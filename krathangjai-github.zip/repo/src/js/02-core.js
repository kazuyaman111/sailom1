/* ===================== เซฟข้อมูล ===================== */
const MEM = {};
const Store = {
  async get(k){
    if (typeof window !== 'undefined' && window.storage && window.storage.get){
      try { const r = await window.storage.get(k); return r ? r.value : null; }
      catch(e){ return null; }
    }
    try { return localStorage.getItem(k); } catch(e){ return MEM[k] ?? null; }
  },
  async set(k, v){
    if (typeof window !== 'undefined' && window.storage && window.storage.set){
      try { await window.storage.set(k, v); return; } catch(e){}
    }
    try { localStorage.setItem(k, v); } catch(e){ MEM[k] = v; }
  }
};

/* ===================== สถานะเกม ===================== */
let S = null;

function newPet(sp, name){
  const s = SPECIES[sp];
  const mul = RARITY[s.rarity].statMul;
  const base = {STR:5, VIT:5, AGI:5, INT:5, LUK:5};
  base[s.main] += 3;
  base[s.sub]  += 2;
  for (const k in base) base[k] = Math.round(base[k] * mul);
  return {
    sp, name: name || s.name,
    stage:0, branch:null,
    lv:1, xp:0,
    stats: base,
    hunger:70, mood:70, hp:100, aff:5,
    care:{body:0, mind:0, play:0},
    born: Date.now(),
    sick:false,
  };
}

function freshSave(){
  return {
    v: VERSION,
    uid: makeUid(),
    created: Date.now(),
    lastTick: Date.now(),
    coins: 120, crystals: 0,
    pet: null,
    bag: { leaf:3, berry:1 },
    garden: [],
    seen: {},
    room: new Array(12).fill(null),
    book: {},              // formId -> วันที่ปลดล็อก
    explore: null,         // {zone, endAt}
    egg: null,           // {tier, pts, need, subj:{}}
    qcustom: [],         // คำถามที่ผู้เล่นเพิ่มเอง
    qoff: {},            // รหัสคำถามในคลังตั้งต้นที่ถูกปิด
    qstate: {},          // รหัส -> {box, seen, right, wrong, lastDay}
    qcount: 0,           // นับจำนวนข้อที่ตอบไปแล้วทั้งหมด (ใช้กับระบบทวนซ้ำ)
    grade: 'p5',
    prog: {},            // "subj|grade|unit" -> {r, w, recent:[]}
    stats: { answered:0, correct:0, points:0, rounds:0, best:0, streak:0, bestStreak:0, lastDay:'' },
    daily: { day:'', plays:0 },
    settings: { timed:true, shuffle:true },
  };
}

function makeUid(){
  let s = '';
  const c = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  for (let i=0;i<8;i++) s += c[Math.floor(Math.random()*c.length)];
  return s;
}

/* ===================== ตัวช่วย ===================== */
const clamp = (v,a,b)=>Math.max(a, Math.min(b, v));
const todayKey = ()=>{ const d=new Date(); return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`; };
const pick = a => a[Math.floor(Math.random()*a.length)];

function hashStr(str){
  let h = 2166136261;
  for (let i=0;i<str.length;i++){ h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function rngFrom(seed){
  let s = seed >>> 0;
  return function(){ s ^= s<<13; s>>>=0; s ^= s>>17; s ^= s<<5; s>>>=0; return s/4294967296; };
}
// รหัสสะสม 13 หลัก ผูกกับบัญชี+ร่าง
function collectCode(formIdStr){
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
  const r = rngFrom(hashStr(S.uid + '|' + formIdStr + '|' + S.created));
  let out = '';
  for (let i=0;i<13;i++){
    if (i===4 || i===9) { out += '-'; continue; }
    out += c[Math.floor(r()*c.length)];
  }
  return out;
}

function fmtTime(sec){
  sec = Math.max(0, Math.round(sec));
  const m = Math.floor(sec/60), s = sec%60;
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
}
function fmtLeft(ms){
  const m = Math.ceil(ms/60000);
  if (m >= 60) return `${Math.floor(m/60)} ชม. ${m%60} นาที`;
  return `${m} นาที`;
}
function fmtDate(ts){
  const d = new Date(ts);
  return `${d.getDate()}/${d.getMonth()+1}/${(d.getFullYear()+543)%100}`;
}

/* ===================== โบนัสจากเฟอร์นิเจอร์ ===================== */
function roomBonus(){
  const b = {moodSlow:0, hungerSlow:0, focusXp:0, exploreLuck:0, aff:0, coin:0, light:0};
  for (const k of S.room){
    if (!k || !FURN[k]) continue;
    for (const [ek, ev] of Object.entries(FURN[k].eff)) b[ek] = (b[ek]||0) + ev;
  }
  return b;
}
function isNight(){ const h = new Date().getHours(); return h >= 19 || h < 6; }

/* ===================== ค่าประสบการณ์ / เลเวล ===================== */
function xpNeed(lv){ return Math.round(20 + 5.3 * Math.pow(lv, 1.35)); }

function gainXp(n){
  const p = S.pet; if (!p) return {levels:0};
  n = Math.round(n);
  p.xp += n;
  let levels = 0;
  while (p.xp >= xpNeed(p.lv) && p.lv < 99){
    p.xp -= xpNeed(p.lv);
    p.lv++; levels++;
    const sp = SPECIES[p.sp];
    for (const k of ['STR','VIT','AGI','INT','LUK']){
      p.stats[k] += (k === sp.main) ? 2 : (k === sp.sub ? 1 : (Math.random() < .5 ? 1 : 0));
    }
    // โบนัสตามความหายาก
    const extra = (RARITY[sp.rarity].statMul - 1) * 3;
    if (Math.random() < extra) p.stats[sp.main] += 1;
    if (Math.random() < extra - 1) p.stats[sp.sub] += 1;
  }
  return {levels, xp:n};
}

/* ===================== วิวัฒนาการ ===================== */
function dominantBranch(){
  const c = S.pet.care;
  let best = 'body', bv = -1;
  for (const k of ['body','mind','play']) if (c[k] > bv){ bv = c[k]; best = k; }
  return best;
}
function evoCheck(){
  const p = S.pet; if (!p) return null;
  const next = p.stage + 1;
  if (next > 5) return null;
  const needLv = STAGE_LV[next];
  const needAff = [0, 10, 25, 45, 65, 85][next];
  const br = p.stage >= 3 ? p.branch : dominantBranch();
  const stoneKey = {body:'stone_b', mind:'stone_m', play:'stone_p'}[br];
  const needStone = next === 5;
  const ok = p.lv >= needLv && p.aff >= needAff && (!needStone || (S.bag[stoneKey]||0) > 0);
  return { next, needLv, needAff, needStone, stoneKey, br, ok };
}
function doEvolve(){
  const e = evoCheck();
  if (!e || !e.ok) return null;
  const p = S.pet;
  if (e.needStone){ S.bag[e.stoneKey]--; if (!S.bag[e.stoneKey]) delete S.bag[e.stoneKey]; }
  p.stage = e.next;
  p.branch = e.next >= 5 ? 'anc' : (e.next >= 3 ? e.br : null);
  for (const k of ['STR','VIT','AGI','INT','LUK']) p.stats[k] += 3;
  p.mood = clamp(p.mood + 20, 0, 100);
  p.hp = 100;
  unlockForm();
  return formName(p.sp, p.stage, p.branch);
}
function currentFormId(){
  const p = S.pet;
  return p.stage <= 2 ? formId(p.sp, p.stage) : formId(p.sp, p.stage, p.branch);
}
function unlockForm(){
  const id = currentFormId();
  if (!S.book[id]) S.book[id] = Date.now();
  if (!S.seen) S.seen = {};
  if (!S.seen[S.pet.sp]) S.seen[S.pet.sp] = Date.now();
}

/* ===================== สวน: เก็บวิญญาณหลายตัว ===================== */
function gardenCount(){ return (S.garden || []).length; }
function stashActive(){
  if (!S.pet) return;
  S.garden = S.garden || [];
  S.garden.push(S.pet);
  S.pet = null;
}
function swapWith(i){
  S.garden = S.garden || [];
  const other = S.garden[i];
  if (!other) return false;
  S.garden[i] = S.pet;
  S.pet = other;
  return true;
}
function releasePet(i){
  S.garden = S.garden || [];
  return S.garden.splice(i, 1)[0];
}

/* ===================== สุ่มสายพันธุ์จากเมล็ด ===================== */
function rollSpecies(tier, n = 3){
  const odds = SEED_ODDS[tier] || SEED_ODDS[1];
  const out = [];
  let guard = 0;
  while (out.length < n && guard++ < 400){
    let total = 0;
    for (const r in odds) total += odds[r];
    let roll = Math.random() * total, rar = 1;
    for (const r in odds){ roll -= odds[r]; if (roll <= 0){ rar = +r; break; } }
    const pool = SP_BY_RARITY(rar).filter(k => !out.includes(k));
    if (!pool.length) continue;
    out.push(pick(pool));
  }
  return out;
}

/* ===================== เวลาเดินจริง ===================== */
function tickOffline(){
  const now = Date.now();
  const hrs = (now - S.lastTick) / 3600000;
  S.lastTick = now;
  if (hrs <= 0) return;
  const t0 = todayKey();
  if (S.daily.day !== t0){ S.daily.day = t0; S.daily.plays = 0; }
  if (!S.pet) return;
  const b = roomBonus();
  const p = S.pet;
  const hMul = RARITY[SPECIES[p.sp].rarity].hungerMul;
  p.hunger = clamp(p.hunger - hrs * 4.2 * hMul * (1 - Math.min(.5, b.hungerSlow)), 0, 100);
  p.mood   = clamp(p.mood   - hrs * 3.0 * (1 - Math.min(.5, b.moodSlow)), 0, 100);
  if (b.light && isNight()) p.mood = clamp(p.mood + hrs * 2, 0, 100);
  if (p.hunger <= 0) p.hp = clamp(p.hp - hrs * 5, 1, 100);
  else if (p.hunger > 50 && p.mood > 40) p.hp = clamp(p.hp + hrs * 3, 0, 100);
  if (p.hp < 30) p.sick = true;
  if (p.hp >= 60) p.sick = false;

  // รีเซ็ตรายวัน
  const t = todayKey();
  if (S.daily.day !== t){ S.daily.day = t; S.daily.plays = 0; }
}

/* ===================== การกระทำกับสัตว์เลี้ยง ===================== */
function useItem(key){
  const it = ITEMS[key]; const p = S.pet;
  if (!it || !p || !(S.bag[key] > 0)) return null;
  const b = roomBonus();
  let msg = '';
  if (it.t === 'food'){
    if (p.hunger >= 99) return {err:'อิ่มจนกินไม่ลงแล้ว'};
    p.hunger = clamp(p.hunger + it.hunger, 0, 100);
    p.mood = clamp(p.mood + (it.mood||0), 0, 100);
    p.aff = clamp(p.aff + (it.aff||0) * (1 + b.aff), 0, 100);
    p.care.body += 1;
    gainXp(6);
    msg = `ให้${it.n}แล้ว ความอิ่ม +${it.hunger}`;
  } else if (it.t === 'heal'){
    if (p.hp >= 100) return {err:'สุขภาพเต็มอยู่แล้ว'};
    p.hp = clamp(p.hp + it.heal, 0, 100);
    p.mood = clamp(p.mood + (it.mood||0), 0, 100);
    p.care.body += 2;
    if (p.hp >= 60) p.sick = false;
    msg = `ใช้${it.n} สุขภาพ +${it.heal}`;
  } else if (it.t === 'egg'){
    return {egg:true};
  } else {
    return {err:'ไอเทมนี้ใช้กับวิญญาณไม่ได้'};
  }
  S.bag[key]--; if (!S.bag[key]) delete S.bag[key];
  return {msg};
}

function addItem(key, n=1){
  S.bag[key] = (S.bag[key]||0) + n;
}
function bagCount(){ return Object.values(S.bag).reduce((a,b)=>a+b, 0); }
function petPower(p){ p = p || S.pet; return ['STR','VIT','AGI','INT','LUK'].reduce((a,k)=>a+p.stats[k], 0); }


/* ===================== คลังคำถาม ===================== */
function allQuestions(){
  const off = S.qoff || {};
  const built = QBANK_BUILTIN.filter(q => !off[q.id]);
  return built.concat(S.qcustom || []);
}
function questionsBy(subj, grade){
  let all = allQuestions();
  if (grade) all = all.filter(q => q.grade === grade);
  return subj === 'mix' ? all : all.filter(q => q.subj === subj);
}
/* วิชาที่มีคำถามพร้อมใช้ในระดับชั้นนั้น */
function subjectsReady(grade){
  return SUBJ_KEYS.filter(k => questionsBy(k, grade).length > 0);
}
function gradesReady(){
  return GRADE_KEYS.filter(g => questionsBy('mix', g).length > 0);
}
function qstate(id){
  S.qstate = S.qstate || {};
  if (!S.qstate[id]) S.qstate[id] = {box:1, seen:0, right:0, wrong:0, at:-999, lastDay:''};
  return S.qstate[id];
}

/* เลือกคำถามถัดไป: ข้อที่ถึงกำหนดทวนก่อน กล่องต่ำมาก่อน */
function pickQuestion(subj, grade, exclude){
  const pool = questionsBy(subj, grade).filter(q => !exclude.includes(q.id));
  if (!pool.length) return null;
  const now = S.qcount || 0;
  const scored = pool.map(q => {
    const st = qstate(q.id);
    const gap = LEITNER_GAP[Math.min(5, st.box)] || 0;
    const overdue = (now - st.at) - gap;        // > 0 คือถึงกำหนดแล้ว
    const fresh = st.seen === 0 ? 40 : 0;       // ข้อที่ยังไม่เคยเจอมาก่อน
    const weight = fresh + Math.max(0, overdue) * 2 + (6 - st.box) * 6 + Math.random() * 18;
    return {q, weight, ready: st.seen === 0 || overdue >= 0};
  });
  const ready = scored.filter(x => x.ready);
  const use = ready.length ? ready : scored;
  use.sort((a, b) => b.weight - a.weight);
  return use[0].q;
}

/* ===================== ให้คะแนนคำตอบ ===================== */
function scoreAnswer(q, correct, msLeft, msTotal, streak){
  const base = DIFF[q.diff].pt;
  if (!correct) return {pts:0, speed:0, mult:0, base};
  const speed = msTotal > 0 ? clamp(msLeft / msTotal, 0, 1) * SPEED_BONUS_MAX : 0;
  const mult = 1 + Math.min(STREAK_CAP, streak) * (1 / STREAK_CAP);   // 1.0 → 2.0
  const st = qstate(q.id);
  const repeat = (st.lastDay === todayKey() && st.seen > 0) ? REPEAT_PENALTY : 1;
  return {
    pts: Math.max(1, Math.round(base * (1 + speed) * mult * repeat)),
    speed, mult, base, repeat
  };
}

/* บันทึกผลสัมฤทธิ์แยกตามวิชา ระดับชั้น และหน่วยการเรียนรู้ */
function progKey(q){ return `${q.subj}|${q.grade}|${q.unit}`; }
function progOf(key){
  S.prog = S.prog || {};
  if (!S.prog[key]) S.prog[key] = {r:0, w:0, recent:[]};
  return S.prog[key];
}
function recordProgress(q, correct){
  const p = progOf(progKey(q));
  if (correct) p.r++; else p.w++;
  p.recent.push(correct ? 1 : 0);
  if (p.recent.length > 40) p.recent.shift();
}
/* แนวโน้ม: เทียบครึ่งหลังกับครึ่งแรกของผลล่าสุด */
function trendOf(p){
  const n = p.recent.length;
  if (n < 10) return null;
  const half = Math.floor(n/2);
  const a = p.recent.slice(0, half), b = p.recent.slice(half);
  const av = a.reduce((x,y)=>x+y,0)/a.length, bv = b.reduce((x,y)=>x+y,0)/b.length;
  return { diff: bv - av, before: av, after: bv };
}

/* บันทึกผลลงกล่องทวนซ้ำ */
function recordAnswer(q, correct){
  const st = qstate(q.id);
  st.seen++;
  st.at = S.qcount || 0;
  st.lastDay = todayKey();
  if (correct){ st.right++; st.box = Math.min(5, st.box + 1); }
  else { st.wrong++; st.box = 1; }
  S.qcount = (S.qcount || 0) + 1;
  recordProgress(q, correct);
}

/* ===================== ไข่ ===================== */
/* ---- สุ่มผังธาตุประจำไข่แต่ละใบ ----
   หน่วยการเรียนรู้เดิมจะให้ธาตุไม่เหมือนกันในไข่คนละใบ
   ทำให้ฟาร์มหน่วยเดิมซ้ำๆ ไม่ได้สายพันธุ์เดิมเสมอไป */
function rollEggMap(){
  const units = Object.keys(UNITS);
  const pool = [];
  while (pool.length < units.length){
    pool.push(...EL_KEYS.slice().sort(() => Math.random() - .5));
  }
  const order = units.slice().sort(() => Math.random() - .5);
  const map = {};
  order.forEach((u, i) => { map[u] = pool[i]; });
  return map;
}
function eggMap(){
  if (!S.egg) return null;
  if (!S.egg.map) S.egg.map = rollEggMap();
  return S.egg.map;
}
function unitEl(u){
  const m = eggMap();
  return (m && m[u]) || (UNITS[u] ? UNITS[u].el : 'wood');
}

function startEgg(tier){
  const key = {1:'seed_r', 2:'seed_g', 3:'seed_m'}[tier];
  S.egg = { tier, pts:0, need: ITEMS[key].need, el:{}, unit:{}, map: rollEggMap() };
}
/* ไข่รับคะแนนพร้อมหน่วยการเรียนรู้ ธาตุของหน่วยเป็นตัวกำหนดสายพันธุ์ */
function eggAddPoints(pts, unitCounts){
  if (!S.egg) return false;
  S.egg.pts += pts;
  S.egg.el = S.egg.el || {}; S.egg.unit = S.egg.unit || {};
  const m = eggMap();
  for (const u in unitCounts){
    if (!UNITS[u]) continue;
    const el = m[u] || UNITS[u].el;
    S.egg.unit[u] = (S.egg.unit[u] || 0) + unitCounts[u];
    S.egg.el[el] = (S.egg.el[el] || 0) + unitCounts[u];
  }
  return S.egg.pts >= S.egg.need;
}
/* สัดส่วนธาตุที่สะสมในไข่ */
function eggElShare(){
  const e = S.egg; if (!e || !e.el) return {};
  let tot = 0;
  for (const k in e.el) tot += e.el[k];
  const out = {};
  if (tot <= 0) return out;
  for (const k in e.el) out[k] = e.el[k] / tot;
  return out;
}
/* หน่วยการเรียนรู้ที่สะสมมากที่สุดในไข่ */
function eggTopUnit(){
  const e = S.egg; if (!e || !e.unit) return null;
  let best = null, bv = -1;
  for (const k in e.unit) if (e.unit[k] > bv){ bv = e.unit[k]; best = k; }
  return best;
}
/* น้ำหนักของแต่ละสายพันธุ์ตอนฟัก
   ขั้นที่ 1 สุ่มความหายากจากชั้นของไข่  ขั้นที่ 2 สุ่มสายพันธุ์ในระดับนั้น
   โดยถ่วงน้ำหนักด้วยสัดส่วนวิชาที่ตอบระหว่างฟัก */
const AFFINITY_K = 10;
const CHAOS_CHANCE = 0.15;   // โอกาสที่ไข่จะสุ่มธาตุเองโดยไม่สนหน่วยที่ตอบ

function hatchWeights(ignoreAffinity){
  const e = S.egg;
  const odds = SEED_ODDS[e ? e.tier : 1] || SEED_ODDS[1];
  const share = ignoreAffinity ? {} : eggElShare();
  const w = {}; for (const k of SP_KEYS) w[k] = 0;
  let tot = 0; for (const r in odds) tot += odds[r];
  for (const r in odds){
    const p = odds[r] / tot;
    if (p <= 0) continue;
    const pool = SP_BY_RARITY(+r);
    if (!pool.length) continue;
    const ws = {}; let sum = 0;
    for (const k of pool){
      const a = 1 + AFFINITY_K * (share[SPECIES[k].elk] || 0);
      ws[k] = a; sum += a;
    }
    for (const k of pool) w[k] += p * ws[k] / sum;
  }
  return w;   // รวมกันได้ 1
}
/* โอกาสเป็นเปอร์เซ็นต์ รวมตามธาตุ */
function hatchOddsByEl(ignoreAffinity){
  const w = hatchWeights(ignoreAffinity);
  const out = {};
  for (const k in w){
    const e = SPECIES[k].elk;
    out[e] = (out[e] || 0) + w[k];
  }
  return out;
}
function hatchRoll(ignoreAffinity){
  const w = hatchWeights(ignoreAffinity);
  let tot = 0; for (const k in w) tot += w[k];
  let r = Math.random() * tot;
  for (const k in w){ r -= w[k]; if (r <= 0) return k; }
  return SP_KEYS[0];
}
