const fs = require('fs');
const shell = fs.readFileSync('template.html', 'utf8');
const parts = ['01-data','01b-curriculum','01c-hist-p4','01c-hist-p5','01c-hist-p6','01c-hist-m1','01c-hist-m2','01c-hist-m3','01c-anti-p4','01c-anti-p5','01c-anti-p6','01d-bank','02-core','03-canvas','04-ui','05-play','06-duel','07-cloud']
  .map(f => fs.readFileSync(`js/${f}.js`, 'utf8')).join('\n');
const out = shell.replace(/<script>\n<\/script>/, '<script>\n' + parts + '\n</script>');
if (out === shell) { console.error('ไม่พบจุดแทรกสคริปต์'); process.exit(1); }
fs.writeFileSync('../index.html', out);
console.log('สร้างไฟล์แล้ว', (out.length/1024).toFixed(1) + ' KB');
