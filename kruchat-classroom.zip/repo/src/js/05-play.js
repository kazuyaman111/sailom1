/* ===================== ระบบตอบคำถาม ===================== */
const QUIZ = {
  running:false, subj:'mix', grade:null, idx:0, used:[], cur:null, units:{},
  streak:0, pts:0, eggPts:0, correct:0, marks:[], len:ROUND_LEN,
  startAt:0, limitMs:0, locked:false, chosen:-1, gained:null, tickId:null
};

function viewQuiz(){
  if (QUIZ.running) return quizQuestionHtml();

  const grade = QUIZ.grade || S.grade;
  const ready = gradesReady();
  const counts = {};
  for (const k of SUBJ_KEYS) counts[k] = questionsBy(k, grade).length;
  const total = questionsBy('mix', grade).length;
  const avail = QUIZ.unit ? questionsBy(QUIZ.subj, grade, QUIZ.unit).length
              : (QUIZ.subj === 'mix' ? total : counts[QUIZ.subj]);

  const gradeChips = GRADE_KEYS.map(g => {
    const n = questionsBy('mix', g).length;
    return `<button class="chip ${g===grade?'on':''}" data-grade="${g}" ${n?'':'disabled'}>
      ${GRADES[g].n} <span class="mono" style="font-size:calc(11px * var(--fs));opacity:.7">${n}</span></button>`;
  }).join('');

  const subjChips = [`<button class="chip ${QUIZ.subj==='mix'?'on':''}" data-subj="mix" ${total?'':'disabled'}>
      🎲 ผสมทุกวิชา <span class="mono" style="font-size:calc(11px * var(--fs));opacity:.7">${total}</span></button>`]
    .concat(SUBJ_KEYS.map(k => {
      const code = SUBJECTS[k].code[grade];
      return `<button class="chip ${QUIZ.subj===k?'on':''}" data-subj="${k}" ${counts[k]?'':'disabled'}>
        ${SUBJECTS[k].g} ${SUBJECTS[k].short}${code?` <span class="tiny">${code}</span>`:''}
        <span class="mono" style="font-size:calc(11px * var(--fs));opacity:.7">${counts[k]}</span></button>`;
    })).join('');

  // หน่วยการเรียนรู้ที่มีในชุดนี้
  const pool = questionsBy(QUIZ.subj, grade);
  const unitSet = {};
  for (const q of pool) unitSet[q.unit] = (unitSet[q.unit] || 0) + 1;
  const unitLine = Object.keys(unitSet).length
    ? `<div class="tiny" style="margin-top:8px">หน่วยที่จะสุ่มมา — ${Object.keys(unitSet)
        .map(u => `${UNITS[u].n} (${unitSet[u]})`).join(' · ')}</div>` : '';

  return `
  ${stageBlock()}
  ${mqCard()}
  <div class="card">
    <div class="eyebrow">ระดับชั้น</div>
    <div class="chips">${gradeChips}</div>
    ${ready.length < GRADE_KEYS.length ? `<div class="tiny" style="margin-top:8px">ระดับชั้นที่ยังไม่มีคำถามจะกดไม่ได้ ครูเพิ่มคำถามได้ที่คลังคำถามด้านล่าง</div>` : ''}
  </div>
  <div class="card">
    <div class="eyebrow">เลือกวิชา</div>
    <h2>จะตอบเรื่องอะไรดี</h2>
    <div class="sub">หน่วยการเรียนรู้ที่ตอบจะกำหนดธาตุของไข่ที่กำลังฟักอยู่</div>
    <div class="gap"></div>
    <div class="chips">${subjChips}</div>
    ${unitLine}
    <div class="gap"></div>
    ${QUIZ.unit ? `<div class="expl" style="border-left-color:var(--gold);margin-bottom:10px">
      <b style="color:var(--gold)">กำลังฝึกเฉพาะ${esc(UNITS[QUIZ.unit].n)}</b>
      <div class="tiny">คำถามในรอบนี้จะมาจากหน่วยนี้เท่านั้น</div>
      <div class="gap" style="height:8px"></div>
      <button class="btn sm" data-act="unlockUnit">ตอบทุกหน่วยตามปกติ</button>
    </div>` : ''}
    <button class="btn pri block" data-act="startQuiz" ${avail?'':'disabled'}>
      ${avail ? `เริ่มรอบ ${Math.min(ROUND_LEN, avail)} ข้อ` : 'ยังไม่มีคำถามในชุดนี้'}</button>
    <div class="tiny" style="margin-top:8px">
      ตอบถูกได้คะแนนเต็มเสมอ ตอบเร็วได้โบนัสเพิ่มสูงสุด 50% และตอบถูกติดกันจะได้ตัวคูณสูงสุด ×2
    </div>
    <hr class="sep">
    <div class="row spread">
      <div class="grow"><b>โหมดจับคู่</b>
        <div class="sub">อุ่นเครื่องก่อนสอบ จับเวลา ไม่หักคะแนนเมื่อผิด</div></div>
      <button class="btn gold" data-act="match">เปิด</button>
    </div>
  </div>
  <div class="card">
    <div class="eyebrow">คลังคำถาม</div>
    <div class="row spread">
      <div class="grow"><b>${allQuestions().length} ข้อทั้งหมด</b>
        <div class="sub">เพิ่มคำถามเอง หรือนำเข้าจาก Google Sheets ได้</div></div>
      <button class="btn" data-act="qbank">จัดการ</button>
    </div>
  </div>`;
}

function quizQuestionHtml(){
  const q = QUIZ.cur;
  const d = DIFF[q.diff];
  const dots = Array.from({length:QUIZ.len}, (_,i) => {
    const m = QUIZ.marks[i];
    return `<i class="${i===QUIZ.idx?'now':(m===1?'ok':(m===0?'no':''))}"></i>`;
  }).join('');

  const choices = q.ch.map((c, i) => {
    let cls = '';
    if (QUIZ.locked){
      if (i === q.ans) cls = 'right';
      else if (i === QUIZ.chosen) cls = 'wrong';
    }
    return `<button class="ch ${cls}" data-ans="${i}" ${QUIZ.locked?'disabled':''}>
      <span class="k">${'กขคง'[i]}</span><span>${esc(c)}</span></button>`;
  }).join('');

  let after = '';
  if (QUIZ.locked){
    const ok = QUIZ.chosen === q.ans;
    const g = QUIZ.gained;
    after = `<div class="expl" style="border-left-color:${ok?'var(--glaze)':'var(--bad)'}">
      <b>${ok ? `ถูกต้อง +${g.pts} คะแนน` : 'ยังไม่ใช่ คำตอบคือ ' + 'กขคง'[q.ans]}</b>
      ${ok && (g.speed > 0.02 || g.mult > 1) ? `<div class="tiny" style="margin-top:2px">ฐาน ${g.base} · เร็ว +${Math.round(g.speed*100)}% · ต่อเนื่อง ×${g.mult.toFixed(1)}${g.repeat<1?' · ข้อซ้ำวันนี้ ×'+g.repeat:''}</div>` : ''}
      ${q.exp ? `<div style="margin-top:6px">${esc(q.exp)}</div>` : ''}
      ${!ok ? `<div class="tiny" style="margin-top:6px;color:var(--glaze-lt)">อ่านคำอธิบายแล้วได้ประสบการณ์เล็กน้อย ข้อนี้จะกลับมาถามอีกเร็วๆ นี้</div>` : ''}
    </div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="nextQ">${QUIZ.idx + 1 >= QUIZ.len ? 'จบรอบ' : 'ข้อถัดไป'}</button>`;
  }

  return `
  ${stageBlock()}
  <div class="card">
    <div class="qmeta">
      <span>ข้อ ${QUIZ.idx+1}/${QUIZ.len} · ${SUBJECTS[q.subj].g} ${GRADES[q.grade].n}
        · ${UNITS[q.unit].n} · <span style="color:${d.c}">${d.n}</span></span>
      <span>${S.settings.timed && !QUIZ.locked ? `<span id="qclock">${Math.ceil(Math.max(0,QUIZ.limitMs-(Date.now()-QUIZ.startAt))/1000)} วิ</span>` : ''}
        ${QUIZ.streak > 1 ? `<span class="combo">🔥 ${QUIZ.streak}</span>` : ''}</span>
    </div>
    <div class="dots" style="margin-bottom:10px">${dots}</div>
    <div class="qtext">${esc(q.q)}</div>
    <div class="choices">${choices}</div>
    ${after}
  </div>
  <div class="card">
    <div class="row spread">
      <span class="sub">คะแนนรอบนี้</span><b class="mono" style="font-size:calc(19px * var(--fs))">${QUIZ.pts}</b>
    </div>
    ${QUIZ.locked ? '' : '<div class="gap"></div><button class="btn sm danger block" data-act="quitQuiz">ออกจากรอบนี้</button>'}
  </div>`;
}

function startQuiz(){
  QUIZ.grade = QUIZ.grade || S.grade;
  const avail = questionsBy(QUIZ.subj, QUIZ.grade).length;
  if (!avail) return toast('วิชานี้ยังไม่มีคำถามในคลัง', 'bad');
  QUIZ.running = true; QUIZ.idx = 0; QUIZ.used = []; QUIZ.streak = 0;
  QUIZ.pts = 0; QUIZ.eggPts = 0; QUIZ.correct = 0; QUIZ.marks = []; QUIZ.units = {}; QUIZ.wokeUp = false; QUIZ.mqDone = null;
  QUIZ.len = Math.min(ROUND_LEN, avail);
  nextQuestion();
}

function nextQuestion(){
  const q = pickQuestion(QUIZ.subj, QUIZ.grade, QUIZ.used, QUIZ.unit);
  if (!q){ return finishQuiz(); }
  QUIZ.used.push(q.id);
  // สลับตัวเลือกไม่ให้จำตำแหน่ง
  let cur = q;
  if (S.settings.shuffle){
    const order = q.ch.map((c,i) => i).sort(() => Math.random() - .5);
    cur = Object.assign({}, q, {
      ch: order.map(i => q.ch[i]),
      ans: order.indexOf(q.ans)
    });
  }
  QUIZ.cur = cur;
  QUIZ.locked = false; QUIZ.chosen = -1; QUIZ.gained = null;
  QUIZ.limitMs = S.settings.timed ? DIFF[cur.diff].sec * 1000 : 0;
  QUIZ.startAt = Date.now();
  View.focusing = true; View.progress = 0; View.drift = false;
  clearInterval(QUIZ.tickId);
  if (QUIZ.limitMs) QUIZ.tickId = setInterval(quizTick, 120);
  render();
}

function quizTick(){
  if (!QUIZ.running || QUIZ.locked || !QUIZ.limitMs) return;
  const left = QUIZ.limitMs - (Date.now() - QUIZ.startAt);
  View.progress = clamp(1 - left / QUIZ.limitMs, 0, 1);
  View.drift = left < QUIZ.limitMs * 0.25;
  const c = document.getElementById('qclock');
  if (c){
    c.textContent = Math.max(0, Math.ceil(left/1000)) + ' วิ';
    c.classList.toggle('low', left < QUIZ.limitMs * 0.25);
  }
  if (left <= 0) answerQuestion(-1);
}

function answerQuestion(i){
  if (QUIZ.locked) return;
  clearInterval(QUIZ.tickId);
  const q = QUIZ.cur;
  const correct = i === q.ans;
  const left = QUIZ.limitMs ? Math.max(0, QUIZ.limitMs - (Date.now() - QUIZ.startAt)) : 0;

  QUIZ.chosen = i;
  QUIZ.locked = true;
  QUIZ.gained = scoreAnswer(q, correct, left, QUIZ.limitMs, QUIZ.streak);
  QUIZ.marks[QUIZ.idx] = correct ? 1 : 0;

  if (correct){
    QUIZ.pts += QUIZ.gained.pts;
    QUIZ.eggPts += QUIZ.gained.base;      // ไข่โตจากคะแนนฐานอย่างเดียว
    QUIZ.units[q.unit] = (QUIZ.units[q.unit] || 0) + QUIZ.gained.base;
    QUIZ.correct++;
    QUIZ.streak++;
    if (wakeProgress(1)) QUIZ.wokeUp = true;
    const mqd = mqRecord(q, true);
    if (mqd) QUIZ.mqDone = { m: mqd, rw: mqReward(mqd) };
    S.stats.bestStreak = Math.max(S.stats.bestStreak, QUIZ.streak);
    if (S.pet){
      const p = S.pet;
      if (q.diff >= 3) p.care.mind += 2;
      else if (QUIZ.gained.speed > 0.3) p.care.play += 1;
      else p.care.mind += 1;
    }
  } else {
    QUIZ.streak = 0;
    if (S.pet) S.pet.mood = clamp(S.pet.mood - 2, 0, 100);
  }
  recordAnswer(q, correct);
  S.stats.answered++;
  if (correct) S.stats.correct++;
  View.drift = false;
  View.progress = correct ? 1 : View.progress;
  save(); render();
}

function advanceQuiz(){
  if (!QUIZ.locked) return;
  if (!QUIZ.marks[QUIZ.idx] && S.pet) gainXp(3);   // อ่านคำอธิบายหลังตอบผิด
  QUIZ.idx++;
  if (QUIZ.idx >= QUIZ.len) return finishQuiz();
  nextQuestion();
}

function finishQuiz(){
  clearInterval(QUIZ.tickId);
  QUIZ.running = false;
  View.focusing = false; View.drift = false; View.progress = 0;

  const b = roomBonus();
  const pts = QUIZ.pts;
  const answered = QUIZ.marks.length;
  const acc = answered ? QUIZ.correct / answered : 0;
  const perfect = answered > 0 && QUIZ.correct === answered && answered === QUIZ.len;

  const boosted = (S.boost || 0) > 0;
  const xp = Math.round(pts * 0.6 * (1 + b.focusXp) * (boosted ? 1.25 : 1));
  if (boosted) S.boost--;
  const coin = Math.round(pts * 0.35 * (1 + b.coin));
  const aff = Math.round(pts / 40 * (1 + b.aff));
  let lv = 0;

  if (S.pet){
    lv = gainXp(xp).levels;
    S.pet.aff = clamp(S.pet.aff + aff, 0, 100);
    S.pet.mood = clamp(S.pet.mood + (acc >= .7 ? 6 : 2), 0, 100);
    S.pet.hunger = clamp(S.pet.hunger - 2, 0, 100);
  }
  S.coins += coin;
  S.stats.points += pts;
  S.stats.rounds++;
  S.stats.best = Math.max(S.stats.best, pts);

  // ต่อเนื่องรายวัน
  const t = todayKey();
  if (S.stats.lastDay !== t){
    const y = new Date(Date.now() - 86400000);
    const yk = `${y.getFullYear()}-${y.getMonth()+1}-${y.getDate()}`;
    S.stats.streak = (S.stats.lastDay === yk) ? S.stats.streak + 1 : 1;
    S.stats.lastDay = t;
  }

  // ผลึกสมาธิ
  let cr = Math.floor(QUIZ.correct / 4) + (perfect ? 2 : 0);
  if (cr > 0 && Math.random() < b.crystal) cr += 1;
  if (cr > 0) S.crystals += cr;

  // ของติดมือ
  const got = [];
  const pool = ['leaf','leaf','berry','clay','bamboo','ricecake','shard'];
  for (let i=0;i<QUIZ.correct;i++){
    if (Math.random() < .30 + b.exploreLuck){ const k = pick(pool); addItem(k); got.push(ITEMS[k].n); }
  }
  if (perfect && Math.random() < .25 + b.exploreLuck){
    const k = pick(['stone_b','stone_m','stone_p']); addItem(k); got.push(ITEMS[k].n);
  }

  // ป้อนคะแนนให้ไข่
  let hatchReady = false;
  if (S.egg && QUIZ.eggPts > 0) hatchReady = eggAddPoints(QUIZ.eggPts, QUIZ.units);

  save(); render();
  if (tutorStep() && tutorStep().id === 'quiz'){
    S.tutor.step++; S.tutor.at = Date.now(); save(); applyTabLock();
  }
  sheet(quizResultSheet(pts, acc, perfect, xp, coin, aff, cr, got, lv, hatchReady, boosted));
  cloudAutoSync();
}

function quizResultSheet(pts, acc, perfect, xp, coin, aff, cr, got, lv, hatchReady, boosted){
  const line = (g, t, s2) => `<div class="item"><div class="ic">${g}</div><div class="grow"><b>${t}</b>${s2?`<div class="sub">${s2}</div>`:''}</div></div>`;
  return `<div class="eyebrow">จบรอบ</div>
  <h2>${perfect ? 'ถูกหมดทั้งรอบ' : `ตอบถูก ${QUIZ.correct} จาก ${QUIZ.marks.length} ข้อ`}</h2>
  <div class="sub">ความแม่นยำ ${Math.round(acc*100)}% · คะแนนรวม ${pts}${pts > S.stats.best - pts ? '' : ''}</div>
  <div class="gap"></div>
  <div class="list">
    ${QUIZ.mqDone ? line('🎯', `ภารกิจ${esc(UNITS[QUIZ.mqDone.m.unit].n)}สำเร็จ`, `ผลึก +${QUIZ.mqDone.rw.crys} · เหรียญ +${QUIZ.mqDone.rw.coin} · เกจคาถาเต็มในดวลครั้งหน้า`) : ''}
    ${QUIZ.wokeUp ? line('🌅', `${esc(S.pet.name)} ตื่นแล้ว`, 'ค่าสถานะกลับมาเต็มเหมือนเดิมทุกอย่าง') : ''}
    ${S.pet ? line('⭐', `ประสบการณ์ +${xp}`, [lv ? `เลื่อนขึ้น ${lv} เลเวล เป็น Lv.${S.pet.lv}` : '', boosted ? `ช็อกโกแลตช่วยเพิ่ม 25% · เหลืออีก ${S.boost} รอบ` : ''].filter(Boolean).join(' · ')) : ''}
    ${line('🪙', `เหรียญ +${coin}`)}
    ${cr ? line('💠', `ผลึกสมาธิ +${cr}`, perfect ? 'โบนัสตอบถูกหมดทั้งรอบ' : '') : ''}
    ${S.pet ? line('💞', `ความสนิท +${aff}`) : ''}
    ${got.length ? line('🎁', 'ได้รับ', got.join(' · ')) : ''}
    ${S.egg ? line('🥚', `ไข่ได้รับ +${QUIZ.eggPts} คะแนนฐาน`, `${Math.min(S.egg.pts,S.egg.need)}/${S.egg.need}`) : ''}
    ${S.stats.streak > 1 ? line('🔥', `ตอบต่อเนื่อง ${S.stats.streak} วัน`) : ''}
  </div>
  <div class="gap"></div>
  ${hatchReady ? `<button class="btn gold block" data-act="hatch">ไข่พร้อมฟักแล้ว</button><div class="gap"></div>` : ''}
  <button class="btn pri block" data-act="closeSheet">ปิด</button>`;
}

/* ===================== ไข่ ===================== */
function openEgg(key){
  if (S.egg) return toast('มีไข่ที่กำลังฟักอยู่แล้ว ต้องฟักใบนี้ให้เสร็จก่อน', 'bad');
  if (!(S.bag[key] > 0)) return toast('ไม่มีไข่ใบนี้', 'bad');
  S.bag[key]--; if (!S.bag[key]) delete S.bag[key];
  startEgg(ITEMS[key].tier);
  save(); render();
  toast(`เริ่มฟัก${ITEMS[key].n}แล้ว ตอบคำถามเพื่อสะสมคะแนน`, 'gold');
}

function doHatch(){
  if (!S.egg || S.egg.pts < S.egg.need) return toast('คะแนนยังไม่ถึง', 'bad');
  if (S.pet && gardenCount() + 1 >= GARDEN_MAX)
    return toast(`สวนเต็ม ${GARDEN_MAX} ตัวแล้ว ปล่อยตัวใดตัวหนึ่งก่อน`, 'bad');

  const chaos = Math.random() < CHAOS_CHANCE;
  const sp = hatchRoll(chaos);
  const topUnit = eggTopUnit();
  S.egg = null;
  const first = !S.pet;
  if (!first) stashActive();
  S.pet = newPet(sp);
  unlockForm();
  save(); render();

  const R = RARITY[SPECIES[sp].rarity];
  sheet(`<div class="eyebrow">ไข่ฟักแล้ว</div>
    <h2 style="color:${SPECIES[sp].accent}">${SPECIES[sp].name} ${R.star}</h2>
    <div class="sub">${SPECIES[sp].desc}</div>
    <div class="gap"></div>
    <div class="list">
      <div class="item"><div class="ic" style="background:${SPECIES[sp].dim};border-color:${SPECIES[sp].a(.4)}">${SPECIES[sp].g}</div>
        <div class="grow"><b>ธาตุ${SPECIES[sp].el} · ${R.n}</b>
          <div class="sub">เด่น ${SPECIES[sp].main} · รอง ${SPECIES[sp].sub}</div>
          ${chaos
            ? `<div class="tiny" style="color:var(--gold)">ธาตุแปรปรวน — ไข่ใบนี้เลือกธาตุเองโดยไม่สนหน่วยที่ตอบ</div>`
            : (topUnit ? `<div class="tiny">ธาตุนี้มาจากการตอบหน่วย "${UNITS[topUnit].n}" เป็นหลัก</div>` : '')}
        </div></div>
    </div>
    <div class="gap"></div>
    <input id="nameIn" maxlength="14" value="${esc(S.pet.name)}" class="fld" placeholder="ตั้งชื่อ">
    <button class="btn pri block" data-act="saveName">เริ่มเลี้ยง</button>`);
}

/* ===================== คลังคำถาม ===================== */
function qbankSheet(){
  const custom = S.qcustom || [];
  const off = Object.keys(S.qoff || {}).length;
  const rows = [];
  for (const k of SUBJ_KEYS){
    for (const g of gradesOf(k)){
      const n = questionsBy(k, g).length;
      const mine = custom.filter(q => q.subj === k && q.grade === g).length;
      rows.push(`<div class="item">
        <div class="ic">${SUBJECTS[k].g}</div>
        <div class="grow"><b>${SUBJECTS[k].short} ${GRADES[g].n}</b>
          <div class="sub">${SUBJECTS[k].code[g]} · ${n} ข้อ${mine?` · เพิ่มเอง ${mine}`:''}${n?'':' · ยังไม่มีคำถาม'}</div></div>
        ${n ? `<button class="btn sm" data-qlist="${k}:${g}">ดู</button>` : '<span class="pill">ว่าง</span>'}
      </div>`);
    }
  }
  sheet(`<div class="eyebrow">คลังคำถาม · ${allQuestions().length} ข้อ</div>
    <h2>จัดการคำถาม</h2>
    <div class="sub">คำถามที่เพิ่มเองบันทึกไว้ในเครื่องพร้อมกับเซฟเกม${off?` · ปิดใช้อยู่ ${off} ข้อ`:''}</div>
    <div class="gap"></div>
    <div class="list">${rows.join('')}</div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="qadd">เพิ่มคำถามใหม่</button>
    <div class="gap"></div>
    <button class="btn block" data-act="qlint">ตรวจคุณภาพข้อสอบ</button>
    <div class="gap"></div>
    <button class="btn block" data-act="qimport">นำเข้าจาก CSV</button>
    <div class="gap"></div>
    <button class="btn block" data-act="qexport">ส่งออกเป็น CSV</button>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

function qlistSheet(tag){
  const [subj, grade] = tag.split(':');
  const list = questionsBy(subj, grade);
  const byUnit = {};
  for (const q of list) (byUnit[q.unit] = byUnit[q.unit] || []).push(q);
  sheet(`<div class="eyebrow">${SUBJECTS[subj].g} ${SUBJECTS[subj].short} ${GRADES[grade].n}</div>
    <h2>${list.length} ข้อ</h2>
    <div class="gap"></div>
    ${Object.keys(byUnit).map(u => `
      <div class="eyebrow" style="margin-top:10px">${UNITS[u].n} · ${byUnit[u].length} ข้อ</div>
      <div class="list">${byUnit[u].map(q => `<div class="item">
        <div class="ic" style="font-size:calc(11px * var(--fs));color:${DIFF[q.diff].c};text-align:center;line-height:1.2">${DIFF[q.diff].n}</div>
        <div class="grow"><b style="font-size:calc(13px * var(--fs));font-weight:400">${esc(q.q)}</b>
          <div class="tiny">เฉลย ${'กขคง'[q.ans]} · ${esc(q.ch[q.ans])}${(S.qstate&&S.qstate[q.id])?` · ถูก ${S.qstate[q.id].right} ผิด ${S.qstate[q.id].wrong} · กล่อง ${S.qstate[q.id].box}`:''}</div></div>
        <button class="btn sm danger" data-qdel="${q.id}">${q.built?'ปิด':'ลบ'}</button>
      </div>`).join('')}</div>`).join('')}
    <div class="gap"></div>
    <button class="btn sm block" data-qlint2="${tag}">ตรวจคุณภาพเฉพาะชุดนี้</button>
    <div class="gap"></div>
    <button class="btn block" data-act="qbank">ย้อนกลับ</button>`);
}

let QADD_ANS = 0;
function unitsOf(subj){ return Object.keys(UNITS).filter(u => UNITS[u].subj === subj); }

function qaddSheet(){
  const subj = SUBJ_KEYS[0];
  sheet(`<div class="eyebrow">เพิ่มคำถาม</div><h2>คำถามใหม่</h2>
    <div class="gap"></div>
    <select id="qsubj" class="fld">${SUBJ_KEYS.map(k=>`<option value="${k}">${SUBJECTS[k].n}</option>`).join('')}</select>
    <select id="qgrade" class="fld">${GRADE_KEYS.map(g=>`<option value="${g}" ${g===S.grade?'selected':''}>${GRADES[g].n}</option>`).join('')}</select>
    <select id="qunit" class="fld">${Object.keys(UNITS).map(u=>`<option value="${u}" data-s="${UNITS[u].subj}">${SUBJECTS[UNITS[u].subj].short} — ${UNITS[u].n}</option>`).join('')}</select>
    <select id="qdiff" class="fld">${[1,2,3,4].map(d=>`<option value="${d}" ${d===2?'selected':''}>${DIFF[d].n} · ${DIFF[d].pt} คะแนน · ${DIFF[d].sec} วิ</option>`).join('')}</select>
    <textarea id="qtext" class="fld" placeholder="โจทย์"></textarea>
    ${[0,1,2,3].map(i=>`<div class="row" style="gap:8px;margin-bottom:8px">
      <button class="btn sm" data-pick="${i}" id="pk${i}" style="width:44px">${'กขคง'[i]}</button>
      <input id="qc${i}" class="fld" style="margin:0" placeholder="ตัวเลือก ${'กขคง'[i]}">
    </div>`).join('')}
    <div class="tiny" style="margin-bottom:8px">แตะตัวอักษรหน้าตัวเลือกเพื่อกำหนดคำตอบที่ถูก (ตอนนี้เลือก <span id="ansNow">ก</span>)</div>
    <textarea id="qexp" class="fld" placeholder="คำอธิบายเฉลย (ไม่ใส่ก็ได้)"></textarea>
    <button class="btn pri block" data-act="qsave">บันทึกคำถาม</button>
    <div class="gap"></div>
    <button class="btn block" data-act="qbank">ยกเลิก</button>`);
  QADD_ANS = 0; markPick();
}
function markPick(){
  for (let i=0;i<4;i++){
    const el = document.getElementById('pk'+i);
    if (el) el.classList.toggle('on', i === QADD_ANS);
  }
  const a = document.getElementById('ansNow');
  if (a) a.textContent = 'กขคง'[QADD_ANS];
}

function qsave(){
  const subj = document.getElementById('qsubj').value;
  const grade = document.getElementById('qgrade').value;
  const unit = document.getElementById('qunit').value;
  const diff = +document.getElementById('qdiff').value;
  const q = document.getElementById('qtext').value.trim();
  const ch = [0,1,2,3].map(i => document.getElementById('qc'+i).value.trim());
  const exp = document.getElementById('qexp').value.trim();
  if (!q) return toast('ยังไม่ได้ใส่โจทย์', 'bad');
  if (ch.some(c => !c)) return toast('ต้องใส่ตัวเลือกให้ครบทั้ง 4 ข้อ', 'bad');
  if (UNITS[unit].subj !== subj) return toast('หน่วยการเรียนรู้ไม่ตรงกับวิชาที่เลือก', 'bad');
  if (!SUBJECTS[subj].code[grade]) return toast(`วิชา${SUBJECTS[subj].short}ไม่ได้สอนในระดับ ${GRADES[grade].n}`, 'bad');
  const chk = lintQuestion({ch, ans:QADD_ANS});
  S.qcustom = S.qcustom || [];
  S.qcustom.push({ id:'c' + Date.now().toString(36), subj, grade, unit, diff, q, ch, ans:QADD_ANS, exp });
  save(); render();
  if (chk.worst === 2) toast('บันทึกแล้ว แต่เฉลยยาวกว่าตัวลวงมาก นักเรียนอาจเดาได้', 'bad');
  else toast('บันทึกคำถามแล้ว');
  qbankSheet();
}

/* ---- CSV ---- */
function csvEscape(v){
  v = String(v == null ? '' : v);
  return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
}
function parseCSV(text){
  const rows = []; let row = [], cell = '', q = false;
  for (let i=0;i<text.length;i++){
    const c = text[i];
    if (q){
      if (c === '"'){ if (text[i+1] === '"'){ cell += '"'; i++; } else q = false; }
      else cell += c;
    } else if (c === '"') q = true;
    else if (c === ',' || c === '\t'){ row.push(cell); cell = ''; }
    else if (c === '\n'){ row.push(cell); cell = ''; if (row.some(x => x.trim() !== '')) rows.push(row); row = []; }
    else if (c !== '\r') cell += c;
  }
  row.push(cell);
  if (row.some(x => x.trim() !== '')) rows.push(row);
  return rows;
}
const SUBJ_BY_NAME = {};
for (const k of SUBJ_KEYS){
  SUBJ_BY_NAME[SUBJECTS[k].n] = k; SUBJ_BY_NAME[SUBJECTS[k].short] = k; SUBJ_BY_NAME[k] = k;
  for (const g in SUBJECTS[k].code) SUBJ_BY_NAME[SUBJECTS[k].code[g]] = k;
}
const GRADE_BY_NAME = {};
for (const g of GRADE_KEYS){ GRADE_BY_NAME[GRADES[g].n] = g; GRADE_BY_NAME[g] = g; GRADE_BY_NAME[GRADES[g].n.replace('.','')] = g; }
const UNIT_BY_NAME = {};
for (const u in UNITS){ UNIT_BY_NAME[UNITS[u].n] = u; UNIT_BY_NAME[u] = u; }
const DIFF_BY_NAME = {'ง่าย':1,'ปานกลาง':2,'กลาง':2,'ยาก':3,'ท้าทาย':4,'1':1,'2':2,'3':3,'4':4};

function qimportSheet(){
  sheet(`<div class="eyebrow">นำเข้าคำถาม</div><h2>วางข้อมูลจาก CSV</h2>
    <div class="sub">คัดลอกจาก Google Sheets แล้ววางลงช่องนี้ได้เลย รองรับทั้งคั่นด้วยจุลภาคและแท็บ</div>
    <div class="gap"></div>
    <div class="tiny" style="margin-bottom:8px">ลำดับคอลัมน์ — <b>วิชา, ระดับชั้น, หน่วยการเรียนรู้, ความยาก, โจทย์, ก, ข, ค, ง, เฉลย(1-4), คำอธิบาย</b><br>
    วิชาใช้ชื่อไทยหรือรหัสวิชา (เช่น ส15102) · ระดับชั้นใช้ ป.5 หรือ ม.1 · ความยากใช้ ง่าย/ปานกลาง/ยาก/ท้าทาย หรือเลข 1-4 · ถ้าเว้นหน่วยว่างไว้ระบบจะใส่หน่วยแรกของวิชานั้นให้ · แถวหัวตารางระบบข้ามให้เอง</div>
    <div class="tiny" style="margin-bottom:8px">หน่วยที่ใช้ได้ — ${Object.keys(UNITS).map(u=>UNITS[u].n).join(' · ')}</div>
    <textarea id="csvIn" class="fld" style="min-height:150px;font-size:calc(13px * var(--fs))" placeholder="ประวัติศาสตร์,ป.5,พัฒนาการของอาณาจักร,ง่าย,กรุงศรีอยุธยาสถาปนาปีใด,1893,1782,2112,1238,1,สถาปนา พ.ศ. 1893"></textarea>
    <button class="btn pri block" data-act="qdoimport">นำเข้า</button>
    <div class="gap"></div>
    <button class="btn block" data-act="qbank">ย้อนกลับ</button>`);
}

function qdoimport(){
  const txt = document.getElementById('csvIn').value;
  if (!txt.trim()) return toast('ยังไม่ได้วางข้อมูล', 'bad');
  const rows = parseCSV(txt);
  let added = 0, skipped = 0;
  S.qcustom = S.qcustom || [];
  for (const r of rows){
    if (r.length < 10){ skipped++; continue; }
    const subj = SUBJ_BY_NAME[(r[0]||'').trim()];
    const grade = GRADE_BY_NAME[(r[1]||'').trim()];
    let unit = UNIT_BY_NAME[(r[2]||'').trim()];
    const diff = DIFF_BY_NAME[(r[3]||'').trim()];
    const q = (r[4]||'').trim();
    const ch = [r[5],r[6],r[7],r[8]].map(x => (x||'').trim());
    const ans = parseInt((r[9]||'').trim(), 10) - 1;
    if (!subj || !grade || !diff || !q || ch.some(c => !c) || !(ans >= 0 && ans <= 3)){ skipped++; continue; }
    if (!unit || UNITS[unit].subj !== subj) unit = unitsOf(subj)[0];
    if (!SUBJECTS[subj].code[grade]){ skipped++; continue; }
    S.qcustom.push({ id:'c' + Date.now().toString(36) + added, subj, grade, unit, diff, q, ch, ans, exp:(r[10]||'').trim() });
    added++;
  }
  save();
  if (!added) return toast(`นำเข้าไม่สำเร็จ ตรวจลำดับคอลัมน์อีกครั้ง (ข้าม ${skipped} แถว)`, 'bad');
  render();
  toast(`นำเข้า ${added} ข้อ${skipped?` · ข้าม ${skipped} แถว`:''}`, 'gold');
  qbankSheet();
}

function qexport(){
  const head = ['วิชา','ระดับชั้น','หน่วยการเรียนรู้','ความยาก','โจทย์','ก','ข','ค','ง','เฉลย','คำอธิบาย'];
  const lines = [head.join(',')];
  for (const q of allQuestions()){
    lines.push([SUBJECTS[q.subj].n, GRADES[q.grade].n, UNITS[q.unit].n, DIFF[q.diff].n,
      q.q, q.ch[0], q.ch[1], q.ch[2], q.ch[3], q.ans+1, q.exp].map(csvEscape).join(','));
  }
  const blob = new Blob(['\ufeff' + lines.join('\n')], {type:'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `คลังคำถาม-${allQuestions().length}ข้อ.csv`; a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 1000);
  toast('ส่งออกไฟล์ CSV แล้ว');
}

/* ===================== ระบบสำรวจ ===================== */
function viewExplore(){
  const p = S.pet;
  if (!p) return `<div class="card"><div class="eyebrow">สำรวจ</div>
    <h2>ยังไม่มีวิญญาณที่จะส่งไป</h2>
    <div class="sub">ตอบคำถามให้ไข่ฟักก่อน แล้วค่อยออกสำรวจ</div></div>`;
  if (S.explore){
    const z = ZONES.find(x => x.id === S.explore.zone);
    const left = S.explore.endAt - Date.now();
    const done = left <= 0;
    const span = Math.max(1, z.min * 60000 * (1 - clamp(roomBonus().exploreFast, 0, .6)));
    const prog = clamp(1 - left / span, 0, 1);
    return `<div class="card">
      <div class="eyebrow">กำลังสำรวจ</div>
      <h2>${z.g} ${z.n}</h2>
      <div class="sub">${done ? `${esc(p.name)}กลับมาถึงบ้านแล้ว` : `เหลืออีก ${fmtLeft(left)}`}</div>
      <div class="gap"></div>
      <div class="bar xp" style="height:8px"><i style="width:${prog*100}%"></i></div>
      <div class="gap"></div>
      ${done ? `<button class="btn pri block" data-act="collect">รับของที่เก็บมา</button>`
             : `<button class="btn block" data-act="recall">เรียกกลับก่อน (ได้ของครึ่งเดียว)</button>`}
      <div class="tiny" style="margin-top:8px">ระหว่างสำรวจยังตอบคำถามต่อได้ตามปกติ เวลาเดินจริงแม้ปิดเกม</div>
    </div>`;
  }
  const busy = p.hp < 30 ? 'สุขภาพต่ำเกินไป ต้องรักษาก่อน' : (p.hunger < 10 ? 'หิวเกินกว่าจะออกไปไหน' : '');
  return `<div class="card">
    <div class="eyebrow">สำรวจ</div>
    <h2>ส่ง${esc(p.name)}ออกไปหาของ</h2>
    <div class="sub">${busy || 'เวลาเดินจริง ปิดเกมได้ กลับมาค่อยเก็บของ'}</div>
  </div>
  <div class="list">
    ${ZONES.map(z => {
      const lock = p.lv < z.lv;
      const ok = !lock && !busy;
      return `<div class="item">
        <div class="ic">${z.g}</div>
        <div class="grow"><b>${z.n}</b><div class="sub">${z.d}</div>
          <div class="tiny" style="margin-top:3px">${z.min} นาที · ความเสี่ยง ${Math.round(z.risk*100)}% · ต้อง Lv.${z.lv}</div></div>
        <button class="btn sm ${ok?'pri':''}" data-go="${z.id}" ${ok?'':'disabled'}>${lock?'ล็อก':'ส่งไป'}</button>
      </div>`;
    }).join('')}
  </div>`;
}

function startExplore(id){
  const z = ZONES.find(x => x.id === id);
  const fast = clamp(roomBonus().exploreFast, 0, .6);
  S.explore = { zone:id, endAt: Date.now() + Math.round(z.min * 60000 * (1 - fast)) };
  save(); render();
  toast(`${S.pet.name}ออกเดินทางไป${z.n}แล้ว`);
}

function collectExplore(half){
  const z = ZONES.find(x => x.id === S.explore.zone);
  const p = S.pet, b = roomBonus();
  S.explore = null;
  const luck = 1 + b.exploreLuck + liveStat(p,'LUK') / 120;
  const got = [];
  for (const [key, chance] of z.loot){
    if (Math.random() < chance * luck * (half ? .5 : 1)){
      const n = 1 + (Math.random() < .18 ? 1 : 0);
      addItem(key, n); got.push(`${ITEMS[key].n}${n>1?' ×'+n:''}`);
    }
  }
  const xp = Math.round(z.min * 2.2 * (half ? .5 : 1));
  const lv = gainXp(xp).levels;
  S.coins += Math.round(z.min * (half ? .6 : 1.2));
  p.hunger = clamp(p.hunger - z.min / 10, 0, 100);
  p.care.body += 1;

  let hurt = 0;
  const dodge = (liveStat(p,'AGI') + liveStat(p,'VIT')) / 200 + gearGuardBonus();
  let guarded = false;
  if (!half && Math.random() < Math.max(.02, z.risk - dodge)){
    if (S.guard > 0){ S.guard--; guarded = true; }
    else {
      hurt = Math.round(12 + Math.random() * 22);
      p.hp = clamp(p.hp - hurt, 1, 100);
      if (p.hp < 30) p.sick = true;
    }
  }
  save(); render();
  sheet(`<div class="eyebrow">กลับจาก${z.n}</div>
    <h2>${got.length ? 'เก็บของมาได้' : 'ไม่เจออะไรเลย'}</h2>
    <div class="sub">${got.length ? got.join(' · ') : 'บางวันก็เป็นแบบนี้ ลองใหม่คราวหน้า'}</div>
    <div class="gap"></div>
    <div class="list">
      <div class="item"><div class="ic">⭐</div><div class="grow"><b>ประสบการณ์ +${xp}</b>${lv?`<div class="sub">เลื่อนเป็น Lv.${p.lv}</div>`:''}</div></div>
      ${hurt?`<div class="item"><div class="ic">🩹</div><div class="grow"><b>บาดเจ็บ −${hurt} สุขภาพ</b><div class="sub">ใช้ยาหม่องหรือพาพักก่อนออกไปอีก</div></div></div>`:''}
      ${guarded?`<div class="item"><div class="ic">🍵</div><div class="grow"><b>ยาต้มบำรุงกำลังช่วยไว้</b><div class="sub">รอดจากการบาดเจ็บครั้งนี้ · เหลืออีก ${S.guard} ครั้ง</div></div></div>`:''}
    </div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="closeSheet">ปิด</button>`);
}

/* ===================== มินิเกม ===================== */
const RPS = [{k:'rock',n:'ค้อน',g:'✊'},{k:'paper',n:'กระดาษ',g:'✋'},{k:'sci',n:'กรรไกร',g:'✌️'}];
function playSheet(){
  const left = 8 - S.daily.plays;
  sheet(`<div class="eyebrow">เล่นด้วยกัน</div>
    <h2>เป่ายิงฉุบกับ${esc(S.pet.name)}</h2>
    <div class="sub">${left > 0 ? `วันนี้ยังได้รางวัลอีก ${left} ครั้ง` : 'วันนี้ครบโควตารางวัลแล้ว เล่นได้แต่ไม่ได้ของ'}</div>
    <div class="gap"></div>
    <div class="row" style="gap:8px">
      ${RPS.map(r => `<button class="btn grow" data-rps="${r.k}" style="font-size:calc(26px * var(--fs));padding:16px 0">${r.g}<div style="font-size:calc(12px * var(--fs))">${r.n}</div></button>`).join('')}
    </div>
    <div id="rpsout" class="gap"></div>
    <button class="btn block" data-act="closeSheet">พอแล้ว</button>`);
}
function doRps(k){
  const mine = RPS.find(r => r.k === k), theirs = pick(RPS);
  const beats = {rock:'sci', paper:'rock', sci:'paper'};
  const p = S.pet;
  let res, coin = 0;
  if (mine.k === theirs.k) res = 'เสมอ';
  else if (beats[mine.k] === theirs.k) res = 'คุณชนะ';
  else res = `${p.name}ชนะ`;
  p.care.play += 1;
  if (S.daily.plays < 8){
    S.daily.plays++;
    coin = res === 'เสมอ' ? 8 : (res === 'คุณชนะ' ? 18 : 12);
    S.coins += coin;
    p.mood = clamp(p.mood + 6, 0, 100);
    p.aff = clamp(p.aff + 1 * (1 + roomBonus().aff), 0, 100);
    gainXp(8);
  } else p.mood = clamp(p.mood + 2, 0, 100);
  const out = document.getElementById('rpsout');
  if (out) out.innerHTML = `<div class="item"><div class="ic">${theirs.g}</div>
    <div class="grow"><b>${res}</b><div class="sub">${p.name}ออก${theirs.n}${coin?` · เหรียญ +${coin} · อารมณ์ +6`:''}</div></div></div>`;
  save(); paintTop();
}

/* ===================== สวน ===================== */
function gardenSheet(){
  const g = S.garden || [], p = S.pet;
  const row = (pet, i) => {
    const sp = SPECIES[pet.sp];
    return `<div class="item">
      <div class="ic" style="background:${sp.dim};border-color:${sp.a(.4)}">${sp.g}</div>
      <div class="grow">
        <b>${esc(pet.name)}</b>
        <span class="pill" style="margin-left:6px;color:${RARITY[sp.rarity].c};border-color:${RARITY[sp.rarity].c}55">${RARITY[sp.rarity].star}</span>
        <div class="sub">${formName(pet.sp, pet.stage, pet.branch)} · Lv.${pet.lv}</div>
        <div class="tiny">พลังรวม ${petPower(pet)} · อิ่ม ${Math.round(pet.hunger)} · อารมณ์ ${Math.round(pet.mood)}</div>
      </div>
      ${i < 0 ? `<span class="pill">กำลังเลี้ยง</span>` : `<div style="text-align:right">
        <button class="btn sm pri" data-swap="${i}">สลับมาเลี้ยง</button>
        <div class="gap" style="height:4px"></div>
        <button class="btn sm danger" data-free="${i}">ปล่อย</button></div>`}
    </div>`;
  };
  sheet(`<div class="eyebrow">สวน · ${g.length + (p?1:0)}/${GARDEN_MAX}</div>
    <h2>วิญญาณที่คุณเลี้ยงอยู่</h2>
    <div class="sub">สลับตัวที่เลี้ยงได้ทุกเมื่อ ค่าสถานะของทุกตัวเดินตามเวลาจริง</div>
    <div class="gap"></div>
    <div class="list">${p?row(p,-1):''}${g.map((x,i) => row(x,i)).join('')}</div>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

/* ===================== ร้านผลึก / ตั้งค่า ===================== */
function eggMapSheet(){
  if (!S.egg) return toast('ยังไม่มีไข่ที่กำลังฟัก', 'bad');
  const m = eggMap();
  const bySubj = {};
  for (const u in UNITS) (bySubj[UNITS[u].subj] = bySubj[UNITS[u].subj] || []).push(u);
  sheet(`<div class="eyebrow">ผังธาตุประจำไข่ใบนี้</div>
    <h2>หน่วยไหนให้ธาตุอะไร</h2>
    <div class="sub">ไข่แต่ละใบสุ่มผังนี้ใหม่ทุกครั้ง ใบหน้าหน่วยเดิมอาจให้ธาตุคนละอย่าง</div>
    <div class="gap"></div>
    ${SUBJ_KEYS.map(k => `
      <div class="eyebrow" style="margin-top:10px">${SUBJECTS[k].g} ${SUBJECTS[k].n}</div>
      <div class="list">${(bySubj[k]||[]).map(u => {
        const el = m[u] || UNITS[u].el;
        const got = (S.egg.unit && S.egg.unit[u]) || 0;
        return `<div class="item">
          <div class="ic" style="background:hsla(${ELEMENTS[el].h},40%,50%,.25)">${ELEMENTS[el].g}</div>
          <div class="grow"><b style="font-size:calc(13.5px * var(--fs))">${UNITS[u].n}</b>
            <div class="tiny">ให้ธาตุ${ELEMENTS[el].n}${got?` · สะสมแล้ว ${got} คะแนน`:''}</div></div>
        </div>`;
      }).join('')}</div>`).join('')}
    <div class="gap"></div>
    <div class="tiny">เวลาฟักมีโอกาส ${Math.round(CHAOS_CHANCE*100)}% ที่ไข่จะแปรปรวน แล้วสุ่มธาตุเองโดยไม่สนผังนี้</div>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

function gearRow(kind, key, it){
  const owned = (S.owned[kind]||[]).includes(key);
  const equipped = S.equip[kind] === key;
  const stat = it.statKey ? `${it.statKey} +${it.statUp} · ` : '';
  const guard = it.guard ? ` · หลบบาดเจ็บ +${Math.round(it.guard*100)}%` : '';
  const hp = it.hp ? ` · เลือด +${it.hp}` : '';
  const pctLabel = kind === 'w' ? `โจมตี +${Math.round(it.atkPct*100)}%` : `เกราะ +${Math.round(it.defPct*100)}%`;
  return `<div class="item" style="${equipped?'border-color:'+TIER_COLOR[it.tier]+'88':''}">
    <div class="ic" style="background:${TIER_COLOR[it.tier]}22;border-color:${TIER_COLOR[it.tier]}55">${it.g}</div>
    <div class="grow">
      <b>${it.n}</b> <span class="pill" style="color:${TIER_COLOR[it.tier]};border-color:${TIER_COLOR[it.tier]}55">ระดับ${TIER_NAME[it.tier]}</span>
      <div class="tiny">${it.d}</div>
      <div class="tiny">${pctLabel} · ${stat}${hp}${guard}</div>
    </div>
    <div style="text-align:right">
      ${equipped ? `<span class="pill" style="color:var(--gold)">สวมอยู่</span>`
        : owned ? `<button class="btn sm pri" data-equip="${kind}:${key}">สวมใส่</button>`
        : `<button class="btn sm ${S.coins>=it.cost?'gold':''}" data-buyg="${kind}:${key}" ${S.coins>=it.cost?'':'disabled'}>${it.cost.toLocaleString('th-TH')}</button>`}
    </div>
  </div>`;
}

function gearSheet(){
  S.owned = S.owned || {w:[],a:[]}; S.equip = S.equip || {w:null,a:null};
  const wRows = Object.entries(WEAPONS).map(([k,it]) => gearRow('w', k, it)).join('');
  const aRows = Object.entries(ARMORS).map(([k,it]) => gearRow('a', k, it)).join('');
  sheet(`<div class="eyebrow">คลังอาวุธ · มี ${Math.floor(S.coins).toLocaleString('th-TH')} เหรียญ</div>
    <h2>อาวุธและเครื่องแต่งกาย</h2>
    <div class="sub">สวมได้อย่างละหนึ่งชิ้น สลับได้ฟรีเมื่อซื้อแล้ว มีผลเฉพาะตอนดวลปริศนา ส่วนเกราะยังช่วยลดโอกาสบาดเจ็บตอนสำรวจด้วย</div>
    <div class="gap"></div>
    ${S.equip.w||S.equip.a ? `<button class="btn sm block" data-act="unequipAll">ถอดทั้งหมด</button><div class="gap" style="height:8px"></div>` : ''}
    <div class="eyebrow">⚔️ อาวุธ</div>
    <div class="list">${wRows}</div>
    <div class="gap"></div>
    <div class="eyebrow">🛡️ เครื่องแต่งกาย</div>
    <div class="list">${aRows}</div>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

function crystalSheet(){
  sheet(`<div class="eyebrow">ร้านผลึกสมาธิ · มีอยู่ ${Math.floor(S.crystals)} ผลึก</div>
    <h2>ของที่แลกด้วยความรู้เท่านั้น</h2>
    <div class="sub">ผลึกได้จากการตอบถูก ทุก 4 ข้อได้ 1 ผลึก และตอบถูกทั้งรอบได้เพิ่มอีก 2 ซื้อด้วยเหรียญไม่ได้</div>
    <div class="gap"></div>
    <div class="list">${CRYSTAL_SHOP.map(row => {
      const it = ITEMS[row.k];
      return `<div class="item">
        <div class="ic">${it.g}</div>
        <div class="grow"><b>${it.n}</b><div class="sub">${it.d}</div></div>
        <button class="btn sm ${S.crystals>=row.cost?'gold':''}" data-cbuy="${row.k}" ${S.crystals>=row.cost?'':'disabled'}>${row.cost}</button>
      </div>`;
    }).join('')}</div>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

function settingsSheet(){
  sheet(`<div class="eyebrow">ตั้งค่า</div><h2>บัญชีและเซฟ</h2>
    <div class="sub">รหัสบัญชี ${S.uid} · เริ่มเล่น ${fmtDate(S.created)} · เวอร์ชัน ${VERSION}</div>
    <div class="tiny" style="margin-top:4px">ห้องเรียนไร้ขีดจำกัด #ห้องเรียนครูชัช</div>
    <div class="gap"></div>
    <div class="list">
      <div class="item"><div class="ic">⏱️</div>
        <div class="grow"><b>จับเวลาแต่ละข้อ</b><div class="sub">ปิดไว้ถ้าอยากให้ค่อยๆ คิด จะไม่ได้โบนัสความเร็ว</div></div>
        <button class="btn sm ${S.settings.timed?'on':''}" data-act="togTimed">${S.settings.timed?'เปิด':'ปิด'}</button></div>
      <div class="item"><div class="ic">🔀</div>
        <div class="grow"><b>สลับตำแหน่งตัวเลือก</b><div class="sub">กันการจำว่าเฉลยอยู่ข้อไหน</div></div>
        <button class="btn sm ${S.settings.shuffle?'on':''}" data-act="togShuf">${S.settings.shuffle?'เปิด':'ปิด'}</button></div>
    </div>
      <div class="item"><div class="ic">🧭</div>
        <div class="grow"><b>สอนเล่น</b><div class="sub">${S.tutor && !S.tutor.off && S.tutor.step < TUTOR_STEPS.length ? 'กำลังอยู่ขั้นที่ ' + (S.tutor.step+1) + ' จาก ' + TUTOR_STEPS.length : 'จบแล้ว เปิดทุกอย่างให้ใช้ได้'}</div></div>
        <button class="btn sm" data-act="tutorAgain">เริ่มใหม่</button></div>
      <div class="item"><div class="ic">☁️</div>
        <div class="grow"><b>เซฟข้ามเครื่อง</b><div class="sub">${S.cloud && S.cloud.sid ? 'รหัส ' + esc(S.cloud.sid) : 'เก็บความคืบหน้าไว้บนคลาวด์ของครู'}</div></div>
        <button class="btn sm" data-act="cloud">${S.cloud && S.cloud.sid ? 'จัดการ' : 'ตั้งค่า'}</button></div>
      <div class="item"><div class="ic">🔠</div>
        <div class="grow"><b>ขนาดตัวอักษร</b><div class="sub">ปรับให้อ่านง่ายบนหน้าจอเล็ก</div></div>
        <button class="btn sm" data-act="fontsize">${(FS_STEPS.find(x=>Math.abs(x.v-((S.settings&&S.settings.fs)||1))<0.001)||{d:'100%'}).d}</button></div>
      <div class="item"><div class="ic">🎓</div>
        <div class="grow"><b>ระดับชั้นของฉัน</b><div class="sub">ใช้เป็นค่าเริ่มต้นเวลาเปิดหน้าตอบคำถาม</div></div>
        <span class="pill">${GRADES[S.grade].n}</span></div>
    </div>
    <div class="gap"></div>
    <button class="btn block" data-act="export">ดาวน์โหลดไฟล์เซฟ</button>
    <div class="gap"></div>
    <button class="btn block" data-act="import">โหลดไฟล์เซฟ</button>
    <hr class="sep">
    <button class="btn danger block" data-act="wipe">เริ่มใหม่ทั้งหมด</button>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

/* ===================== การกระทำ ===================== */
function bindView(){
  view().querySelectorAll('[data-subj]').forEach(b => b.onclick = () => { QUIZ.subj = b.dataset.subj; render(); });
  view().querySelectorAll('[data-grade]').forEach(b => b.onclick = () => {
    QUIZ.grade = b.dataset.grade; S.grade = b.dataset.grade;
    const ok = subjectsReady(S.grade);
    if (QUIZ.subj !== 'mix' && !ok.includes(QUIZ.subj)) QUIZ.subj = 'mix';
    save(); render();
  });
  view().querySelectorAll('[data-ans]').forEach(b => b.onclick = () => answerQuestion(+b.dataset.ans));
  view().querySelectorAll('[data-dans]').forEach(b => b.onclick = () => duelAnswer(+b.dataset.dans));
  view().querySelectorAll('[data-mtap]').forEach(b => b.onclick = () => {
    const [side, id] = b.dataset.mtap.split(':');
    matchTap(side, +id);
  });
  view().querySelectorAll('[data-go]').forEach(b => b.onclick = () => startExplore(b.dataset.go));
  view().querySelectorAll('[data-bookel]').forEach(b => b.onclick = () => { BOOKEL = b.dataset.bookel; render(); });
  view().querySelectorAll('[data-card]').forEach(b => b.onclick = () => sheet(cardSheet(b.dataset.card)));
  view().querySelectorAll('[data-use]').forEach(b => b.onclick = () => {
    const r = useItem(b.dataset.use);
    if (!r) return;
    if (r.err) return toast(r.err, 'bad');
    if (r.egg) return openEgg(b.dataset.use);
    toast(r.msg); save(); render();
    if (ITEMS[b.dataset.use] && ITEMS[b.dataset.use].t === 'food') setTimeout(() => tutorDone('feed'), 80);
  });
  view().querySelectorAll('[data-sell]').forEach(b => b.onclick = () => {
    const k = b.dataset.sell, it = ITEMS[k];
    if (!(S.bag[k] > 0)) return;
    S.bag[k]--; if (!S.bag[k]) delete S.bag[k];
    S.coins += it.sell;
    toast(`ขาย${it.n} ได้ ${it.sell} เหรียญ`); save(); render();
  });
  view().querySelectorAll('[data-buy]').forEach(b => b.onclick = () => {
    const k = b.dataset.buy, price = +b.dataset.price;
    if (S.coins < price) return toast('เหรียญไม่พอ', 'bad');
    S.coins -= price; addItem(k);
    toast(`ซื้อ${ITEMS[k].n}แล้ว`); save(); render();
  });
  view().querySelectorAll('[data-buyf]').forEach(b => b.onclick = () => {
    const k = b.dataset.buyf, f = FURN[k];
    if (S.coins < f.cost) return toast('เหรียญไม่พอ', 'bad');
    const slot = S.room.indexOf(null);
    if (slot < 0) return toast('ห้องเต็มแล้ว เก็บของบางชิ้นออกก่อน', 'bad');
    S.coins -= f.cost; S.room[slot] = k;
    toast(`วาง${f.n}ไว้ในห้องแล้ว`); save(); render();
  });
  view().querySelectorAll('[data-slot]').forEach(b => b.onclick = () => {
    const i = +b.dataset.slot;
    if (S.room[i]){
      const f = FURN[S.room[i]];
      S.room[i] = null;
      S.coins += Math.round(f.cost * .5);
      toast(`เก็บ${f.n} คืนมา ${Math.round(f.cost*.5)} เหรียญ`); save(); render();
    } else toast('ซื้อของจากร้านด้านล่างเพื่อวางลงช่องนี้');
  });
  /* ปุ่มไปทำภารกิจในหน้าหลัก ล็อกวิชากับหน่วยให้ตรงกับภารกิจนั้น */
  view().querySelectorAll('[data-mqgo]').forEach(b => b.onclick = () => {
    const [subj, grade, unit] = b.dataset.mqgo.split(':');
    S.grade = grade; QUIZ.grade = grade; QUIZ.subj = subj; QUIZ.unit = unit;
    save(); render();
    toast(`ล็อกไว้ที่${UNITS[unit].n}แล้ว กดเริ่มรอบได้เลย`, 'gold');
  });
  view().querySelectorAll('[data-act]').forEach(b => b.onclick = () => act(b.dataset.act));
}

document.getElementById('fsbtn').addEventListener('click', fsSheet);

document.getElementById('sheet').addEventListener('click', e => {
  const b = e.target.closest('[data-mqgo],[data-mgo],[data-mgrade],[data-msubj],[data-dpick],[data-qlint2],[data-buyg],[data-equip],[data-dgrade],[data-dsubj],[data-fs],[data-act],[data-rps],[data-feed],[data-swap],[data-free],[data-freeyes],[data-cbuy],[data-qlist],[data-qdel],[data-pick]');
  if (!b) return;
  if (b.dataset.fs) return setFS(+b.dataset.fs);
  if (b.dataset.buyg){
    const [kind, key] = b.dataset.buyg.split(':');
    const r = buyGear(kind, key);
    if (r.err) return toast(r.err, 'bad');
    save(); paintTop();
    toast(`ซื้อ${(kind==='w'?WEAPONS:ARMORS)[key].n}แล้ว`, 'gold');
    return gearSheet();
  }
  if (b.dataset.equip){
    const [kind, key] = b.dataset.equip.split(':');
    equipGear(kind, key);
    save(); render();
    toast(`สวมใส่${(kind==='w'?WEAPONS:ARMORS)[key].n}แล้ว`);
    return gearSheet();
  }
  if (b.dataset.dgrade){ QUIZ.grade = b.dataset.dgrade; S.grade = b.dataset.dgrade; save(); return duelPasteSheet(); }
  if (b.dataset.dsubj){ DUEL.subj = b.dataset.dsubj; return duelPasteSheet(); }
  if (b.dataset.rps) return doRps(b.dataset.rps);
  if (b.dataset.pick !== undefined && b.dataset.pick !== ''){ QADD_ANS = +b.dataset.pick; return markPick(); }
  if (b.dataset.qlist) return qlistSheet(b.dataset.qlist);
  if (b.dataset.qlint2) return qlintSheet(b.dataset.qlint2);
  if (b.dataset.dpick) return duelStartWith(+b.dataset.dpick);
  if (b.dataset.mgrade){ QUIZ.grade = b.dataset.mgrade; S.grade = b.dataset.mgrade; save(); return matchIntroSheet(); }
  if (b.dataset.msubj){ MATCH.subj = b.dataset.msubj; return matchIntroSheet(); }
  if (b.dataset.mqgo){
    const [subj, grade, unit] = b.dataset.mqgo.split(':');
    S.grade = grade; QUIZ.grade = grade; QUIZ.subj = subj; QUIZ.unit = unit;
    save(); render();
    return toast(`ล็อกไว้ที่${UNITS[unit].n}แล้ว กดเริ่มรอบได้เลย`, 'gold');
  }
  if (b.dataset.mgo){
    closeSheet();
    TAB = 'match';
    document.querySelectorAll('#tabs button').forEach(x => x.classList.remove('on'));
    return matchStart(b.dataset.mgo, MATCH.subj, QUIZ.grade || S.grade);
  }
  if (b.dataset.qdel){
    const id = b.dataset.qdel;
    if (id.startsWith('c')){ S.qcustom = (S.qcustom||[]).filter(q => q.id !== id); toast('ลบคำถามแล้ว'); }
    else { S.qoff = S.qoff || {}; S.qoff[id] = 1; toast('ปิดคำถามนี้แล้ว'); }
    save(); render();
    const q = QBANK_BUILTIN.concat(S.qcustom||[]).find(x => x.id === id);
    return qlistSheet(q ? q.subj : SUBJ_KEYS[0]);
  }
  if (b.dataset.cbuy){
    const row = CRYSTAL_SHOP.find(x => x.k === b.dataset.cbuy);
    if (S.crystals < row.cost) return toast('ผลึกสมาธิไม่พอ', 'bad');
    S.crystals -= row.cost; addItem(row.k);
    save(); paintTop(); toast(`แลก${ITEMS[row.k].n}แล้ว`, 'gold');
    return crystalSheet();
  }
  if (b.dataset.feed){
    const r = useItem(b.dataset.feed);
    if (r && r.err) return toast(r.err, 'bad');
    if (r) toast(r.msg);
    closeSheet(); save(); render();
    if (r && !r.err) setTimeout(() => tutorDone('feed'), 80);
    return;
  }
  if (b.dataset.swap !== undefined && b.dataset.swap !== ''){
    swapWith(+b.dataset.swap); save(); closeSheet(); render();
    return toast(`สลับมาเลี้ยง${S.pet.name}แล้ว`);
  }
  if (b.dataset.free !== undefined && b.dataset.free !== ''){
    const i = +b.dataset.free, nm = S.garden[i] && S.garden[i].name;
    return sheet(`<h2>ปล่อย${esc(nm)}</h2>
      <div class="sub">ตัวนี้จะกลับสู่ป่าถาวร เลเวลและค่าสถานะจะหายไป แต่ร่างที่เคยพบยังอยู่ในสมุดสะสม</div>
      <div class="gap"></div>
      <button class="btn danger block" data-freeyes="${i}">ปล่อยไป</button>
      <div class="gap"></div>
      <button class="btn pri block" data-act="garden">ไม่ปล่อย</button>`);
  }
  if (b.dataset.freeyes !== undefined && b.dataset.freeyes !== ''){
    const pet = releasePet(+b.dataset.freeyes);
    S.coins += 60 + pet.lv * 8;
    save(); toast(`ปล่อย${pet.name}กลับป่า ได้ ${60 + pet.lv*8} เหรียญ`);
    return gardenSheet();
  }
  act(b.dataset.act);
});

function act(a){
  const p = S.pet;
  if (a === 'closeSheet'){
    closeSheet();
    if (TAB === 'match' && !MATCH.running){
      TAB = 'quiz';
      document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x.dataset.tab === 'quiz'));
      render();
      return;
    }
    if (TAB === 'duel' && !DUEL.running){
      TAB = 'pot';
      document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x.dataset.tab === 'pot'));
      render();
    }
    return;
  }
  if (a === 'goQuiz'){
    TAB = 'quiz';
    document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x.dataset.tab === 'quiz'));
    return render();
  }
  if (a === 'goQuizStart'){ closeSheet(); act('goQuiz'); return; }
  if (a === 'tutorBegin'){ S.tutor.started = true; save(); closeSheet(); applyTabLock(); act('goQuiz'); return; }
  if (a === 'tutorSkip') return tutorSkipSheet();
  if (a === 'tutorSkipYes'){
    S.tutor.off = true; save(); closeSheet(); applyTabLock(); render();
    return toast('เปิดทุกอย่างให้แล้ว');
  }
  if (a === 'tutorAgain'){
    S.tutor = { step:0, off:false, started:true, at:Date.now() };
    save(); closeSheet(); applyTabLock(); render();
    return toast('เริ่มสอนเล่นใหม่ตั้งแต่ต้น');
  }
  if (a === 'unlockUnit'){ QUIZ.unit = null; render(); return toast('กลับมาตอบทุกหน่วยแล้ว'); }
  if (a === 'startQuiz') return startQuiz();
  if (a === 'nextQ') return advanceQuiz();
  if (a === 'quitQuiz'){
    return sheet(`<h2>ออกจากรอบนี้</h2>
      <div class="sub">คะแนนที่ทำได้ ${QUIZ.pts} จะถูกเก็บตามปกติ แต่จะไม่ได้โบนัสตอบถูกทั้งรอบ</div>
      <div class="gap"></div>
      <button class="btn danger block" data-act="quitYes">ออก</button>
      <div class="gap"></div>
      <button class="btn pri block" data-act="closeSheet">ตอบต่อ</button>`);
  }
  if (a === 'quitYes'){ closeSheet(); return finishQuiz(); }
  if (a === 'hatch'){ closeSheet(); tutorDone('hatch', true); return doHatch(); }
  if (a === 'qbank') return qbankSheet();
  if (a === 'qadd') return qaddSheet();
  if (a === 'qsave') return qsave();
  if (a === 'qlint') return qlintSheet('all');
  if (a === 'qimport') return qimportSheet();
  if (a === 'qdoimport') return qdoimport();
  if (a === 'qexport') return qexport();
  if (a === 'fontsize') return fsSheet();
  if (a === 'cloud'){ closeSheet(); return cloudSheet(); }
  if (a === 'cloudSaveSet') return cloudSaveSettings();
  if (a === 'cloudUp'){
    return saveGameToCloud().then(r => {
      if (r.err) return toast(r.err, 'bad');
      toast('ส่งขึ้นคลาวด์เรียบร้อย', 'gold');
      cloudSheet();
    });
  }
  if (a === 'cloudDown') return cloudDownloadFlow();
  if (a === 'cloudApply'){
    if (!CLOUD_PENDING) return toast('ไม่พบข้อมูลที่จะดึง', 'bad');
    const inc = CLOUD_PENDING; CLOUD_PENDING = null;
    closeSheet();
    return applyCloudSave(inc).then(() => toast('ดึงข้อมูลจากคลาวด์แล้ว', 'gold'));
  }
  if (a === 'cloudAuto'){
    S.cloud.auto = !S.cloud.auto; save();
    toast(S.cloud.auto ? 'จะส่งขึ้นคลาวด์ให้อัตโนมัติ' : 'ปิดการส่งอัตโนมัติแล้ว');
    return cloudSheet();
  }
  if (a === 'duel'){ closeSheet(); return duelSheet(); }
  if (a === 'duelMine') return duelMineSheet();
  if (a === 'duelPaste') return duelPasteSheet();
  if (a === 'duelCopy'){
    const el = document.getElementById('duelOut');
    if (!el) return;
    el.select(); el.setSelectionRange(0, 99999);
    try { document.execCommand('copy'); } catch(e){}
    if (navigator.clipboard) navigator.clipboard.writeText(el.value).catch(()=>{});
    return toast('คัดลอกรหัสแล้ว ส่งให้เพื่อนได้เลย', 'gold');
  }
  if (a === 'duelGo'){
    const raw = (document.getElementById('duelIn') || {}).value || '';
    const r = readDuelCode(raw);
    if (!r.ok) return toast(r.err, 'bad');
    const g = QUIZ.grade || S.grade;
    if (!questionsBy(DUEL.subj, g).length) return toast('วิชานี้ยังไม่มีคำถามในระดับชั้นที่เลือก', 'bad');
    return duelPickSheet(r.foe);
  }
  if (a === 'duelNext') return duelAdvance();
  if (a === 'elchart') return elChartSheet();
  if (a === 'match'){ closeSheet(); return matchIntroSheet(); }
  if (a === 'mqSync'){
    toast('กำลังดึงภารกิจจากครู…');
    return fetchTeacherMissions().then(r => {
      if (r.err) return toast(r.err, 'bad');
      render();
      toast(r.n ? `ได้ภารกิจจากครู ${r.n} รายการ` : 'ตอนนี้ครูยังไม่ได้สั่งภารกิจ', r.n ? 'gold' : '');
    });
  }
  if (a === 'matchNext'){ closeSheet(); return matchLoadSet(); }
  if (a === 'matchQuit'){
    clearInterval(MATCH.tickId); MATCH.running = false;
    TAB = 'quiz';
    document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x.dataset.tab === 'quiz'));
    render();
    return toast('ออกจากโหมดจับคู่แล้ว');
  }
  if (a === 'duelQuit'){
    return sheet(`<h2>ยอมแพ้</h2><div class="sub">การดวลจะจบทันทีและนับเป็นแพ้</div>
      <div class="gap"></div><button class="btn danger block" data-act="duelQuitYes">ยอมแพ้</button>
      <div class="gap"></div><button class="btn pri block" data-act="closeSheet">สู้ต่อ</button>`);
  }
  if (a === 'duelQuitYes'){ closeSheet(); DUEL.hp = 0; return duelFinish(); }
  if (a === 'eggmap') return eggMapSheet();
  if (a === 'garden') return gardenSheet();
  if (a === 'crystal') return crystalSheet();
  if (a === 'gear') return gearSheet();
  if (a === 'unequipAll'){ S.equip = {w:null,a:null}; save(); return gearSheet(); }
  if (a === 'settings') return settingsSheet();
  if (a === 'togTimed'){ S.settings.timed = !S.settings.timed; save(); return settingsSheet(); }
  if (a === 'togShuf'){ S.settings.shuffle = !S.settings.shuffle; save(); return settingsSheet(); }
  if (a === 'feed'){
    const foods = Object.keys(S.bag).filter(k => ITEMS[k] && ITEMS[k].t === 'food' && S.bag[k] > 0);
    if (!foods.length) return toast('ไม่มีอาหารเลย ซื้อได้ที่กระเป๋า', 'bad');
    return sheet(`<div class="eyebrow">ให้อาหาร</div><h2>จะให้อะไรดี</h2><div class="gap"></div>
      <div class="list">${foods.map(k => `<button class="item" data-feed="${k}" style="text-align:left;width:100%">
        <div class="ic">${ITEMS[k].g}</div>
        <div class="grow"><b>${ITEMS[k].n}</b><div class="sub">อิ่ม +${ITEMS[k].hunger} · อารมณ์ +${ITEMS[k].mood}</div></div>
        <span class="qty">×${S.bag[k]}</span></button>`).join('')}</div>
      <div class="gap"></div><button class="btn block" data-act="closeSheet">ปิด</button>`);
  }
  if (a === 'play') return playSheet();
  if (a === 'rest'){
    const gap = Date.now() - (S.lastRest || 0);
    if (gap < 1800000) return toast(`เพิ่งพักไป ลองอีกครั้งใน ${fmtLeft(1800000-gap)}`, 'bad');
    S.lastRest = Date.now();
    p.mood = clamp(p.mood + 8, 0, 100);
    p.hp = clamp(p.hp + 6, 0, 100);
    p.care.body += 1;
    View.bounce = -12; setTimeout(()=>{ View.bounce = 0; }, 260);
    toast(`${p.name}ได้พักแล้ว อารมณ์ +8 สุขภาพ +6`);
    save(); return render();
  }
  if (a === 'evolve'){
    const nm = doEvolve();
    if (!nm) return toast('ยังไม่ครบเงื่อนไข', 'bad');
    toast(`วิวัฒนาการเป็น ${nm}`, 'gold');
    save(); render();
    return sheet(`<div class="eyebrow">วิวัฒนาการ</div><h2>${nm}</h2>
      <div class="sub">${SPECIES[p.sp].desc}</div><div class="gap"></div>
      <div style="text-align:center">${sigilSVG(S.uid + currentFormId(), SPECIES[p.sp].accent, 88)}</div>
      <div class="tiny" style="text-align:center">การ์ดใบใหม่ถูกบันทึกลงสมุดสะสมแล้ว · ${collectCode(currentFormId())}</div>
      <div class="gap"></div><button class="btn pri block" data-act="closeSheet">ดีมาก</button>`);
  }
  if (a === 'collect') return collectExplore(false);
  if (a === 'recall') return collectExplore(true);
  if (a === 'rename'){
    return sheet(`<div class="eyebrow">เปลี่ยนชื่อ</div><h2>จะเรียกว่าอะไรดี</h2><div class="gap"></div>
      <input id="nameIn" maxlength="14" value="${esc(p.name)}" class="fld">
      <button class="btn pri block" data-act="saveName">บันทึกชื่อ</button>`);
  }
  if (a === 'saveName'){
    setTimeout(() => tutorDone('name'), 60);
    const el = document.getElementById('nameIn');
    const v = (el && el.value || '').trim();
    if (v && S.pet) S.pet.name = v.slice(0,14);
    closeSheet(); save(); return render();
  }
  if (a === 'export'){
    const blob = new Blob([JSON.stringify(S)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a2 = document.createElement('a');
    a2.href = url; a2.download = `kruchat-save-${S.uid}.json`; a2.click();
    setTimeout(()=>URL.revokeObjectURL(url), 1000);
    return toast('ดาวน์โหลดไฟล์เซฟแล้ว');
  }
  if (a === 'import'){
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'application/json';
    inp.onchange = () => {
      const f = inp.files[0]; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        try {
          const d = JSON.parse(rd.result);
          S = Object.assign(freshSave(), d);
          crackle = null; buildCrackle(hashStr(S.uid));
          save(); closeSheet(); render(); toast('โหลดเซฟเรียบร้อย');
        } catch(e){ toast('ไฟล์นี้อ่านไม่ได้', 'bad'); }
      };
      rd.readAsText(f);
    };
    inp.click();
    return;
  }
  if (a === 'wipe'){
    return sheet(`<h2>เริ่มใหม่ทั้งหมด</h2>
      <div class="sub">สมุดสะสม สวน คลังคำถามที่เพิ่มเอง และวิญญาณทุกตัวจะหายไปถาวร</div>
      <div class="gap"></div>
      <button class="btn danger block" data-act="wipeYes">ลบและเริ่มใหม่</button>
      <div class="gap"></div><button class="btn pri block" data-act="closeSheet">ไม่ลบ</button>`);
  }
  if (a === 'wipeYes'){
    S = freshSave(); crackle = null; buildCrackle(hashStr(S.uid));
    startEgg(1); save(); closeSheet(); render(); return intro();
  }
}

/* ===================== ขนาดตัวอักษร ===================== */
const FS_STEPS = [
  {v:0.9,  n:'เล็ก',      d:'90%'},
  {v:1.0,  n:'ปกติ',      d:'100%'},
  {v:1.15, n:'ใหญ่',      d:'115%'},
  {v:1.3,  n:'ใหญ่มาก',   d:'130%'},
  {v:1.5,  n:'ใหญ่พิเศษ', d:'150%'},
];
function applyFS(){
  const v = (S && S.settings && S.settings.fs) || 1;
  document.documentElement.style.setProperty('--fs', v);
}
function setFS(v){
  S.settings.fs = v;
  applyFS(); save();
  const box = document.getElementById('fsopts');
  if (box) box.querySelectorAll('[data-fs]').forEach(b =>
    b.classList.toggle('on', Math.abs(+b.dataset.fs - v) < 0.001));
  const now = document.getElementById('fsnow');
  if (now) now.textContent = (FS_STEPS.find(x => Math.abs(x.v - v) < 0.001) || {d:Math.round(v*100)+'%'}).d;
}
function fsSheet(){
  const cur = (S.settings && S.settings.fs) || 1;
  sheet(`<div class="eyebrow">ขนาดตัวอักษร</div>
    <h2>ปรับให้อ่านสบายตา</h2>
    <div class="sub">ตอนนี้ <span id="fsnow">${(FS_STEPS.find(x=>Math.abs(x.v-cur)<0.001)||{d:Math.round(cur*100)+'%'}).d}</span> · ตัวอย่างด้านล่างจะเปลี่ยนตามทันที</div>
    <div class="gap"></div>
    <div class="fsrow" id="fsopts">
      ${FS_STEPS.map(x => `<button class="fsopt ${Math.abs(x.v-cur)<0.001?'on':''}" data-fs="${x.v}">
        <b style="font-size:${Math.round(13*x.v)}px">ก</b><span>${x.n}</span></button>`).join('')}
    </div>
    <div class="gap"></div>
    <div class="fspreview">
      <div class="q">กรุงศรีอยุธยาสถาปนาขึ้นในปีใด</div>
      <div class="c"><span class="k">ก</span><span>พ.ศ. 1781</span></div>
      <div class="c"><span class="k">ข</span><span>พ.ศ. 1893</span></div>
    </div>
    <div class="gap"></div>
    <div class="tiny">ค่านี้จะถูกจำไว้ในเครื่องนี้ เปิดเกมครั้งหน้าก็ยังเป็นขนาดเดิม · ถ้ายังเล็กไป ใช้การซูมของเบราว์เซอร์เพิ่มได้อีก</div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="closeSheet">เรียบร้อย</button>`);
}

/* ===================== เริ่มระบบ ===================== */
function intro(){
  sheet(`<div class="eyebrow">ห้องเรียนไร้ขีดจำกัด · #ห้องเรียนครูชัช</div>
    <h2>มีไข่ใบหนึ่งอยู่ในกระถาง</h2>
    <div class="sub">ยังไม่มีใครรู้ว่าข้างในเป็นอะไร เพราะมันยังไม่ถูกกำหนด</div>
    <div class="gap"></div>
    <div class="list">
      <div class="item"><div class="ic">❓</div><div class="grow"><b>ตอบคำถามเพื่อฟักไข่</b>
        <div class="sub">ตอบถูกได้คะแนน ตอบเร็วได้โบนัส ตอบถูกติดกันได้ตัวคูณถึง ×2</div></div></div>
      <div class="item"><div class="ic">🎨</div><div class="grow"><b>หน่วยที่เรียนกำหนดธาตุ</b>
        <div class="sub">ตอบหน่วยพัฒนาการของอาณาจักรมาก ไข่จะเอนไปทางธาตุดิน ตอบหน่วยบุคคลสำคัญมากจะเอนไปทางธาตุไฟ ดูเปอร์เซ็นต์สดได้ที่หน้ากระถาง</div></div></div>
      <div class="item"><div class="ic">🌱</div><div class="grow"><b>เลี้ยงต่อให้โต</b>
        <div class="sub">มี 32 สายพันธุ์ 320 ร่างให้เก็บ วิธีดูแลจะกำหนดว่ามันจะแตกสายไปทางไหน</div></div></div>
    </div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="goQuizStart">เริ่มตอบคำถาม</button>`);
}

let saveTimer = null;
function save(){
  if (!S) return;
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { S.savedAt = Date.now(); Store.set(SAVEKEY, JSON.stringify(S)); }, 250);
}

/* ปรับโครงสร้างเซฟให้ครบถ้วน ใช้ทั้งตอนเปิดเกมและตอนกู้เซฟจากคลาวด์ */
function migrateSave(){
  if (!Array.isArray(S.room)) S.room = [];
  while (S.room.length < ROOM_SLOTS) S.room.push(null);
  if (S.room.length > ROOM_SLOTS) S.room = S.room.slice(0, ROOM_SLOTS);
  if (typeof S.guard !== 'number') S.guard = 0;
  if (typeof S.boost !== 'number') S.boost = 0;
  if (typeof S.mopDay !== 'string') S.mopDay = '';
  if (!S.settings || typeof S.settings.timed === 'undefined') S.settings = {timed:true, shuffle:true, fs:1};
  if (typeof S.settings.fs !== 'number' || !(S.settings.fs > 0)) S.settings.fs = 1;
  applyFS();
  if (!S.stats || typeof S.stats.answered === 'undefined')
    S.stats = {answered:0, correct:0, points:0, rounds:0, best:0, streak:0, bestStreak:0, lastDay:''};
  S.qcustom = S.qcustom || [];
  S.qoff = S.qoff || {};
  S.qstate = S.qstate || {};
  S.garden = S.garden || [];
  S.seen = S.seen || {};
  S.prog = S.prog || {};
  S.duel = S.duel || { win:0, lose:0, draw:0, day:'', today:0 };
  S.cloud = S.cloud || { url:'', sid:'', auto:false, lastUp:0, lastDown:0 };
  if (typeof S.savedAt !== 'number') S.savedAt = 0;
  S.sleep = S.sleep || { on:false, since:0, woke:0 };
  S.match = S.match || { plays:0, best:0 };
  S.mq = S.mq || { day:'', list:[], done:[] };
  S.teacherMq = S.teacherMq || [];
  if (typeof S.mqGauge !== 'boolean') S.mqGauge = false;
  S.tutor = S.tutor || { step:0, off:false, started:false, at:0 };
  /* เด็กที่เคยเล่นมาก่อนระบบนี้จะมี pet อยู่แล้ว ไม่ต้องสอนซ้ำ */
  if (!S.tutor.started && S.pet) S.tutor.off = true;
  S.owned = S.owned || { w:[], a:[] };
  S.equip = S.equip || { w:null, a:null };
  if (!S.grade || !GRADES[S.grade]) S.grade = (gradesReady()[0] || 'p5');
  QUIZ.grade = S.grade;
}

async function boot(){
  const raw = await Store.get(SAVEKEY);
  if (raw){
    try { S = Object.assign(freshSave(), JSON.parse(raw)); }
    catch(e){ S = freshSave(); }
  } else S = freshSave();

  migrateSave();
  checkSleep();
  applyTabLock();

  buildCrackle(hashStr(S.uid));
  tickOffline();

  const firstTime = !S.pet && !S.egg;
  if (firstTime) startEgg(1);
  render();
  /* เด็กใหม่เจอหน้าต้อนรับของระบบสอนเล่น เด็กเก่าเจอหน้าแนะนำเดิม */
  if (firstTime){
    if (S.tutor && !S.tutor.started && !S.tutor.off) welcomeSheet();
    else intro();
  }

  setInterval(() => {
    if (QUIZ.running) return;
    tickOffline(); paintTop();
    if (TAB === 'explore' && S.explore) render();
    save();
  }, 20000);
}

/* จุดเข้าถึงสถานะสำหรับตรวจสอบ */
window.__game = () => ({ S, QUIZ, DUEL, MATCH, TAB, VERSION });

boot();

/* ===================== ตรวจคุณภาพข้อสอบ ===================== */
/* ตรวจว่าเฉลยยาวกว่าตัวลวงจนเดาได้โดยไม่ต้องอ่าน */
function lintQuestion(q){
  const flags = [];
  const ans = q.ch[q.ans];
  const others = q.ch.filter((c,i) => i !== q.ans);
  const maxOther = Math.max(...others.map(c => c.length));
  const ratio = maxOther > 0 ? ans.length / maxOther : 99;
  const diff = ans.length - maxOther;

  if (ratio > 1.6 && diff >= 12) flags.push({lv:2, t:`เฉลยยาวกว่าตัวลวงที่ยาวที่สุด ${diff} ตัวอักษร (${ratio.toFixed(1)} เท่า)`});
  else if (ratio > 1.3 && diff >= 8) flags.push({lv:1, t:`เฉลยยาวกว่าตัวลวงเล็กน้อย ${diff} ตัวอักษร`});

  // ตัวลวงที่สั้นผิดปกติเมื่อเทียบกับเพื่อน
  const avgOther = others.reduce((a,c)=>a+c.length,0) / others.length;
  if (ans.length > avgOther * 2 && ans.length - avgOther >= 15)
    flags.push({lv:2, t:'เฉลยยาวกว่าค่าเฉลี่ยของตัวลวงเกินสองเท่า'});

  // คำที่มักโผล่เฉพาะในตัวลวง
  const giveaway = ['ไม่มีผลใดๆ','ไม่เกี่ยวข้องกันเลย','ครูสั่ง','ไม่มีประโยชน์ใดๆ','ทุกประการ'];
  const inAns = giveaway.filter(w => ans.includes(w));
  const inOther = giveaway.filter(w => others.some(c => c.includes(w)));
  if (inOther.length && !inAns.length)
    flags.push({lv:1, t:`ตัวลวงใช้คำที่ส่อว่าผิดชัดเจน เช่น "${inOther[0]}"`});

  return {flags, ratio, diff, worst: flags.reduce((m,f)=>Math.max(m,f.lv),0)};
}

function lintReport(list){
  let longest = 0, lv2 = 0, lv1 = 0;
  const bad = [];
  for (const q of list){
    const r = lintQuestion(q);
    const mx = Math.max(...q.ch.map(c=>c.length));
    const uniqueMax = q.ch.filter(c => c.length === mx).length === 1;
    if (uniqueMax && q.ch[q.ans].length === mx) longest++;
    if (r.worst === 2) lv2++;
    else if (r.worst === 1) lv1++;
    if (r.worst > 0) bad.push({q, r});
  }
  bad.sort((a,b) => (b.r.worst - a.r.worst) || (b.r.ratio - a.r.ratio));
  return {total:list.length, longest, lv2, lv1, bad};
}

function qlintSheet(tag){
  let list, title;
  if (tag && tag !== 'all'){
    const [subj, grade] = tag.split(':');
    list = questionsBy(subj, grade);
    title = `${SUBJECTS[subj].short} ${GRADES[grade].n}`;
  } else {
    list = allQuestions(); title = 'ทั้งคลัง';
  }
  const R = lintReport(list);
  const pct = R.total ? Math.round(R.longest / R.total * 100) : 0;
  const col = pct >= 45 ? 'var(--bad)' : (pct >= 32 ? 'var(--warn)' : 'var(--ok)');

  const rows = R.bad.slice(0, 40).map(({q, r}) => `<div class="item">
    <div class="ic" style="font-size:calc(11px * var(--fs));color:${r.worst===2?'var(--bad)':'var(--warn)'};text-align:center;line-height:1.2">${r.worst===2?'ต้องแก้':'เฝ้าดู'}</div>
    <div class="grow">
      <b style="font-size:calc(13px * var(--fs));font-weight:400">${esc(q.q)}</b>
      <div class="tiny" style="color:var(--glaze-lt)">เฉลย: ${esc(q.ch[q.ans])}</div>
      ${r.flags.map(f=>`<div class="tiny">· ${f.t}</div>`).join('')}
    </div>
  </div>`).join('');

  sheet(`<div class="eyebrow">ตรวจคุณภาพข้อสอบ · ${title}</div>
    <h2>เฉลยเดาได้จากความยาวหรือไม่</h2>
    <div class="sub">ถ้าเฉลยเป็นตัวเลือกที่ยาวที่สุดบ่อยเกินไป นักเรียนจะเดาถูกโดยไม่ต้องอ่านโจทย์</div>
    <div class="gap"></div>
    <div class="bigstat">
      <div><b style="color:${col}">${pct}%</b><span>เฉลยยาวที่สุด</span></div>
      <div><b style="color:var(--bad)">${R.lv2}</b><span>ต้องแก้</span></div>
      <div><b style="color:var(--warn)">${R.lv1}</b><span>เฝ้าดู</span></div>
    </div>
    <div class="tiny" style="margin-top:8px">เกณฑ์ที่ดีคือใกล้ 25% เพราะมีสี่ตัวเลือก · เกิน 45% ถือว่าเดาได้ง่ายเกินไป · ตัวเลขนี้คิดจาก ${R.total} ข้อ</div>
    <div class="gap"></div>
    <div class="tiny">วิธีแก้ที่ดีที่สุดคือ<b>เขียนตัวลวงให้ยาวและดูน่าเชื่อพอกับเฉลย</b> ไม่ใช่ตัดเฉลยให้สั้นลง เพราะจะเสียความถูกต้องของเนื้อหา</div>
    <div class="gap"></div>
    ${rows ? `<div class="eyebrow">ข้อที่ควรแก้ ${R.bad.length > 40 ? '(แสดง 40 ข้อแรกจาก ' + R.bad.length + ' ข้อ)' : ''}</div>
      <div class="list">${rows}</div>` : '<div class="sub">ไม่พบข้อที่มีปัญหา</div>'}
    <div class="gap"></div>
    <button class="btn block" data-act="qbank">ย้อนกลับ</button>`);
}
