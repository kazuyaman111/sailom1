/* ===================== UI พื้นฐาน ===================== */
const $ = s => document.querySelector(s);
const view = () => $('#view');
let TAB = 'pot';

function toast(msg, kind=''){
  const box = $('#toast');
  const el = document.createElement('div');
  el.className = 'tst ' + kind;
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .4s'; }, 2100);
  setTimeout(()=>el.remove(), 2600);
}
function sheet(html){
  $('#sheet').innerHTML = html;
  $('#veil').classList.add('show');
}
function closeSheet(){ $('#veil').classList.remove('show'); }
$('#veil').addEventListener('click', e => { if (e.target.id === 'veil') closeSheet(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

function esc(s){ return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

/* ===================== แถบบน ===================== */
function paintTop(){
  $('#coins').textContent = Math.floor(S.coins).toLocaleString('th-TH');
  $('#crys').textContent  = Math.floor(S.crystals).toLocaleString('th-TH');
  const p = S.pet;
  const line = $('#petline');
  if (line) line.textContent = p ? `#ห้องเรียนครูชัช · ${p.name} Lv.${p.lv}` : '#ห้องเรียนครูชัช';
  document.body.classList.toggle('night', isNight() && !roomBonus().light);
  // จุดแจ้งเตือนสำรวจเสร็จ
  const eb = document.querySelector('#tabs button[data-tab="explore"]');
  const old = eb.querySelector('.dot'); if (old) old.remove();
  if (S.explore && Date.now() >= S.explore.endAt){
    const d = document.createElement('span'); d.className = 'dot'; eb.appendChild(d);
  }
}

/* ===================== แท็บ ===================== */
document.querySelectorAll('#tabs button').forEach(b => {
  b.addEventListener('click', () => {
    if (QUIZ.running && !QUIZ.locked) return;
    if (DUEL.running && !DUEL.locked) return;
    TAB = b.dataset.tab;
    document.querySelectorAll('#tabs button').forEach(x => x.classList.toggle('on', x === b));
    render();
  });
});

function render(){
  tickOffline();
  paintTop();
  const v = view();
  if (TAB === 'pot')      v.innerHTML = viewPot();
  else if (TAB === 'quiz')    v.innerHTML = viewQuiz();
  else if (TAB === 'explore') v.innerHTML = viewExplore();
  else if (TAB === 'bag')     v.innerHTML = viewBag();
  else if (TAB === 'home')    v.innerHTML = viewHome();
  else if (TAB === 'book')    v.innerHTML = viewBook();
  else if (TAB === 'sum')     v.innerHTML = viewSummary();
  else if (TAB === 'duel')    v.innerHTML = viewDuel();
  bindView();
  const cv = document.getElementById('pot');
  if (cv) initCanvas(cv);
  save();
}

/* ===================== ชิ้นส่วนที่ใช้ซ้ำ ===================== */
function eggBlock(){
  const e = S.egg; if (!e) return '';
  const key = {1:'seed_r',2:'seed_g',3:'seed_m'}[e.tier];
  const prog = clamp(e.pts / e.need * 100, 0, 100);
  const odds = hatchOddsByEl();
  const rows = Object.entries(odds).sort((a,b)=>b[1]-a[1]).slice(0, 5).map(([el, v]) =>
    `<div class="odd">
      <span class="nm">${ELEMENTS[el].g} ${ELEMENTS[el].n}</span>
      <span class="tr"><i style="width:${(v*100).toFixed(1)}%;background:hsl(${ELEMENTS[el].h},52%,58%)"></i></span>
      <span class="pc">${(v*100).toFixed(1)}%</span>
    </div>`).join('');
  const topUnit = eggTopUnit();
  return `<div class="card">
    <div class="eyebrow">${ITEMS[key].g} ${ITEMS[key].n}</div>
    <div class="row spread"><span class="sub">${e.pts >= e.need ? 'พร้อมฟักแล้ว' : `อีก ${e.need - e.pts} คะแนนจะฟัก`}</span>
      <b class="mono">${Math.min(e.pts, e.need)}/${e.need}</b></div>
    <div class="gap" style="height:6px"></div>
    <div class="eggbar"><i style="width:${prog}%"></i></div>
    ${topUnit ? `<div class="tiny" style="margin-top:8px">หน่วยที่สะสมมากที่สุด — ${UNITS[topUnit].n} → ธาตุ${ELEMENTS[unitEl(topUnit)].n} ${ELEMENTS[unitEl(topUnit)].g}</div>` : `<div class="tiny" style="margin-top:8px">ยังไม่มีหน่วยใดนำ ตอบคำถามเพื่อกำหนดธาตุของไข่</div>`}
    <div class="odds">${rows}</div>
    <div class="tiny" style="margin-top:6px">ไข่โตจากคะแนนฐานของข้อที่ตอบถูก ไม่รวมโบนัสความเร็วและตัวคูณต่อเนื่อง · ไข่ใบนี้สุ่มผังธาตุมาเองแล้ว ${Math.round(CHAOS_CHANCE*100)}% ที่ตอนฟักจะแปรปรวนไม่สนผัง</div>
    <div class="gap" style="height:6px"></div>
    <button class="btn sm block" data-act="eggmap">ดูผังธาตุประจำไข่ใบนี้</button>
    ${e.pts >= e.need ? `<div class="gap"></div><button class="btn pri block" data-act="hatch">ฟักไข่</button>` : ''}
  </div>`;
}

function stageBlock(){
  const p = S.pet;
  if (!p) return `<div class="card">
    <div class="stage"><canvas id="pot" width="420" height="340" aria-label="ไข่ในกระถาง"></canvas></div>
    <div style="text-align:center;margin-top:6px">
      <h2>ยังไม่มีวิญญาณ</h2>
      <div class="sub">ตอบคำถามเพื่อสะสมคะแนนให้ไข่ฟัก</div>
    </div>
  </div>`;
  const ew = equippedWeapon(), ea = equippedArmor();
  return `<div class="card">
    <div class="stage">
      <canvas id="pot" width="420" height="340" aria-label="กระถางและวิญญาณ"></canvas>
    </div>
    ${(ew||ea) ? `<div class="row" style="gap:6px;justify-content:center;margin-top:2px">
      ${ew?`<span class="pill" style="color:${TIER_COLOR[ew.tier]};border-color:${TIER_COLOR[ew.tier]}55">${ew.g} ${ew.n}</span>`:''}
      ${ea?`<span class="pill" style="color:${TIER_COLOR[ea.tier]};border-color:${TIER_COLOR[ea.tier]}55">${ea.g} ${ea.n}</span>`:''}
    </div>` : ''}
    <div class="row spread" style="margin-top:6px">
      <div>
        <h2>${esc(p.name)}</h2>
        <div class="sub">${formName(p.sp,p.stage,p.branch)} · ธาตุ${SPECIES[p.sp].el} · Lv.${p.lv}</div>
      </div>
      <div style="text-align:right">
        <span class="pill" style="color:${RARITY[SPECIES[p.sp].rarity].c};border-color:${RARITY[SPECIES[p.sp].rarity].c}55">${RARITY[SPECIES[p.sp].rarity].star}</span>
        <div class="tiny" style="margin-top:3px">${STAGE_NAMES[p.stage] || (p.stage===5?'โบราณ':BRANCHES[p.branch]||'')}</div>
      </div>
    </div>
    ${metersBlock()}
  </div>`;
}

function metersBlock(){
  const p = S.pet;
  const need = xpNeed(p.lv);
  const m = (cls, lab, val, txt) => `<div class="meter">
      <div class="lab"><span>${lab}</span><span class="mono">${txt}</span></div>
      <div class="bar ${cls}"><i style="width:${clamp(val,0,100)}%"></i></div>
    </div>`;
  return `<div class="meters">
    ${m('hp','สุขภาพ', p.hp, Math.round(p.hp))}
    ${m('hu','ความอิ่ม', p.hunger, Math.round(p.hunger))}
    ${m('mo','อารมณ์', p.mood, Math.round(p.mood))}
    ${m('af','ความสนิท', p.aff, Math.round(p.aff))}
    ${m('xp','ประสบการณ์', p.xp/need*100, `${p.xp}/${need}`)}
  </div>`;
}

function statsBlock(){
  const p = S.pet, sp = SPECIES[p.sp];
  return `<div class="stats">` + ['STR','VIT','AGI','INT','LUK'].map(k =>
    `<div class="stat" style="${k===sp.main?'border-color:rgba(216,176,74,.45)':(k===sp.sub?'border-color:rgba(168,211,194,.35)':'')}">
      <b>${p.stats[k]}</b><span>${k}</span></div>`).join('') + `</div>`;
}

/* ===================== หน้า: กระถาง ===================== */
function viewPot(){
  const p = S.pet;
  if (!p) return stageBlock() + eggBlock() + `<div class="card">
    <div class="eyebrow">เริ่มต้น</div>
    <div class="row wrap">
      <button class="btn pri" data-act="goQuiz">ไปตอบคำถาม</button>
      <button class="btn sm" data-act="settings">ตั้งค่าและเซฟ</button>
    </div>
    <div class="gap"></div>
    <div class="row spread">
      <div class="grow"><b>เคยเล่นมาก่อนใช่ไหม</b>
        <div class="sub">ถ้าเคยส่งเซฟขึ้นคลาวด์ไว้ ดึงวิญญาณตัวเดิมกลับมาเล่นต่อได้</div></div>
      <button class="btn gold" data-act="cloud">กู้เซฟ</button>
    </div>
  </div>`;
  const e = evoCheck();
  const b = roomBonus();
  const foods = Object.keys(S.bag).filter(k => ITEMS[k] && ITEMS[k].t === 'food');
  const dom = dominantBranch();

  let evoHtml = '';
  if (e){
    const lines = [
      `เลเวล ${p.lv}/${e.needLv}`,
      `ความสนิท ${Math.round(p.aff)}/${e.needAff}`,
      e.needStone ? `${ITEMS[e.stoneKey].n} ${(S.bag[e.stoneKey]||0)}/1` : null
    ].filter(Boolean).join(' · ');
    evoHtml = `<div class="card">
      <div class="eyebrow">ร่างถัดไป</div>
      <div class="row spread">
        <div class="grow">
          <b>${formName(p.sp, e.next, e.next>=5?'anc':(e.next>=3?e.br:null))}</b>
          <div class="sub">${lines}</div>
          ${p.stage < 3 ? `<div class="tiny" style="margin-top:4px">สายที่นำอยู่ตอนนี้: <b style="color:var(--glaze-lt)">${BRANCHES[dom]}</b> — วิธีดูแลจะเป็นตัวกำหนดร่างที่แตกออกไป</div>` : ''}
        </div>
        <button class="btn ${e.ok?'pri':''}" data-act="evolve" ${e.ok?'':'disabled'}>วิวัฒนาการ</button>
      </div>
    </div>`;
  }

  return `
  ${stageBlock()}
  ${statsBlock()}
  <div class="card">
    <div class="eyebrow">ดูแล</div>
    <div class="row wrap">
      <button class="btn" data-act="feed">ให้อาหาร${foods.length?'':' (ไม่มีอาหาร)'}</button>
      <button class="btn" data-act="play">เล่นด้วยกัน</button>
      <button class="btn" data-act="rest">พาพัก</button>
      <button class="btn pri" data-act="goQuiz">ไปตอบคำถาม</button>
    </div>
    <div class="tiny" style="margin-top:8px">
      สายการเลี้ยง — กายา ${p.care.body} · ฌาน ${p.care.mind} · ระบำ ${p.care.play}
    </div>
  </div>
  ${evoHtml}
  <div class="card">
    <div class="eyebrow">ดวลปริศนา</div>
    <div class="row spread">
      <div class="grow"><b>ท้าดวลกับเพื่อน</b>
        <div class="sub">แลกรหัสกันแล้วดวลได้เลย ไม่ต้องต่อเน็ตหากัน${(S.duel&&(S.duel.win||S.duel.lose))?` · สถิติ ${S.duel.win||0}-${S.duel.draw||0}-${S.duel.lose||0}`:''}</div></div>
      <button class="btn gold" data-act="duel">เปิด</button>
    </div>
  </div>
  ${eggBlock()}
  <div class="card">
    <div class="eyebrow">บันทึก</div>
    <div class="row spread"><span class="sub">ตอบคำถามไปแล้ว</span><b class="mono">${S.stats.answered} ข้อ</b></div>
    <div class="row spread"><span class="sub">ความแม่นยำ</span><b class="mono">${S.stats.answered ? Math.round(S.stats.correct/S.stats.answered*100) : 0}%</b></div>
    <div class="row spread"><span class="sub">คะแนนสะสม</span><b class="mono">${S.stats.points.toLocaleString('th-TH')}</b></div>
    <div class="row spread"><span class="sub">ตอบถูกติดกันสูงสุด</span><b class="mono">${S.stats.bestStreak} ข้อ</b></div>
    <div class="row spread"><span class="sub">ตอบต่อเนื่อง</span><b class="mono">${S.stats.streak} วัน</b></div>
    ${(()=>{const L=[];
      if(b.focusXp)L.push(`ประสบการณ์ +${Math.round(b.focusXp*100)}%`);
      if(b.exploreLuck)L.push(`ของหายาก +${Math.round(b.exploreLuck*100)}%`);
      if(b.hungerSlow)L.push(`หิวช้าลง ${Math.round(b.hungerSlow*100)}%`);
      if(b.moodSlow)L.push(`อารมณ์ลดช้าลง ${Math.round(b.moodSlow*100)}%`);
      if(b.coin)L.push(`เหรียญ +${Math.round(b.coin*100)}%`);
      if(b.aff)L.push(`ความสนิท +${Math.round(b.aff*100)}%`);
      if(b.rest)L.push(`ฟื้นสุขภาพ +${b.rest}/ชม.`);
      if(b.foodBoost)L.push(`ความอิ่มจากอาหาร +${Math.round(b.foodBoost*100)}%`);
      if(b.duelAtk)L.push(`โจมตีในดวล +${Math.round(b.duelAtk*100)}%`);
      if(b.duelDef)L.push(`เกราะในดวล +${Math.round(b.duelDef*100)}%`);
      if(b.crystal)L.push(`ลุ้นผลึกเพิ่ม ${Math.round(b.crystal*100)}%`);
      if(b.exploreFast)L.push(`สำรวจเร็วขึ้น ${Math.round(b.exploreFast*100)}%`);
      if(b.eggBoost)L.push(`ไข่โตเร็วขึ้น ${Math.round(b.eggBoost*100)}%`);
      return L.length?`<hr class="sep"><div class="tiny">โบนัสจากบ้าน — ${L.join(' · ')}</div>`:'';
    })()}
    ${S.guard>0?`<div class="tiny" style="color:var(--glaze-lt)">มียาต้มคุ้มกันอยู่ กันบาดเจ็บได้อีก ${S.guard} ครั้ง</div>`:''}
    ${S.boost>0?`<div class="tiny" style="color:var(--gold)">กำลังตื่นตัวจากช็อกโกแลต ประสบการณ์ +25% อีก ${S.boost} รอบ</div>`:''}
    <hr class="sep">
    <div class="row wrap">
      <button class="btn sm" data-act="garden">สวน ${gardenCount()+1}/${GARDEN_MAX}</button>
      <button class="btn sm" data-act="rename">เปลี่ยนชื่อ</button>
      <button class="btn sm" data-act="settings">ตั้งค่าและเซฟ</button>
    </div>
  </div>`;
}

/* ===================== หน้า: กระเป๋า ===================== */
function viewBag(){
  const keys = Object.keys(S.bag).filter(k => S.bag[k] > 0 && ITEMS[k]);
  const order = {food:0, heal:1, tool:2, stat:3, care:4, eggboost:5, explore:6, stone:7, egg:8, mat:9};
  keys.sort((a,b) => (order[ITEMS[a].t] - order[ITEMS[b].t]) || ITEMS[a].n.localeCompare(ITEMS[b].n,'th'));
  const list = keys.length ? keys.map(k => {
    const it = ITEMS[k];
    const canUse = ['food','heal','egg','stat','care','eggboost','explore','tool'].includes(it.t);
    return `<div class="item">
      <div class="ic">${it.g}</div>
      <div class="grow"><b>${it.n}</b><div class="sub">${it.d}</div></div>
      <div style="text-align:right">
        <div class="qty">×${S.bag[k]}</div>
        <div class="row" style="gap:4px;margin-top:4px">
          ${canUse?`<button class="btn sm" data-use="${k}">${it.t==='egg'?'เริ่มฟัก':(it.t==='explore'?'เรียกกลับ':(it.t==='tool'?'ถูบ้าน':'ใช้'))}</button>`:''}
          ${it.sell?`<button class="btn sm" data-sell="${k}">ขาย ${it.sell}</button>`:''}
        </div>
      </div>
    </div>`;
  }).join('') : `<div class="tiny">กระเป๋าว่างเปล่า ส่งวิญญาณออกสำรวจเพื่อเก็บของ หรือโฟกัสให้ครบรอบเพื่อรับของติดมือ</div>`;

  return `<div class="card">
    <div class="eyebrow">กระเป๋า · ${bagCount()} ชิ้น</div>
    <h2>ของที่เก็บมาได้</h2>
    <div class="gap"></div>
    <div class="list">${list}</div>
  </div>
  <div class="card">
    <div class="eyebrow">อาวุธและเครื่องแต่งกาย</div>
    <div class="row spread">
      <div class="grow"><b>คลังอาวุธ</b><div class="sub">ซื้อด้วยเหรียญ สวมได้ทีละชิ้น ยิ่งแพงยิ่งแรง</div></div>
      <button class="btn" data-act="gear">เปิด</button>
    </div>
  </div>
  <div class="card">
    <div class="eyebrow">ร้านผลึกสมาธิ</div>
    <div class="row spread">
      <div class="grow"><b>เมล็ดและของหายาก</b><div class="sub">แลกด้วยผลึกที่ได้จากการโฟกัสเท่านั้น</div></div>
      <button class="btn gold" data-act="crystal">มี ${Math.floor(S.crystals)} ผลึก</button>
    </div>
  </div>
  <div class="card">
    <div class="eyebrow">ร้านค้า</div>
    <h2>ซื้อของกิน</h2>
    <div class="sub">ใช้เหรียญที่ได้จากการโฟกัส</div>
    <div class="gap"></div>
    <div class="list">
      ${['leaf','berry','meatball','driedfish','ricecake','popchick','honey','sweetsoup','chocolate','mop','balm','antidote','tonic','elixir'].map(k=>{
        const it = ITEMS[k], price = it.buy || Math.round(it.sell*1.8);
        return `<div class="item">
          <div class="ic">${it.g}</div>
          <div class="grow"><b>${it.n}</b><div class="sub">${it.d}</div></div>
          <button class="btn sm ${S.coins>=price?'gold':''}" data-buy="${k}" data-price="${price}" ${S.coins>=price?'':'disabled'}>${price}</button>
        </div>`;
      }).join('')}
    </div>
  </div>`;
}

/* ===================== หน้า: บ้าน ===================== */
function viewHome(){
  const lit = roomBonus().light > 0;
  const night = isNight();
  const slots = S.room.map((k,i) =>
    `<button class="slot ${k?'filled':''}" data-slot="${i}" title="${k?FURN[k].n:'ช่องว่าง'}">${k?FURN[k].g:''}</button>`).join('');
  const owned = S.room.filter(Boolean).length;

  return `<div class="card">
    <div class="eyebrow">บ้าน · วางได้ ${owned}/${ROOM_SLOTS} ช่อง</div>
    <h2>${S.pet ? `ห้องของ${esc(S.pet.name)}` : 'ห้องว่างรอเจ้าของ'}</h2>
    <div class="sub">${night ? (lit ? 'กลางคืน — โคมไฟส่องห้องให้สว่างอยู่' : 'กลางคืน — ห้องมืด ลองวางโคมกระดาษดู') : 'กลางวัน — แสงเข้าห้องพอดี'}</div>
    <div class="gap"></div>
    <div id="room" class="${lit||!night?'lit':''}"><div class="slots">${slots}</div></div>
    <div class="tiny" style="margin-top:8px">${S.pet?'':'ตกแต่งล่วงหน้าได้เลย ของที่วางไว้จะให้โบนัสทันทีที่ไข่ฟัก · '}แตะช่องเพื่อวางหรือเก็บของ ของทุกชิ้นที่วางไว้จะให้โบนัสกับการเลี้ยงและการโฟกัส</div>
  </div>
  <div class="card">
    <div class="eyebrow">ร้านของตกแต่ง</div>
    <div class="list">
      ${Object.entries(FURN).map(([k,f])=>{
        const have = S.room.includes(k);
        return `<div class="item">
          <div class="ic">${f.g}</div>
          <div class="grow"><b>${f.n}</b><div class="sub">${f.d}</div></div>
          ${have ? `<span class="pill">วางแล้ว</span>`
                 : `<button class="btn sm ${S.coins>=f.cost?'gold':''}" data-buyf="${k}" ${S.coins>=f.cost?'':'disabled'}>${f.cost}</button>`}
        </div>`;
      }).join('')}
    </div>
  </div>`;
}

/* ===================== หน้า: สมุดสะสม ===================== */
let BOOKEL = null;

function viewBook(){
  const EL = BOOKEL || (S.pet ? SPECIES[S.pet.sp].elk : 'wood');
  const gotForms = Object.keys(S.book).length;
  const gotSp = Object.keys(S.seen || {}).length;

  const chips = EL_KEYS.map(e => {
    const list = SP_BY_EL(e);
    const n = list.reduce((a,k) => a + FORMS_BY_SP[k].filter(f => S.book[f.id]).length, 0);
    const tot = list.length * 10;
    return `<button class="chip ${e===EL?'on':''}" data-bookel="${e}">${ELEMENTS[e].g} ${ELEMENTS[e].n} <span class="mono" style="font-size:calc(11px * var(--fs));opacity:.7">${n}/${tot}</span></button>`;
  }).join('');

  const groups = SP_BY_EL(EL).map(k => {
    const sp = SPECIES[k];
    const forms = FORMS_BY_SP[k];
    const n = forms.filter(f => S.book[f.id]).length;
    const seen = !!(S.seen && S.seen[k]);
    const cards = forms.map(f => {
      const has = !!S.book[f.id];
      if (has) return `<button class="bcard" data-card="${f.id}">
          ${sigilSVG(S.uid + f.id, sp.accent)}
          <div class="nm">${formName(f.sp,f.stage,f.branch).replace(sp.name+' ','')}</div>
          <div class="st">${collectCode(f.id).slice(0,4)}···</div>
        </button>`;
      return `<div class="bcard locked">
          <svg class="sigil" width="44" height="44" viewBox="0 0 44 44"><rect width="44" height="44" fill="rgba(255,255,255,.05)"/></svg>
          <div class="nm">${seen ? formName(f.sp,f.stage,f.branch).replace(sp.name+' ','') : '???'}</div>
          <div class="st">ขั้น ${f.stage}</div>
        </div>`;
    }).join('');
    return `<div class="card">
      <div class="row spread" style="align-items:baseline">
        <div class="grow">
          <b style="color:${seen?sp.accent:'inherit'}">${seen ? sp.name : '??? ยังไม่เคยพบ'}</b>
          <div class="tiny">${seen ? sp.desc : 'ต้องปลูกเมล็ดให้เจอสายพันธุ์นี้ก่อน'}</div>
        </div>
        <span class="pill" style="color:${RARITY[sp.rarity].c};border-color:${RARITY[sp.rarity].c}55">${RARITY[sp.rarity].star}</span>
      </div>
      <div class="tiny" style="margin:6px 0 8px">เด่น ${sp.main} · รอง ${sp.sub} · พบแล้ว ${n}/10 ร่าง</div>
      <div class="book">${cards}</div>
    </div>`;
  }).join('');

  return `<div class="card">
    <div class="eyebrow">สมุดสะสม</div>
    <h2>${gotSp}/${SP_KEYS.length} สายพันธุ์ · ${gotForms}/${ALL_FORMS.length} ร่าง</h2>
    <div class="sub">ทุกใบมีรหัสสะสม 13 หลักที่คำนวณจากบัญชี ${S.uid} เครื่องอื่นได้รหัสคนละชุด</div>
    <div class="gap"></div>
    <div class="chips">${chips}</div>
  </div>
  ${groups}`;
}

function cardSheet(id){
  const f = ALL_FORMS.find(x => x.id === id);
  const sp = SPECIES[f.sp];
  return `<div style="text-align:center">
    <div class="eyebrow" style="text-align:center">การ์ดสะสม</div>
    <div style="display:inline-block;border:1px solid ${sp.a(.45)};border-radius:16px;padding:18px 22px;background:linear-gradient(160deg,${sp.dim},transparent)">
      ${sigilSVG(S.uid + f.id, sp.accent, 92)}
      <h2 style="margin-top:10px">${formName(f.sp,f.stage,f.branch)}</h2>
      <div class="sub">ธาตุ${sp.el} · ขั้นที่ ${f.stage}${f.branch&&f.branch!=='anc'?' · สาย'+BRANCHES[f.branch]:''}</div>
      <div class="pill" style="display:inline-block;margin-top:6px;color:${RARITY[sp.rarity].c};border-color:${RARITY[sp.rarity].c}55">${RARITY[sp.rarity].star} ${RARITY[sp.rarity].n}</div>
      <div class="tiny" style="margin-top:8px">${sp.desc}</div>
      <hr class="sep">
      <div class="mono" style="font-size:calc(15px * var(--fs));letter-spacing:.12em;color:${sp.accent}">${collectCode(f.id)}</div>
      <div class="tiny">ปลดล็อก ${fmtDate(S.book[f.id])} · บัญชี ${S.uid}</div>
    </div>
  </div>
  <div class="gap"></div>
  <button class="btn block" data-act="closeSheet">ปิด</button>`;
}


/* ===================== หน้า: สรุปผลสัมฤทธิ์ ===================== */
function accColor(pct){
  if (pct >= 80) return '#7cae9b';
  if (pct >= 60) return '#a8c98a';
  if (pct >= 40) return '#d8b04a';
  return '#c26a6a';
}
function accBar(r, w){
  const t = r + w;
  const pct = t ? Math.round(r / t * 100) : 0;
  return {pct, t, html:`<div class="pbar"><i style="width:${pct}%;background:${accColor(pct)}"></i></div>`};
}
function trendTag(p){
  const tr = trendOf(p);
  if (!tr) return `<span class="trend flat">—</span>`;
  const d = Math.round(tr.diff * 100);
  if (d >= 8)  return `<span class="trend up">▲ ${d}%</span>`;
  if (d <= -8) return `<span class="trend down">▼ ${Math.abs(d)}%</span>`;
  return `<span class="trend flat">คงที่</span>`;
}

function viewSummary(){
  const st = S.stats;
  const acc = st.answered ? Math.round(st.correct / st.answered * 100) : 0;

  // รวมตามวิชา+ระดับชั้น และตามหน่วย
  const bySG = {}, byUnit = {};
  for (const key in (S.prog || {})){
    const [subj, grade, unit] = key.split('|');
    const p = S.prog[key];
    const sg = subj + '|' + grade;
    if (!bySG[sg]) bySG[sg] = {r:0, w:0, subj, grade};
    bySG[sg].r += p.r; bySG[sg].w += p.w;
    byUnit[key] = {subj, grade, unit, p};
  }

  const petCard = S.pet ? (() => {
    const p = S.pet, sp = SPECIES[p.sp];
    return `<div class="card">
      <div class="stage"><canvas id="pot" width="420" height="340" aria-label="วิญญาณปัจจุบัน"></canvas></div>
      <div style="text-align:center;margin-top:4px">
        <h2>${esc(p.name)}</h2>
        <div class="sub">${formName(p.sp,p.stage,p.branch)} · Lv.${p.lv}</div>
        <div class="gap" style="height:6px"></div>
        <span class="pill" style="color:${RARITY[sp.rarity].c};border-color:${RARITY[sp.rarity].c}55">${RARITY[sp.rarity].star} ${RARITY[sp.rarity].n}</span>
        <span class="pill">ธาตุ${sp.el}</span>
        <span class="pill">พลังรวม ${petPower(p)}</span>
      </div>
    </div>` ;
  })() : `<div class="card"><div class="eyebrow">ยังไม่มีวิญญาณ</div>
      <div class="stage"><canvas id="pot" width="420" height="340"></canvas></div>
      <div class="sub" style="text-align:center">ตอบคำถามให้ไข่ฟักก่อน</div></div>`;

  const sgRows = Object.values(bySG)
    .sort((a,b) => (GRADES[a.grade].ord - GRADES[b.grade].ord) || a.subj.localeCompare(b.subj))
    .map(x => {
      const b = accBar(x.r, x.w);
      const code = SUBJECTS[x.subj].code[x.grade];
      return `<div class="prow">
        <div class="lab">
          <b>${SUBJECTS[x.subj].g} ${SUBJECTS[x.subj].short} · ${GRADES[x.grade].n}</b>
          <div class="tiny">${code || ''} · ถูก ${x.r} ผิด ${x.w} จาก ${b.t} ข้อ</div>
          ${b.html}
        </div>
        <div class="num" style="color:${accColor(b.pct)}">${b.pct}%</div>
      </div>`;
    }).join('');

  const unitRows = Object.values(byUnit)
    .sort((a,b) => (b.p.r + b.p.w) - (a.p.r + a.p.w))
    .map(x => {
      const b = accBar(x.p.r, x.p.w);
      const el = ELEMENTS[UNITS[x.unit].el];
      return `<div class="prow">
        <div class="lab">
          <b>${UNITS[x.unit].n}</b>
          <div class="tiny">${SUBJECTS[x.subj].short} ${GRADES[x.grade].n} · ธาตุ${el.n} ${el.g} · ถูก ${x.p.r} ผิด ${x.p.w}</div>
          ${b.html}
        </div>
        <div class="num" style="color:${accColor(b.pct)}">${b.pct}%</div>
        ${trendTag(x.p)}
      </div>`;
    }).join('');

  // หน่วยที่ควรทบทวน
  const weak = Object.values(byUnit)
    .filter(x => (x.p.r + x.p.w) >= 5)
    .map(x => ({...x, pct: x.p.r / (x.p.r + x.p.w) * 100}))
    .filter(x => x.pct < 70)
    .sort((a,b) => a.pct - b.pct).slice(0, 3);

  return `
  ${petCard}
  <div class="card">
    <div class="eyebrow">ภาพรวม</div>
    <div class="bigstat">
      <div><b>${st.answered}</b><span>ตอบทั้งหมด</span></div>
      <div><b style="color:${accColor(acc)}">${acc}%</b><span>ความแม่นยำ</span></div>
      <div><b>${st.rounds}</b><span>รอบที่ทำ</span></div>
    </div>
    <div class="gap"></div>
    <div class="bigstat">
      <div><b style="color:var(--ok)">${st.correct}</b><span>ตอบถูก</span></div>
      <div><b style="color:var(--bad)">${st.answered - st.correct}</b><span>ตอบผิด</span></div>
      <div><b>${st.points.toLocaleString('th-TH')}</b><span>คะแนนสะสม</span></div>
    </div>
    <div class="tiny" style="margin-top:10px">ตอบถูกติดกันสูงสุด ${st.bestStreak} ข้อ · ตอบต่อเนื่อง ${st.streak} วัน · คะแนนสูงสุดในหนึ่งรอบ ${st.best}</div>
  </div>
  ${sgRows ? `<div class="card">
    <div class="eyebrow">แยกตามวิชาและระดับชั้น</div>
    ${sgRows}
  </div>` : ''}
  ${unitRows ? `<div class="card">
    <div class="eyebrow">ผลสัมฤทธิ์รายหน่วยการเรียนรู้</div>
    <div class="sub">ลูกศรเทียบผลครึ่งหลังกับครึ่งแรกของ 40 ข้อล่าสุดในหน่วยนั้น ต้องตอบอย่างน้อย 10 ข้อจึงเริ่มแสดง</div>
    <div class="gap" style="height:6px"></div>
    ${unitRows}
  </div>` : `<div class="card"><div class="eyebrow">ยังไม่มีข้อมูล</div>
    <div class="sub">ตอบคำถามสักรอบแล้วกลับมาดูผลสัมฤทธิ์รายหน่วยได้ที่นี่</div></div>`}
  ${weak.length ? `<div class="card">
    <div class="eyebrow">ควรทบทวน</div>
    <div class="list">${weak.map(x => `<div class="item">
      <div class="ic">${ELEMENTS[UNITS[x.unit].el].g}</div>
      <div class="grow"><b>${UNITS[x.unit].n}</b>
        <div class="sub">${SUBJECTS[x.subj].short} ${GRADES[x.grade].n} · ทำได้ ${Math.round(x.pct)}%</div></div>
    </div>`).join('')}</div>
    <div class="tiny" style="margin-top:8px">ข้อที่ตอบผิดจะถูกนำกลับมาถามซ้ำเร็วขึ้นโดยอัตโนมัติ</div>
  </div>` : ''}`;
}
