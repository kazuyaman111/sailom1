/* ===========================================================
   ภารกิจซ่อมจุดบอด
   - อัตโนมัติ  เกมดู S.prog หาหน่วยที่ทำได้ต่ำสุดแล้วตั้งภารกิจให้เอง
   - ครูสั่ง    ดึงจากแท็บ Missions ในชีต สั่งเป็นรายห้อง
   - สำรวจ      ถ้ายังไม่มีจุดบอด ให้ลองหน่วยที่ยังไม่เคยแตะ
   =========================================================== */

const MQ_PASS   = 70;   // ทำหน่วยนั้นได้ต่ำกว่ากี่เปอร์เซ็นต์จึงถือว่าเป็นจุดบอด
const MQ_MIN    = 5;    // ต้องเคยตอบในหน่วยนั้นอย่างน้อยกี่ข้อจึงตัดสิน
const MQ_NEED   = 8;    // ภารกิจกำหนดให้ตอบถูกกี่ข้อ
const MQ_WINDOW = 12;   // ภายในกี่ข้อที่ตอบในหน่วยนั้น

/* ---------- หาจุดบอดจากผลสัมฤทธิ์ของเด็กคนนี้ ---------- */
function findWeakSpot(){
  const rows = [];
  for (const key in (S.prog || {})){
    const [subj, grade, unit] = key.split('|');
    if (!SUBJECTS[subj] || !GRADES[grade] || !UNITS[unit]) continue;
    const p = S.prog[key];
    const tot = p.r + p.w;
    if (tot < MQ_MIN) continue;
    const acc = Math.round(p.r / tot * 100);
    if (acc >= MQ_PASS) continue;
    rows.push({ subj, grade, unit, acc, tot });
  }
  rows.sort((a, b) => a.acc - b.acc);
  return rows[0] || null;
}

/* หน่วยที่ยังไม่เคยตอบเลย ใช้เป็นภารกิจสำรวจ */
function findFreshUnit(){
  const grade = S.grade;
  const out = [];
  for (const subj of SUBJ_KEYS){
    if (!questionsBy(subj, grade).length) continue;
    for (const unit of Object.keys(UNITS)){
      if (UNITS[unit].subj !== subj) continue;
      const key = `${subj}|${grade}|${unit}`;
      const p = S.prog[key];
      if (p && p.r + p.w >= MQ_MIN) continue;
      if (!questionsBy(subj, grade).some(q => q.unit === unit)) continue;
      out.push({ subj, grade, unit });
    }
  }
  return out.length ? out[Math.floor(Math.random() * out.length)] : null;
}

/* ---------- สร้างภารกิจประจำวัน ---------- */
function todayMissions(){
  S.mq = S.mq || { day:'', list:[], done:[] };
  const t = todayKey();
  if (S.mq.day === t && S.mq.list.length) return S.mq.list;

  S.mq.day = t;
  S.mq.done = [];
  const list = [];

  /* 1) ภารกิจจากครู ถ้ามีและยังไม่หมดอายุ */
  (S.teacherMq || []).forEach((m, i) => {
    if (m.grade && m.grade !== S.grade) return;
    if (m.until && Date.now() > m.until) return;
    if (!UNITS[m.unit] || !SUBJECTS[m.subj]) return;
    list.push({
      id: 'T' + i, from:'teacher',
      subj:m.subj, grade:m.grade || S.grade, unit:m.unit,
      need: m.need || MQ_NEED, win: m.win || MQ_WINDOW,
      note: m.note || '',
      r:0, w:0
    });
  });

  /* 2) ภารกิจซ่อมจุดบอดของตัวเอง */
  const weak = findWeakSpot();
  if (weak && !list.some(x => x.unit === weak.unit && x.subj === weak.subj))
    list.push({ id:'W', from:'weak', subj:weak.subj, grade:weak.grade, unit:weak.unit,
                need:MQ_NEED, win:MQ_WINDOW, acc:weak.acc, r:0, w:0 });

  /* 3) ภารกิจสำรวจ ถ้ายังว่างอยู่ */
  if (list.length < 2){
    const fresh = findFreshUnit();
    if (fresh && !list.some(x => x.unit === fresh.unit && x.subj === fresh.subj))
      list.push({ id:'F', from:'fresh', subj:fresh.subj, grade:fresh.grade, unit:fresh.unit,
                  need:6, win:10, r:0, w:0 });
  }

  S.mq.list = list;
  save();
  return list;
}

/* ---------- บันทึกความคืบหน้าเมื่อตอบข้อในหน่วยที่ตรงกับภารกิจ ---------- */
function mqRecord(q, correct){
  if (!S.mq || !S.mq.list) return null;
  let finished = null;
  S.mq.list.forEach(m => {
    if (S.mq.done.includes(m.id)) return;
    if (m.unit !== q.unit) return;
    if (m.subj !== q.subj || m.grade !== q.grade) return;
    if (correct) m.r++; else m.w++;
    if (m.r >= m.need){
      S.mq.done.push(m.id);
      finished = m;
    } else if (m.r + m.w >= m.win){
      /* ใช้โควตาหมดแล้วยังไม่ถึงเป้า รีเซ็ตให้ลองใหม่ ไม่ลงโทษ */
      m.r = 0; m.w = 0;
    }
  });
  return finished;
}

/* รางวัลเมื่อทำภารกิจสำเร็จ */
function mqReward(m){
  const crys = m.from === 'teacher' ? 6 : (m.from === 'weak' ? 5 : 3);
  const coin = m.from === 'teacher' ? 220 : (m.from === 'weak' ? 180 : 120);
  S.crystals += crys;
  S.coins += coin;
  S.mqGauge = true;      // เกจคาถาเต็มทันทีในการดวลครั้งถัดไป
  save();
  return { crys, coin };
}

/* ---------- ดึงภารกิจจากครูผ่านชีต ---------- */
async function fetchTeacherMissions(){
  if (!cloudUrl()) return { err:'ยังไม่ได้ตั้งค่าที่อยู่เซิร์ฟเวอร์' };
  try {
    const res = await fetch(cloudUrl() + '?missions=1&grade=' + encodeURIComponent(S.grade || ''));
    const out = await res.json();
    if (out.status !== 'success') return { err: out.message || 'ดึงภารกิจไม่สำเร็จ' };
    S.teacherMq = (out.data || []).slice(0, 3);
    S.mq = S.mq || { day:'', list:[], done:[] };
    S.mq.day = '';        // บังคับให้สร้างรายการใหม่
    save();
    return { ok:true, n: S.teacherMq.length };
  } catch (e){
    return { err:'เชื่อมต่อไม่ได้' };
  }
}

/* ---------- หน้าจอ ---------- */
function mqLabel(m){
  if (m.from === 'teacher') return { t:'ภารกิจจากครู', c:'var(--gold)' };
  if (m.from === 'weak')    return { t:'ซ่อมจุดบอด',  c:'var(--bad)' };
  return { t:'ลองหน่วยใหม่', c:'var(--glaze-lt)' };
}

function mqCard(){
  const list = todayMissions();
  if (!list.length) return '';
  const rows = list.map(m => {
    const done = S.mq.done.includes(m.id);
    const L = mqLabel(m);
    const pct = Math.min(100, m.r / m.need * 100);
    return `<div class="item">
      <div class="ic" style="font-size:calc(10px * var(--fs));color:${L.c};text-align:center;line-height:1.25">${L.t}</div>
      <div class="grow">
        <b>${done ? '✓ ' : ''}${esc(UNITS[m.unit].n)}</b>
        <div class="sub">${SUBJECTS[m.subj].short} ${GRADES[m.grade].n} · ตอบถูก ${m.need} ข้อจาก ${m.win} ข้อที่ตอบ${m.acc !== undefined ? ` · ตอนนี้ทำได้ ${m.acc}%` : ''}</div>
        ${m.note ? `<div class="tiny" style="color:var(--gold)">ครูฝากไว้ — ${esc(m.note)}</div>` : ''}
        ${done ? '<div class="tiny" style="color:var(--ok)">สำเร็จแล้ววันนี้</div>'
               : `<div class="bar" style="margin-top:5px"><i style="width:${pct}%;background:${L.c}"></i></div>
                  <div class="tiny">${m.r}/${m.need} ข้อ</div>`}
      </div>
      ${done ? '' : `<button class="btn sm" data-mqgo="${m.subj}:${m.grade}:${m.unit}">ไปทำ</button>`}
    </div>`;
  }).join('');

  const allDone = list.every(m => S.mq.done.includes(m.id));
  return `<div class="card">
    <div class="row spread">
      <div class="grow"><div class="eyebrow">ภารกิจวันนี้</div></div>
      ${cloudUrl() ? '<button class="btn sm" data-act="mqSync">ดึงจากครู</button>' : ''}
    </div>
    <div class="list">${rows}</div>
    ${allDone ? '<div class="tiny" style="color:var(--ok);margin-top:8px">ทำครบทุกภารกิจแล้ว พรุ่งนี้มีใหม่</div>'
              : '<div class="tiny" style="margin-top:8px">ทำสำเร็จได้ผลึกสมาธิและเกจคาถาเต็มทันทีในการดวลครั้งถัดไป</div>'}
  </div>`;
}

function mqDoneSheet(m, rw){
  const L = mqLabel(m);
  return `<div class="eyebrow" style="color:${L.c}">${L.t}สำเร็จ</div>
    <h2>${esc(UNITS[m.unit].n)}</h2>
    <div class="sub">ตอบถูกครบ ${m.need} ข้อแล้ว${m.acc !== undefined ? ` จากเดิมที่เคยทำได้ ${m.acc}%` : ''}</div>
    <div class="gap"></div>
    <div class="list">
      <div class="item"><div class="ic">💠</div><div class="grow"><b>ผลึกสมาธิ +${rw.crys}</b></div></div>
      <div class="item"><div class="ic">🪙</div><div class="grow"><b>เหรียญ +${rw.coin}</b></div></div>
      <div class="item"><div class="ic">✨</div><div class="grow"><b>เกจคาถาเต็มทันที</b>
        <div class="sub">ใช้ได้ในการดวลครั้งถัดไป ตอบถูกข้อแรกร่ายคาถาได้เลย</div></div></div>
    </div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="closeSheet">เยี่ยม</button>`;
}
