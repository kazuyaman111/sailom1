/* ===========================================================
   ห้องเรียนไร้ขีดจำกัด #ห้องเรียนครูชัช — v2.1
   เกมเลี้ยงวิญญาณที่เติบโตจากคำถามที่นักเรียนตอบได้
   =========================================================== */

const VERSION = '2.1';
// คงคีย์เดิมไว้ตั้งแต่ชื่อเก่า เพื่อไม่ให้เซฟของผู้เล่นเดิมหายตอนเปลี่ยนชื่อเกม
const SAVEKEY = 'krathangjai:save:v1';

/* ===================== ธาตุ ===================== */
const ELEMENTS = {
  wood:  {n:'ไม้',     g:'🌿', main:'VIT', h:152, s:30, l:56},
  water: {n:'น้ำ',     g:'💧', main:'INT', h:205, s:38, l:60},
  fire:  {n:'ไฟ',      g:'🔥', main:'STR', h:14,  s:52, l:60},
  wind:  {n:'ลม',      g:'🌬️', main:'AGI', h:96,  s:12, l:70},
  earth: {n:'ดิน',     g:'⛰️', main:'VIT', h:28,  s:26, l:50},
  bolt:  {n:'สายฟ้า',  g:'⚡', main:'AGI', h:268, s:34, l:62},
  light: {n:'แสง',     g:'✨', main:'LUK', h:46,  s:56, l:64},
  shade: {n:'เงา',     g:'🌑', main:'INT', h:232, s:22, l:44},
};
const EL_KEYS = Object.keys(ELEMENTS);

/* ===================== ระดับความหายาก ===================== */
const RARITY = [
  null,
  {n:'ธรรมดา',    star:'★',    statMul:1.00, hungerMul:1.00, c:'#9fb6ac'},
  {n:'ไม่ธรรมดา', star:'★★',   statMul:1.09, hungerMul:1.06, c:'#7fb6c9'},
  {n:'หายาก',     star:'★★★',  statMul:1.20, hungerMul:1.16, c:'#c9a24a'},
  {n:'ในตำนาน',   star:'★★★★', statMul:1.34, hungerMul:1.28, c:'#c98ad4'},
];

/* ===================== รายชื่อสายพันธุ์ 32 ชนิด ===================== */
// [id, ชื่อ, ธาตุ, ความหายาก, ค่าสถานะรอง, คำบรรยาย]
const SP_RAW = [
  ['rukkha',   'รุกขา',       'wood',  1, 'STR', 'วิญญาณรากไม้ธรรมดา อดทนและซื่อ'],
  ['praiwan',  'ไพรวัลย์',    'wood',  1, 'AGI', 'เถาวัลย์เลื้อยเร็ว ชอบปีนป่ายทุกอย่าง'],
  ['phakamas', 'ผกามาศ',      'wood',  2, 'LUK', 'ดอกไม้ที่บานเฉพาะตอนเจ้าของตั้งใจจริง'],
  ['takian',   'ตะเคียนเฒ่า', 'wood',  3, 'INT', 'อยู่มาก่อนเมืองนี้ พูดน้อยแต่ไม่เคยล้ม'],

  ['waree',    'วารี',        'water', 1, 'AGI', 'หยดน้ำใสที่จำทุกอย่างที่ไหลผ่าน'],
  ['chonlatan','ชลธาร',       'water', 2, 'VIT', 'สายธารเย็น ยิ่งไหลนานยิ่งลึก'],
  ['mukda',    'มุกดา',       'water', 2, 'LUK', 'ไข่มุกน้ำจืด เปล่งแสงตอนอารมณ์ดี'],
  ['nakhin',   'นาคินทร์',    'water', 4, 'STR', 'พญานาคน้อยจากใต้คลอง เกล็ดสะท้อนฟ้า'],

  ['akkhi',    'อัคคี',       'fire',  1, 'AGI', 'เปลวไฟดวงเล็กที่ไม่ยอมดับ'],
  ['thanthao', 'ถ่านเถ้า',    'fire',  1, 'VIT', 'ถ่านที่ยังอุ่น ค่อยๆ ให้ความร้อนไปทั้งคืน'],
  ['phloeng',  'เพลิงพราย',   'fire',  2, 'INT', 'ไฟสีเขียวที่ลอยเหนือพื้น เย็นเมื่อสัมผัส'],
  ['suriyan',  'สุริยัน',     'fire',  3, 'LUK', 'เศษเสี้ยวของตะวันเที่ยง ร้อนแต่ใจดี'],

  ['wayu',     'วายุ',        'wind',  1, 'INT', 'ลมหายใจที่มีรูปร่าง ว่องไวกว่าที่คิด'],
  ['lomwao',   'ลมว่าว',      'wind',  1, 'LUK', 'ลมหน้าหนาวที่พาว่าวขึ้นฟ้าได้เสมอ'],
  ['mekhin',   'เมฆิน',       'wind',  2, 'VIT', 'ก้อนเมฆที่หลงมาต่ำ นุ่มจนอยากกอด'],
  ['krut',     'ครุฑน้อย',    'wind',  4, 'STR', 'ลูกครุฑที่เพิ่งหัดบิน ปีกยังใหญ่เกินตัว'],

  ['sila',     'ศิลา',        'earth', 1, 'STR', 'ก้อนหินที่ตื่นขึ้นมาเพราะมีคนเรียกชื่อ'],
  ['dinphao',  'ดินเผา',      'earth', 1, 'INT', 'ตุ๊กตาดินเผาจากเตาเก่า ผิวยังอุ่น'],
  ['pathaphi', 'ปฐพี',        'earth', 2, 'STR', 'ดินชั้นล่างสุด หนักแน่นและเงียบ'],
  ['khunkhao', 'ขุนเขา',      'earth', 3, 'STR', 'ยอดเขาที่ย่อส่วนลงมาอยู่ในกระถาง'],

  ['atsani',   'อัสนี',       'bolt',  1, 'STR', 'ประกายไฟฟ้าที่กระโดดไปมาไม่หยุด'],
  ['prakaifa', 'ประกายฟ้า',   'bolt',  2, 'INT', 'สายฟ้าเส้นบางที่ค้างอยู่กลางอากาศ'],
  ['fakhamram','ฟ้าคำราม',    'bolt',  3, 'VIT', 'เสียงฟ้าร้องที่กลายร่างได้ ดังแต่ขี้อาย'],
  ['wachira',  'วชิระ',       'bolt',  4, 'LUK', 'สายฟ้าที่แข็งเป็นเพชร ผ่าอะไรก็ได้'],

  ['saengngoen','แสงเงิน',    'light', 1, 'INT', 'แสงแรกของเช้า จางแต่ไม่เคยขาด'],
  ['thonguarai','ทองอุไร',    'light', 2, 'VIT', 'ดอกไม้สีทองที่บานรับแดดบ่าย'],
  ['prakai',   'ประกาย',      'light', 2, 'AGI', 'เศษแสงที่กระเด็นออกมาแล้วไม่ยอมกลับ'],
  ['rungarun', 'รุ่งอรุณ',    'light', 3, 'STR', 'ขอบฟ้าตอนตีห้า อบอุ่นจนคนตื่นเอง'],

  ['ngaowai',  'เงาไหว',      'shade', 1, 'AGI', 'เงาของใครสักคนที่หลุดออกมาเดินเอง'],
  ['mokklum',  'หมอกคลุ้ม',   'shade', 2, 'VIT', 'หมอกเช้าที่ไม่ยอมจางแม้แดดออก'],
  ['ratri',    'ราตรี',       'shade', 2, 'LUK', 'ความเงียบตอนตีสาม เป็นเพื่อนที่ดีกว่าที่คิด'],
  ['asunngao', 'อสูรเงา',     'shade', 3, 'STR', 'อะไรบางอย่างในซากเจดีย์ที่ยอมตามคุณกลับบ้าน'],
];

/* ---- แปลงเป็นข้อมูลเต็ม พร้อมสีและลักษณะที่สุ่มคงที่ ---- */
const BODY_SHAPES = ['round','tall','tear','chunky'];
const HORNS  = ['none','pair','single','curved','antler'];
const EARS   = ['none','leaf','long','fin'];
const TAILS  = ['none','wisp','plume','curl'];
const MARKS  = ['none','spots','stripes','veins'];

function clampN(v,a,b){ return Math.max(a, Math.min(b, v)); }
function _hsl(h, s, l){ return `hsl(${((Math.round(h)%360)+360)%360}, ${clampN(Math.round(s),6,92)}%, ${clampN(Math.round(l),8,94)}%)`; }
function _hsla(h, s, l, a){ return `hsla(${((Math.round(h)%360)+360)%360}, ${clampN(Math.round(s),6,92)}%, ${clampN(Math.round(l),8,94)}%, ${a})`; }

const SPECIES = {};
const SP_KEYS = [];
SP_RAW.forEach(row => {
  const [id, name, elk, rar, sub, desc] = row;
  const E = ELEMENTS[elk];
  const idxInEl = SP_RAW.filter(r => r[2] === elk).findIndex(r => r[0] === id);
  const r = rngFrom(hashStr('sp:' + id));

  const h = E.h + [-16, 0, 14, 30][idxInEl] + Math.round((r() - .5) * 10);
  const s = E.s + Math.round((r() - .3) * 14) + (rar - 1) * 5;
  const l = E.l + Math.round((r() - .5) * 12) - (rar === 4 ? 4 : 0);

  SPECIES[id] = {
    id, name, elk, el: E.n, g: E.g,
    main: E.main, sub, rarity: rar, desc,
    hue: h, sat: s, lum: l,
    c1:     _hsl(h, s, l),
    c2:     _hsl(h + 6, s + 8, l - 20),
    accent: _hsl(h - 6, s - 6, l + 22),
    dim:    _hsla(h, s, l, .30),
    a: al => _hsla(h - 6, s - 6, l + 22, al),
    traits: {
      body: BODY_SHAPES[Math.floor(r() * BODY_SHAPES.length)],
      horn: rar >= 3 ? HORNS[1 + Math.floor(r() * (HORNS.length - 1))] : HORNS[Math.floor(r() * HORNS.length)],
      ear:  EARS[Math.floor(r() * EARS.length)],
      tail: rar >= 2 ? TAILS[1 + Math.floor(r() * (TAILS.length - 1))] : TAILS[Math.floor(r() * TAILS.length)],
      mark: MARKS[Math.floor(r() * MARKS.length)],
      halo: rar >= 4,
    }
  };
  SP_KEYS.push(id);
});

const SP_BY_RARITY = r => SP_KEYS.filter(k => SPECIES[k].rarity === r);
const SP_BY_EL = e => SP_KEYS.filter(k => SPECIES[k].elk === e);

/* ===================== ขั้นการเติบโต ===================== */
const BRANCHES = { body:'กายา', mind:'ฌาน', play:'ระบำ' };
const STAGE_NAMES = ['เมล็ด','หน่อ','ผลิใบ','','',''];
const STAGE_LV    = [1, 5, 12, 22, 35, 50];
const STAGE3_NAME = { body:'ร่างกายา', mind:'ร่างฌาน', play:'ร่างระบำ' };
const STAGE4_NAME = { body:'ผู้พิทักษ์', mind:'ผู้ตื่นรู้', play:'ผู้ร่ายรำ' };
const STAGE5_NAME = 'ร่างโบราณ';

function formId(sp, stage, branch){
  return stage <= 2 ? `${sp}:${stage}` : `${sp}:${stage}:${branch}`;
}
function formName(sp, stage, branch){
  const b = SPECIES[sp].name;
  if (stage <= 2) return `${b} ${STAGE_NAMES[stage]}`;
  if (stage === 3) return `${b} ${STAGE3_NAME[branch]}`;
  if (stage === 4) return `${b} ${STAGE4_NAME[branch]}`;
  return `${b} ${STAGE5_NAME}`;
}
// ร่างทั้งหมด: 32 สายพันธุ์ × 10 ร่าง = 320
const ALL_FORMS = (() => {
  const out = [];
  for (const sp of SP_KEYS){
    out.push({id:formId(sp,0), sp, stage:0, branch:null});
    out.push({id:formId(sp,1), sp, stage:1, branch:null});
    out.push({id:formId(sp,2), sp, stage:2, branch:null});
    for (const br of Object.keys(BRANCHES)){
      out.push({id:formId(sp,3,br), sp, stage:3, branch:br});
      out.push({id:formId(sp,4,br), sp, stage:4, branch:br});
    }
    out.push({id:formId(sp,5,'anc'), sp, stage:5, branch:'anc'});
  }
  return out;
})();
const FORMS_BY_SP = {};
for (const f of ALL_FORMS){ (FORMS_BY_SP[f.sp] = FORMS_BY_SP[f.sp] || []).push(f); }

/* ===================== ไอเทม ===================== */
const ITEMS = {
  leaf:    {n:'ใบอ่อน',        g:'🌿', t:'food', hunger:18, mood:3,  aff:1, sell:6,   d:'อาหารพื้นฐาน หาได้ทั่วไป'},
  berry:   {n:'ลูกหว้า',       g:'🫐', t:'food', hunger:30, mood:8,  aff:2, sell:14,  d:'หวานฉ่ำ วิญญาณส่วนใหญ่ชอบ'},
  ricecake:{n:'ข้าวต้มมัด',    g:'🍡', t:'food', hunger:40, mood:12, aff:3, sell:26,  d:'ทำจากข้าวเหนียวกับกล้วย'},
  honey:   {n:'น้ำผึ้งป่า',    g:'🍯', t:'food', hunger:48, mood:16, aff:4, sell:34,  d:'อิ่มนานและอารมณ์ดีขึ้นมาก'},
  nectar:  {n:'น้ำค้างดอกไม้', g:'🌸', t:'food', hunger:60, mood:22, aff:7, sell:70,  d:'อาหารชั้นดี วิญญาณหายากกินแล้วสนิทเร็ว'},

  driedfish:{n:'ปลาแห้งย่าง',  g:'🐟', t:'food', hunger:55, mood:2,  aff:1, sell:22,  d:'อิ่มท้องมากแต่รสจืด เหมาะเวลาหิวจัด'},
  meatball:{n:'ลูกชิ้นปิ้ง',   g:'🍢', t:'food', hunger:28, mood:12, aff:2, sell:16,  d:'ของกินเล่นหน้าโรงเรียน ราคาถูกแต่คุ้ม'},
  popchick:{n:'ไก่ป๊อบ',       g:'🍗', t:'food', hunger:38, mood:22, aff:3, sell:38,  d:'ทอดกรอบร้อนๆ วิญญาณตัวไหนก็ชอบ'},
  chocolate:{n:'ช็อกโกแลต',    g:'🍫', t:'food', hunger:12, mood:28, aff:4, boost:3, sell:52, d:'หวานและให้พลังงานเร็ว ตื่นตัวจนได้ประสบการณ์เพิ่ม 25% ในการตอบคำถาม 3 รอบถัดไป'},
  sweetsoup:{n:'บัวลอยน้ำขิง',  g:'🍮', t:'food', hunger:15, mood:30, aff:5, sell:44,  d:'อิ่มไม่มากแต่ทำให้อารมณ์ดีขึ้นมาก'},

  balm:    {n:'ยาหม่องสมุนไพร', g:'🧴', t:'heal', heal:35, sell:30,  d:'รักษาบาดแผลจากการสำรวจ'},
  antidote:{n:'ยาถอนพิษ',      g:'🧪', t:'heal', heal:20, cure:true, sell:55, d:'ถอนอาการป่วยได้ทันทีแม้สุขภาพยังไม่ถึงเกณฑ์'},
  tonic:   {n:'ยาต้มบำรุงกำลัง', g:'🍵', t:'heal', heal:55, guard:1, sell:75, d:'ฟื้นสุขภาพและกันบาดเจ็บจากการสำรวจครั้งถัดไปหนึ่งครั้ง'},
  elixir:  {n:'ยาต้มโบราณ',    g:'⚗️', t:'heal', heal:100, mood:10, sell:90, d:'ฟื้นสุขภาพเต็มทันที'},

  mainfruit:{n:'ผลไม้บำรุงธาตุ', g:'🍑', t:'stat', target:'main', up:2, sell:0, d:'เพิ่มค่าสถานะหลักของวิญญาณอย่างถาวร 2 หน่วย'},
  subfruit:{n:'ผลไม้บำรุงรอง',  g:'🍈', t:'stat', target:'sub',  up:2, sell:0, d:'เพิ่มค่าสถานะรองของวิญญาณอย่างถาวร 2 หน่วย'},

  charm_b: {n:'เครื่องรางกายา', g:'🧿', t:'care', br:'body', up:10, sell:0, d:'ผลักเส้นทางวิวัฒนาการไปทางสายกายา 10 หน่วย'},
  charm_m: {n:'เครื่องรางฌาน',  g:'📿', t:'care', br:'mind', up:10, sell:0, d:'ผลักเส้นทางวิวัฒนาการไปทางสายฌาน 10 หน่วย'},
  charm_p: {n:'เครื่องรางระบำ', g:'🎏', t:'care', br:'play', up:10, sell:0, d:'ผลักเส้นทางวิวัฒนาการไปทางสายระบำ 10 หน่วย'},

  dewdrop: {n:'น้ำทิพย์เร่งฟัก', g:'💧', t:'eggboost', up:150, sell:0, d:'เติมคะแนนฐานให้ไข่ทันที 150 โดยไม่เปลี่ยนธาตุที่สะสมไว้'},
  compass: {n:'เข็มทิศเก่า',    g:'🧭', t:'explore', sell:0, d:'เรียกวิญญาณที่ออกสำรวจกลับทันทีโดยได้ของครบเหมือนรอจนหมดเวลา'},

  mop:     {n:'ไม้ถูพื้น',     g:'🧹', t:'tool', sell:0, buy:320, d:'ใช้ซ้ำได้ไม่มีวันหมด ถูบ้านได้วันละครั้ง อารมณ์ +15 สุขภาพ +8 และหายป่วยทันที'},

  clay:    {n:'ดินเหนียว',     g:'🟤', t:'mat', sell:8,   d:'วัสดุสร้างของตกแต่ง'},
  bamboo:  {n:'ไม้ไผ่',        g:'🎋', t:'mat', sell:12,  d:'เหนียว ทนทาน ใช้ต่อของได้สารพัด'},
  shard:   {n:'เศษสังคโลก',    g:'🏺', t:'mat', sell:26,  d:'เศษเครื่องเคลือบจากเตาเก่า'},
  silk:    {n:'ไหมป่า',        g:'🧵', t:'mat', sell:40,  d:'เส้นใยเงางาม หายากพอสมควร'},
  relic:   {n:'ลูกปัดโบราณ',   g:'🔗', t:'mat', sell:120, d:'พบได้เฉพาะในซากเจดีย์'},

  stone_b: {n:'หินกายา',       g:'🟩', t:'stone', br:'body', sell:0, d:'ใช้ปลุกร่างโบราณสายกายา'},
  stone_m: {n:'หินฌาน',        g:'🟦', t:'stone', br:'mind', sell:0, d:'ใช้ปลุกร่างโบราณสายฌาน'},
  stone_p: {n:'หินระบำ',       g:'🟪', t:'stone', br:'play', sell:0, d:'ใช้ปลุกร่างโบราณสายระบำ'},

  seed_r:  {n:'ไข่ธรรมดา',     g:'🥚', t:'egg', tier:1, need:400,  sell:0, d:'ฟักด้วยคะแนนฐาน 400 วิชาที่ตอบระหว่างฟักเป็นตัวกำหนดธาตุ'},
  seed_g:  {n:'ไข่ลายหิน',     g:'🪺', t:'egg', tier:2, need:1600,  sell:0, d:'ต้องคะแนนฐาน 1,600 แต่โอกาสได้สายพันธุ์หายากสูงขึ้นมาก'},
  seed_m:  {n:'ไข่ปริศนา',     g:'🔮', t:'egg', tier:3, need:5000, sell:0, d:'ต้องคะแนนฐาน 5,000 และไม่มีสายพันธุ์ธรรมดาอยู่ในไข่ใบนี้เลย'},
};

/* ---- น้ำหนักความหายากของไข่แต่ละชั้น ---- */
const SEED_ODDS = {
  1: {1:62, 2:30, 3:7,  4:1},
  2: {1:18, 2:47, 3:29, 4:6},
  3: {1:0,  2:24, 3:53, 4:23},
};

/* ===================== โซนสำรวจ ===================== */
const ZONES = [
  { id:'grove',  n:'ป่าละเมาะหลังบ้าน', g:'🌾', min:5,  lv:1,  risk:.06,
    d:'ทุ่งหญ้าเตี้ยๆ ปลอดภัย เหมาะกับวิญญาณที่เพิ่งงอก',
    loot:[['leaf',.55],['clay',.30],['berry',.22],['bamboo',.14]] },
  { id:'canal',  n:'ริมคลองเก่า',       g:'🛶', min:12, lv:6,  risk:.12,
    d:'น้ำนิ่ง เงาไม้ทอด มีของตกหล่นจากเรือสมัยก่อน',
    loot:[['berry',.45],['bamboo',.34],['clay',.26],['shard',.16],['ricecake',.12]] },
  { id:'mist',   n:'เนินหมอก',          g:'⛰️', min:25, lv:14, risk:.20,
    d:'ลมแรง ทัศนวิสัยต่ำ แต่ของที่พบมักมีค่า',
    loot:[['silk',.30],['shard',.28],['honey',.24],['bamboo',.22],['balm',.16],['stone_p',.05],['seed_r',.07]] },
  { id:'deep',   n:'ป่าลึกน้ำครำ',      g:'🌲', min:45, lv:24, risk:.30,
    d:'ต้นไม้สูงบังฟ้า มีอะไรบางอย่างเฝ้าอยู่',
    loot:[['silk',.36],['relic',.14],['elixir',.14],['honey',.30],['shard',.26],
          ['stone_b',.06],['stone_m',.06],['seed_r',.12],['seed_g',.05]] },
  { id:'ruin',   n:'ซากเจดีย์ร้าง',     g:'🛕', min:70, lv:34, risk:.38,
    d:'อิฐเรียงเป็นแนว ยังพอเห็นลายปูนปั้น ที่นี่เก็บของเก่าไว้เยอะ',
    loot:[['relic',.34],['silk',.30],['elixir',.20],['shard',.30],['nectar',.16],
          ['seed_g',.11],['seed_m',.04],['stone_b',.09],['stone_m',.09],['stone_p',.09]] },
];

/* ===================== เฟอร์นิเจอร์ ===================== */
const FURN = {
  mat:    {n:'เสื่อกก',         g:'🟫', cost:60,   eff:{moodSlow:.10}, d:'นั่งสบายขึ้น อารมณ์ลดช้าลง 10%'},
  jar:    {n:'ไหน้ำสังคโลก',    g:'🏺', cost:140,  eff:{hungerSlow:.12}, d:'มีน้ำให้จิบตลอด ความหิวลดช้าลง 12%'},
  lamp:   {n:'โคมกระดาษ',       g:'🏮', cost:180,  eff:{light:1}, d:'กลางคืนห้องจะสว่าง และอารมณ์ +2 ทุกชั่วโมง'},
  shelf:  {n:'ชั้นวางไม้ไผ่',   g:'🪜', cost:220,  eff:{exploreLuck:.10}, d:'จัดของเป็นระเบียบ โอกาสได้ของหายาก +10%'},
  bonsai: {n:'ไม้ดัดกระถางเล็ก', g:'🌳', cost:300, eff:{focusXp:.08}, d:'มองแล้วใจสงบ ค่าประสบการณ์จากโฟกัส +8%'},
  incense:{n:'กระถางธูป',       g:'🕯️', cost:420,  eff:{focusXp:.12,moodSlow:.06}, d:'กลิ่นช่วยตั้งสมาธิ โฟกัส +12%'},
  scroll: {n:'ภาพเขียนม้วน',    g:'🖼️', cost:560,  eff:{aff:.15}, d:'ความสนิทที่ได้รับ +15%'},
  gong:   {n:'ฆ้องเล็ก',        g:'🔔', cost:700,  eff:{focusXp:.10,coin:.12}, d:'โฟกัส +10% และเหรียญที่ได้ +12%'},
  pond:   {n:'บ่อบัวจิ๋ว',      g:'🪷', cost:900,  eff:{hungerSlow:.15,moodSlow:.15}, d:'ความหิวและอารมณ์ลดช้าลงอย่างละ 15%'},
  chime:  {n:'กระดิ่งลม',       g:'🎐', cost:1200, eff:{exploreLuck:.18}, d:'เสียงนำทาง โอกาสได้ของหายาก +18%'},

  hammock:{n:'เปลผ้าไหม',       g:'🛏️', cost:250,  eff:{rest:3}, d:'ฟื้นสุขภาพเองชั่วโมงละ 3 หน่วยแม้ปิดเกม'},
  stove:  {n:'เตาถ่านดินเผา',   g:'🔥', cost:380,  eff:{foodBoost:.25}, d:'อุ่นอาหารก่อนให้ ความอิ่มที่ได้จากอาหารทุกชนิด +25%'},
  bookcase:{n:'ตู้หนังสือไม้สัก', g:'📚', cost:520, eff:{focusXp:.15}, d:'ค่าประสบการณ์จากการตอบคำถาม +15%'},
  rack:   {n:'ชั้นวางดาบไม้',   g:'🗡️', cost:660,  eff:{duelAtk:.12}, d:'ฝึกซ้อมทุกวัน พลังโจมตีในการดวล +12%'},
  mirror: {n:'กระจกเงาโบราณ',   g:'🪞', cost:660,  eff:{duelDef:.12}, d:'อ่านทางคู่ต่อสู้ได้ เกราะในการดวล +12%'},
  loom:   {n:'กี่ทอผ้า',        g:'🧶', cost:780,  eff:{exploreLuck:.12, coin:.10}, d:'แปรรูปของที่เก็บมา ของหายาก +12% และเหรียญ +10%'},
  altar:  {n:'หิ้งบูชาไม้จันทน์', g:'🛕', cost:880, eff:{crystal:.35}, d:'มีโอกาส 35% ได้ผลึกสมาธิเพิ่มอีก 1 เม็ดเมื่อจบรอบ'},
  sundial:{n:'นาฬิกาแดดหิน',    g:'⏳', cost:1050, eff:{exploreFast:.20}, d:'เวลาที่ใช้ในการสำรวจลดลง 20%'},
  nest:   {n:'รังฟางอุ่น',      g:'🪹', cost:1150, eff:{eggBoost:.15}, d:'ไข่ได้รับคะแนนฐานเพิ่มขึ้น 15%'},
  bodhi:  {n:'ต้นโพธิ์ประจำบ้าน', g:'🌲', cost:1600, eff:{moodSlow:.12, rest:2, aff:.10}, d:'ร่มเย็นทั้งบ้าน อารมณ์ลดช้าลง 12% ฟื้นสุขภาพชั่วโมงละ 2 และความสนิท +10%'},
};

/* จำนวนช่องวางของตกแต่งในบ้าน */
const ROOM_SLOTS = 16;

/* ===================== รอบตอบคำถาม ===================== */
const ROUND_LEN = 10;            // จำนวนข้อต่อหนึ่งรอบ
const STREAK_CAP = 10;           // สตรีคที่ให้ตัวคูณสูงสุด ×2
const SPEED_BONUS_MAX = 0.5;     // โบนัสความเร็วสูงสุด +50%
const REPEAT_PENALTY = 0.25;     // ตอบข้อเดิมซ้ำในวันเดียวกันได้คะแนนเท่านี้
const LEITNER_GAP = [0, 0, 3, 8, 20, 50];  // ต้องผ่านไปกี่ข้อจึงจะถามซ้ำ

/* ===================== ร้านผลึกสมาธิ ===================== */
const CRYSTAL_SHOP = [
  {k:'seed_r', cost:10},
  {k:'seed_g', cost:32},
  {k:'seed_m', cost:90},
  {k:'dewdrop', cost:7},
  {k:'mainfruit', cost:14},
  {k:'subfruit', cost:11},
  {k:'charm_b', cost:9},
  {k:'charm_m', cost:9},
  {k:'charm_p', cost:9},
  {k:'compass', cost:5},
  {k:'nectar', cost:6},
  {k:'elixir', cost:4},
];
const GARDEN_MAX = 6;


/* ===========================================================
   อาวุธและเครื่องแต่งกาย — ซื้อด้วยเหรียญ ใส่ได้ทีละหนึ่งชิ้น
   ราคาไล่ระดับแบบทวีคูณ ชิ้นท้ายๆ ต้องเก็บเงินหลายวัน
   =========================================================== */
const WEAPONS = {
  w1: {n:'ไม้เท้าไผ่',        g:'🥢', tier:1, cost:150,   atkPct:.05, statKey:'STR', statUp:1, d:'อาวุธเริ่มต้น น้ำหนักเบา ใช้ฝึกมือ'},
  w2: {n:'มีดสั้นหินเหล็กไฟ', g:'🔪', tier:1, cost:450,   atkPct:.14, statKey:'AGI', statUp:2, dodgePct:.03, d:'คมกริบและคล่องตัว เพิ่มโอกาสหลบ 3%'},
  w3: {n:'ตะบองไม้แก่น',      g:'🏏', tier:2, cost:1100,  atkPct:.15, statKey:'STR', statUp:2, d:'หนักแน่น เหมาะกับสายพลัง'},
  w4: {n:'หอกด้ามยาว',        g:'🔱', tier:2, cost:2400,  atkPct:.20, statKey:'INT', statUp:3, d:'แทงได้ไกล อาศัยจังหวะและการคำนวณ'},
  w5: {n:'ดาบสั้นสำริด',      g:'🗡️', tier:3, cost:4800,  atkPct:.26, statKey:'STR', statUp:3, d:'หลอมจากสำริดโบราณ คมและทนทาน'},
  w6: {n:'ขวานรบ',           g:'🪓', tier:3, cost:8500,  atkPct:.33, statKey:'STR', statUp:4, d:'ฟันแรง แต่ต้องใช้กำลังมาก'},
  w7: {n:'ดาบยาวเหล็กกล้า',   g:'⚔️', tier:4, cost:15000, atkPct:.40, statKey:'STR', statUp:5, dodgePct:.05, d:'สมดุลทั้งแรงและไว เพิ่มโอกาสหลบ 5%'},
  w8: {n:'คทาเวทมนตร์',       g:'🪄', tier:4, cost:26000, atkPct:.48, statKey:'INT', statUp:10, critPct:.05, d:'แปลงพลังจิตเป็นแรงโจมตี เพิ่มโอกาสเข้าเต็มแรง 5%'},
  w9: {n:'ทวนมังกร',         g:'🐉', tier:5, cost:45000, atkPct:.58, statKey:'STR', statUp:6, critPct:.12, d:'สลักลายมังกรโบราณ เพิ่มโอกาสเข้าเต็มแรง 12%'},
  w10:{n:'ดาบเทวะ',          g:'🌟', tier:5, cost:80000, atkPct:.72, statKey:'STR', statUp:10, critPct:.08, dodgePct:.05, d:'ตำนานว่าตีขึ้นจากเศษดาวตก แรงที่สุดในทุกด้าน'},
};
const ARMORS = {
  a1: {n:'เสื้อผ้าฝ้ายเสริมแผ่น', g:'🧥', tier:1, cost:300,   defPct:.08, hp:10, guard:.02, statUp:1, d:'เกราะเริ่มต้น ใส่สบาย ป้องกันได้เล็กน้อย'},
  a2: {n:'เกราะหนังสัตว์',       g:'🦺', tier:2, cost:2200,  defPct:.18, hp:24, guard:.05, statUp:3, d:'หนังฟอกอย่างดี เหนียวและยืดหยุ่น'},
  a3: {n:'เกราะเกล็ดสำริด',      g:'🛡️', tier:3, cost:9000,  defPct:.32, hp:45, guard:.09, statUp:6, d:'เกล็ดสำริดเรียงซ้อนกันแน่นหนา'},
  a4: {n:'เกราะเหล็กเต็มตัว',    g:'⛓️', tier:4, cost:28000, defPct:.48, hp:72, guard:.13, statUp:10, d:'หนักแต่ป้องกันได้แทบทุกทิศทาง'},
  a5: {n:'เกราะเทพศักดิ์สิทธิ์',  g:'✨', tier:5, cost:70000, defPct:.70, hp:110, guard:.20, statUp:16, d:'ผ่านพิธีปลุกเสกจากสายวิญญาณโบราณ'},
};
const TIER_NAME = [null,'ต้น','กลาง','สูง','ยอด','ตำนาน'];
const TIER_COLOR = [null,'#9fb6ac','#7fb6c9','#c9a24a','#c98ad4','#e8b4d8'];
