/* ===========================================================
   ระบบภาพตัวละคร
   โหลดภาพจากโฟลเดอร์ art/ เฉพาะตัวที่ใช้จริง เกมจึงยังเบา
   ถ้าโหลดไม่ได้จะถอยไปวาดด้วยโค้ดแบบเดิมอัตโนมัติ

   วิธีเพิ่มตัวใหม่ — ไม่ต้องแก้โค้ดเลย
   1. สร้างโฟลเดอร์ art/<ชื่ออังกฤษ>/ แล้วใส่ 1.png 2.png ...
   2. เติมข้อมูลใน ART_BOOK ด้านล่างนี้
   =========================================================== */

/* ที่อยู่ของโฟลเดอร์ภาพ เทียบกับไฟล์ index.html */
const ART_BASE = 'art/';

/* ทะเบียนตัวละครที่มีภาพแล้ว
   key      ชื่อโฟลเดอร์
   n        ชื่อไทยที่แสดงในเกม
   skill    ทักษะ (จดจำ ค้นคว้า เชื่อมโยง แยกแยะ กล้าหาญ รับผิดชอบ)
   rarity   ความหายาก 1-4
   main/sub ค่าสถานะหลักและรอง
   stages   ชื่อแต่ละขั้น จำนวนขั้นนับจากความยาวรายการนี้             */
const ART_BOOK = {
  bandit: {
    n:'บัณฑิต', skill:'memory', rarity:3, main:'INT', sub:'VIT',
    stages:[
      { n:'ลบเลือน',       d:'ยางลบน้อยที่ยอมหายไปทีละนิดเพื่อให้คนอื่นได้เริ่มใหม่' },
      { n:'โต๊ะร้าง',      d:'โต๊ะเรียนตัวเปล่าที่รอใครสักคนมานั่ง' },
      { n:'โต๊ะตำรา',      d:'เริ่มมีหนังสือวางแล้ว ความรู้ค่อยๆ สะสม' },
      { n:'โต๊ะรัตติกาล',  d:'มีโคมไฟส่องถึงดึก คนที่ไม่ยอมหยุดเรียนรู้' },
      { n:'พลไม้เนื้ออ่อน', d:'ลุกขึ้นยืนได้แล้ว ยังไม่แข็งแรงแต่กล้าสู้' },
      { n:'ขุนพลปากกา',    d:'ถืออาวุธเป็นดินสอ มีโล่หัวปากกา' },
      { n:'ราชันอักษร',    d:'สวมมงกุฎ ปกครองด้วยความรู้ไม่ใช่กำลัง' },
      { n:'เทพวิทยาธร',    d:'ปีกเป็นหน้าหนังสือ ดาบเป็นปากกา' },
    ],
  },
  bag: {
    n:'เป้ภาระ', skill:'duty', rarity:2, main:'VIT', sub:'STR',
    stages:[
      { n:'กระเป๋าผ้า',  d:'ใบเล็กที่ใส่ได้แค่สมุดเล่มเดียว แต่ไม่เคยทำหาย' },
      { n:'เป้นักเรียน', d:'มีช่องแยกเป็นระเบียบ เริ่มแบกของได้มากขึ้น' },
      { n:'เป้เดินป่า',  d:'ไปได้ไกลขึ้น แบกได้หนักขึ้น ไม่บ่นสักคำ' },
      { n:'เป้ยุทธวิธี', d:'พร้อมทุกสถานการณ์ มีของที่จำเป็นครบเสมอ' },
      { n:'เป้คริสตัล',  d:'แบกความรับผิดชอบจนกลายเป็นเกราะของตัวเอง' },
    ],
  },
  ruler: {
    n:'มาตรา', skill:'judge', rarity:2, main:'STR', sub:'INT',
    stages:[
      { n:'ไม้บรรทัดไม้',   d:'เครื่องมือวัดชิ้นแรกของเด็กทุกคน' },
      { n:'ไม้บรรทัดเหล็ก', d:'แข็งแรงขึ้น ขีดเส้นได้ตรงกว่าเดิม' },
      { n:'วงเวียน',        d:'วัดได้ทั้งระยะและมุม เริ่มเห็นสิ่งที่ตาเปล่าไม่เห็น' },
      { n:'เครื่องวัดเลเซอร์', d:'ความเที่ยงตรงระดับที่ไม่มีใครเถียงได้' },
      { n:'ดาบมาตรฐาน',    d:'ความเที่ยงตรงที่กลายเป็นอาวุธ ตัดสิ่งผิดออกจากสิ่งถูก' },
    ],
  },
};

/* ทักษะทั้งหก แทนที่ระบบธาตุเดิม */
const SKILLS = {
  memory:  { n:'จดจำ',      g:'🧠', h:266, s:38, l:62 },
  search:  { n:'ค้นคว้า',   g:'🔍', h:205, s:40, l:60 },
  link:    { n:'เชื่อมโยง', g:'🔗', h:152, s:34, l:56 },
  judge:   { n:'แยกแยะ',    g:'⚖️', h:38,  s:58, l:58 },
  brave:   { n:'กล้าหาญ',   g:'🔥', h:12,  s:56, l:58 },
  duty:    { n:'รับผิดชอบ', g:'🛡️', h:96,  s:22, l:52 },
};

/* วงจรข่มกัน — เรียงตามลำดับการเรียนรู้จริง
   จดจำ → ค้นคว้า → เชื่อมโยง → แยกแยะ → กล้าหาญ → รับผิดชอบ → จดจำ */
const SKILL_BEATS = {
  memory:['search'], search:['link'], link:['judge'],
  judge:['brave'],   brave:['duty'],  duty:['memory'],
};
const SKILL_WHY = {
  'memory>search':'ถ้าจำข้อมูลพื้นฐานไม่ได้ ค้นเท่าไรก็ไม่เข้าใจ',
  'search>link'  :'เชื่อมโยงโดยไม่มีข้อมูลคือการเดา',
  'link>judge'   :'ต้องเห็นภาพรวมก่อนจึงแยกแยะถูกผิดได้',
  'judge>brave'  :'กล้าโดยไม่แยกแยะคือความหุนหัน',
  'brave>duty'   :'รู้หน้าที่แต่ไม่กล้าทำก็ไม่เกิดอะไรขึ้น',
  'duty>memory'  :'ความรับผิดชอบทำให้กลับมาทบทวนซ้ำจนจำได้จริง',
};

/* ---------- คลังภาพที่โหลดแล้ว ---------- */
const ART_CACHE = {};      // 'bandit:3' -> Image | 'fail'

function artPath(key, stage){ return `${ART_BASE}${key}/${stage + 1}.png`; }

/* มีภาพสำหรับตัวนี้ขั้นนี้ไหม */
function hasArt(key, stage){
  const b = ART_BOOK[key];
  if (!b) return false;
  return stage >= 0 && stage < b.stages.length;
}

/* ขอภาพ ถ้ายังไม่โหลดจะเริ่มโหลดแล้วคืน null ไปก่อน
   เมื่อโหลดเสร็จจะวาดใหม่เอง */
function getArt(key, stage){
  if (!hasArt(key, stage)) return null;
  const id = key + ':' + stage;
  const hit = ART_CACHE[id];
  if (hit === 'fail') return null;
  if (hit) return hit.complete && hit.naturalWidth > 0 ? hit : null;

  const img = new Image();
  ART_CACHE[id] = img;
  img.onerror = () => { ART_CACHE[id] = 'fail'; };
  img.onload = () => { if (typeof render === 'function') render(); };
  img.src = artPath(key, stage);
  return null;
}

/* โหลดภาพขั้นถัดไปล่วงหน้า เพื่อให้ตอนวิวัฒนาการไม่กระตุก */
function preloadNextArt(key, stage){
  if (hasArt(key, stage + 1)) getArt(key, stage + 1);
}

/* ---------- ข้อมูลตัวละครสำหรับใช้ในเกม ---------- */
function artSpecies(key){
  const b = ART_BOOK[key];
  if (!b) return null;
  const sk = SKILLS[b.skill];
  return {
    key, name: b.n, rarity: b.rarity, main: b.main, sub: b.sub,
    skill: b.skill, art: true,
    g: sk.g,
    h: sk.h, s: sk.s, l: sk.l,
    dim: `hsla(${sk.h},${sk.s}%,${sk.l}%,.30)`,
    a: (o) => `hsla(${sk.h},${sk.s}%,${sk.l + 18}%,${o})`,
    stages: b.stages,
    maxStage: b.stages.length - 1,
  };
}
function artStageName(key, stage){
  const b = ART_BOOK[key];
  if (!b || !b.stages[stage]) return '';
  return b.stages[stage].n;
}
function artStageDesc(key, stage){
  const b = ART_BOOK[key];
  if (!b || !b.stages[stage]) return '';
  return b.stages[stage].d;
}

/* ตัวคูณความเสียหายจากทักษะข่มกัน ใช้ค่าเดียวกับระบบธาตุเดิม */
function skillMul(a, b){
  if (!a || !b) return 1;
  if ((SKILL_BEATS[a] || []).includes(b)) return ADV_UP;
  if ((SKILL_BEATS[b] || []).includes(a)) return ADV_DOWN;
  return 1;
}
function skillLabel(a, b){
  const m = skillMul(a, b);
  if (m > 1) return { t:'ข่มได้', c:'var(--ok)', why: SKILL_WHY[a + '>' + b] || '' };
  if (m < 1) return { t:'ถูกข่ม', c:'var(--bad)', why: SKILL_WHY[b + '>' + a] || '' };
  return null;
}

/* ---------- วาดภาพตัวละครลงแคนวาส ----------
   คืน true ถ้าวาดด้วยภาพสำเร็จ คืน false ถ้าต้องถอยไปวาดด้วยโค้ด */
function drawArtSpirit(t, p, sp, opt){
  const key = p.sp;
  if (!ART_BOOK[key]) return false;
  const img = getArt(key, p.stage);
  if (!img) return false;

  const o = opt || {};
  const cx = o.cx || CW / 2;
  const scale = (o.scale || 1);
  const happy = p.mood > 60 && p.hp > 40;
  const breathe = Math.sin(t * 1.6) * 2.5;
  const hop = happy ? Math.abs(Math.sin(t * 2.2)) * 5 : 0;

  /* ขนาดโตขึ้นตามขั้น แต่ไม่เกินกรอบ */
  const b = ART_BOOK[key];
  const step = b.stages.length > 1 ? p.stage / (b.stages.length - 1) : 0;
  const H = (128 + step * 78) * scale;
  const W = H * (img.naturalWidth / img.naturalHeight);

  /* เท้าอยู่บนเส้นพื้นเดียวกันเสมอ ไม่ว่าตัวจะโตแค่ไหน */
  const groundY = 246;
  const cy = groundY - H + breathe * 0.5 - hop + View.bounce;

  ctx.save();
  if (p === S.pet && typeof isAsleep === 'function' && isAsleep()) ctx.globalAlpha = 0.45;

  /* เงาใต้เท้า */
  ctx.save();
  ctx.globalAlpha *= 0.30;
  ctx.fillStyle = '#000';
  ctx.beginPath();
  ctx.ellipse(cx, groundY + 3, W * 0.34, H * 0.045, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  /* แสงเรืองสำหรับตัวหายาก */
  if (sp && sp.rarity >= 3){
    ctx.shadowColor = sp.a(.55);
    ctx.shadowBlur = 14 + sp.rarity * 4;
  }

  ctx.translate(cx, cy + H / 2);
  if (o.flip) ctx.scale(-1, 1);
  ctx.imageSmoothingEnabled = false;      /* รักษาความคมของพิกเซลอาร์ต */
  ctx.drawImage(img, -W / 2, -H / 2, W, H);
  ctx.restore();

  preloadNextArt(key, p.stage);
  return true;
}


/* ===========================================================
   ลงทะเบียนตัวละครที่มีภาพเข้าระบบสายพันธุ์เดิม
   ทำให้ทุกอย่างที่มีอยู่ใช้ได้ทันที ทั้งฟักไข่ ดวล สวน สมุดสะสม
   =========================================================== */
(function registerArtSpecies(){
  if (typeof SPECIES === 'undefined') return;
  for (const key in ART_BOOK){
    const b = ART_BOOK[key];
    const sk = SKILLS[b.skill];
    const h = sk.h, s = sk.s, l = sk.l;
    const hsl  = (H,S,L) => `hsl(${H},${S}%,${L}%)`;
    const hsla = (H,S,L,A) => `hsla(${H},${S}%,${L}%,${A})`;

    SPECIES[key] = {
      id:key, name:b.n,
      art:true,                       // ธงบอกว่าตัวนี้ใช้ภาพ ไม่ใช่วาดด้วยโค้ด
      skill:b.skill,
      elk:b.skill, el:sk.n, g:sk.g,   // ใช้ช่องธาตุเดิมเก็บทักษะ ระบบอื่นจึงทำงานต่อได้
      main:b.main, sub:b.sub, rarity:b.rarity,
      desc:b.stages[0].d,
      hue:h, sat:s, lum:l,
      c1:hsl(h,s,l), c2:hsl(h+6,s+8,l-20), accent:hsl(h-6,s-6,l+22),
      dim:hsla(h,s,l,.30),
      a: al => hsla(h-6,s-6,l+22,al),
      maxStage: b.stages.length - 1,
      traits:{ body:'round', horn:'none', ear:'none', tail:'none', mark:'none', halo:b.rarity>=4 },
    };
    if (typeof SP_KEYS !== 'undefined' && !SP_KEYS.includes(key)) SP_KEYS.push(key);
    if (typeof ELEMENTS !== 'undefined' && !ELEMENTS[b.skill])
      ELEMENTS[b.skill] = { n:sk.n, g:sk.g, main:b.main, h, s, l };
  }
})();

/* สร้างทะเบียนร่างให้ตัวที่มีภาพ เพื่อให้สมุดสะสมและระบบอื่นทำงานได้ */
(function registerArtForms(){
  if (typeof FORMS_BY_SP === 'undefined') return;
  for (const key in ART_BOOK){
    const b = ART_BOOK[key];
    const forms = b.stages.map((st, i) => ({ id:`${key}:${i}`, sp:key, stage:i, branch:null }));
    FORMS_BY_SP[key] = forms;
    if (typeof ALL_FORMS !== 'undefined') forms.forEach(f => ALL_FORMS.push(f));
    if (typeof EL_KEYS !== 'undefined' && !EL_KEYS.includes(b.skill)) EL_KEYS.push(b.skill);
  }
})();

/* รวมวงจรทักษะเข้ากับวงจรธาตุเดิม เพื่อให้ระบบดวลที่มีอยู่ใช้ได้ทันที
   ทั้งสองวงจรแยกกันอิสระ ธาตุข่มธาตุ ทักษะข่มทักษะ ข้ามกันไม่ได้ */
(function mergeSkillCycle(){
  if (typeof EL_BEATS === 'undefined') return;
  for (const k in SKILL_BEATS){
    if (!EL_BEATS[k]) EL_BEATS[k] = SKILL_BEATS[k].slice();
  }
  if (typeof EL_WHY !== 'undefined'){
    for (const k in SKILL_WHY) if (!EL_WHY[k]) EL_WHY[k] = SKILL_WHY[k];
  }
})();

/* ให้ชื่อร่างของตัวที่มีภาพใช้ชื่อจากทะเบียน ไม่ใช่ชื่อร่างมาตรฐาน */
if (typeof formName === 'function'){
  const _formName = formName;
  formName = function(sp, stage, branch){
    if (ART_BOOK[sp]) return artStageName(sp, Math.min(stage, ART_BOOK[sp].stages.length - 1));
    return _formName(sp, stage, branch);
  };
}
