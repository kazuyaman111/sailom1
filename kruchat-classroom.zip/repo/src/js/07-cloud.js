/* ===========================================================
   เซฟข้ามเครื่องผ่าน Google Sheets (Apps Script)
   ครูวาง URL ของเว็บแอปที่ CLOUD_API_URL ด้านล่าง หรือให้กรอกในหน้าตั้งค่าก็ได้
   =========================================================== */

/* ครูชัชวาง URL ที่ได้จาก Apps Script ตรงนี้ แล้วนักเรียนไม่ต้องกรอกเอง */
const CLOUD_API_URL = 'https://script.google.com/macros/s/AKfycbx8sqQRJZEE__dRN3pZYqX8lZfywtXhwA-eZo8IIFkjAYcWANGlwjd1kvAAdVHSUV9u/exec';

function cloudUrl(){ return (S.cloud && S.cloud.url) || CLOUD_API_URL || ''; }
function cloudReady(){ return !!(cloudUrl() && S.cloud && S.cloud.sid); }

/* รหัสนักเรียน: ตัวอักษร ตัวเลข ขีด ยาว 3-20 ตัว */
function normStudentId(v){
  return String(v || '').trim().replace(/\s+/g, '').slice(0, 20);
}
function validStudentId(v){ return /^[A-Za-z0-9ก-๙_-]{3,20}$/.test(v); }

/* ---------- ส่งขึ้นคลาวด์ ---------- */
async function saveGameToCloud(opt){
  const quiet = opt && opt.quiet;
  if (!cloudReady()) return {err:'ยังไม่ได้ตั้งค่ารหัสนักเรียนหรือที่อยู่เซิร์ฟเวอร์'};

  S.savedAt = Date.now();
  const acc = S.stats.answered ? Math.round(S.stats.correct / S.stats.answered * 100) : 0;

  /* ย่อผลสัมฤทธิ์รายหน่วยให้กระชับ "วิชา|ชั้น|หน่วย": [ถูก, ผิด] */
  const prog = {};
  for (const k in (S.prog || {})){
    const v = S.prog[k];
    if ((v.r + v.w) > 0) prog[k] = [v.r, v.w];
  }
  const payload = {
    studentId: S.cloud.sid,
    spiritName: S.pet ? S.pet.name : 'ยังไม่ฟัก',
    level: S.pet ? S.pet.lv : 0,
    coins: Math.floor(S.coins || 0),
    stats: {
      answered: S.stats.answered || 0,
      correct: S.stats.correct || 0,
      accuracy: acc,
      rounds: S.stats.rounds || 0,
      duelWin: (S.duel && S.duel.win) || 0
    },
    savedAt: S.savedAt,
    grade: S.grade || '',
    progress: prog,       // ผลสัมฤทธิ์รายหน่วย ใช้ทำแดชบอร์ดของครู
    saveRaw: S            // ก้อนเซฟเต็ม ส่งเป็นอ็อบเจกต์ ฝั่งสคริปต์จะแปลงเป็นข้อความเอง
  };

  try {
    if (!quiet) toast('กำลังส่งข้อมูลขึ้นคลาวด์…');
    const res = await fetch(cloudUrl(), {
      method: 'POST',
      /* ใช้ text/plain เพื่อเลี่ยง CORS preflight ที่ Apps Script ไม่รองรับ */
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payload)
    });
    const out = await res.json();
    if (out.status !== 'success') return {err: out.message || 'เซิร์ฟเวอร์ปฏิเสธข้อมูล'};
    S.cloud.lastUp = Date.now();
    save();
    return {ok:true};
  } catch (e){
    return {err:'เชื่อมต่อไม่ได้ ตรวจสอบอินเทอร์เน็ตหรือที่อยู่เซิร์ฟเวอร์'};
  }
}

/* ---------- ดึงจากคลาวด์ ---------- */
async function loadGameFromCloud(){
  if (!cloudReady()) return {err:'ยังไม่ได้ตั้งค่ารหัสนักเรียนหรือที่อยู่เซิร์ฟเวอร์'};
  try {
    toast('กำลังดึงข้อมูลจากคลาวด์…');
    const res = await fetch(cloudUrl() + '?studentId=' + encodeURIComponent(S.cloud.sid));
    const out = await res.json();
    if (out.status !== 'success' || !out.data || !out.data.saveRaw)
      return {err:'ไม่พบข้อมูลของรหัสนี้บนคลาวด์'};

    let inc = out.data.saveRaw;
    if (typeof inc === 'string'){ try { inc = JSON.parse(inc); } catch(e){ return {err:'ข้อมูลบนคลาวด์เสียหาย'}; } }
    if (!inc || typeof inc !== 'object' || !inc.uid) return {err:'ข้อมูลบนคลาวด์ไม่ใช่ไฟล์เซฟของเกมนี้'};
    return {ok:true, incoming:inc, meta:out.data};
  } catch (e){
    return {err:'เชื่อมต่อไม่ได้ ตรวจสอบอินเทอร์เน็ตหรือที่อยู่เซิร์ฟเวอร์'};
  }
}

/* นำเซฟจากคลาวด์มาใช้แทนของในเครื่อง */
async function applyCloudSave(inc){
  const keepCloud = S.cloud || {};
  S = Object.assign(freshSave(), inc);
  /* คงที่อยู่เซิร์ฟเวอร์และรหัสของเครื่องนี้ไว้ ไม่เอาของเจ้าของเซฟมาทับ */
  S.cloud = Object.assign({}, inc.cloud || {}, {
    url: keepCloud.url || '',
    sid: keepCloud.sid || '',
    auto: !!keepCloud.auto,
    lastDown: Date.now()
  });
  migrateSave();
  buildCrackle(hashStr(S.uid));
  tickOffline();
  /* เขียนลงที่เก็บทันที ไม่รอตัวหน่วงของ save() */
  S.savedAt = Date.now();
  await Store.set(SAVEKEY, JSON.stringify(S));
  render();
}

/* ส่งขึ้นอัตโนมัติเมื่อจบรอบตอบคำถามหรือจบการดวล (ถ้าเปิดไว้) */
let cloudAutoTimer = null;
function cloudAutoSync(){
  if (!S.cloud || !S.cloud.auto || !cloudReady()) return;
  clearTimeout(cloudAutoTimer);
  cloudAutoTimer = setTimeout(async () => {
    const r = await saveGameToCloud({quiet:true});
    if (r && r.ok) toast('บันทึกขึ้นคลาวด์แล้ว');
  }, 1500);
}

/* ===================== หน้าจอเซฟข้ามเครื่อง ===================== */
function cloudSheet(){
  S.cloud = S.cloud || {url:'', sid:'', auto:false, lastUp:0, lastDown:0};
  const hasUrl = !!cloudUrl();
  const fmt = t => t ? fmtDate(t) : 'ยังไม่เคย';

  sheet(`<div class="eyebrow">เซฟข้ามเครื่อง</div>
    <h2>เก็บวิญญาณไว้บนคลาวด์</h2>
    <div class="sub">บันทึกความคืบหน้าไว้ที่ Google Sheets ของครู เปลี่ยนเครื่องหรือล้างเบราว์เซอร์แล้วก็ดึงกลับมาเล่นต่อได้</div>
    <div class="gap"></div>

    <div class="eyebrow">รหัสนักเรียน</div>
    <input id="cloudSid" class="fld" maxlength="20" placeholder="เช่น p5-12 หรือเลขที่ในห้อง" value="${esc(S.cloud.sid || '')}">
    <div class="tiny" style="margin-top:-4px">ใช้รหัสที่ครูกำหนดให้ ห้ามใส่ชื่อจริง เลขบัตรประชาชน หรือเบอร์โทรศัพท์</div>
    <div class="gap"></div>

    ${hasUrl ? '' : `<div class="eyebrow">ที่อยู่เซิร์ฟเวอร์ของครู</div>
      <input id="cloudUrl" class="fld" placeholder="วาง URL ที่ครูให้มา ขึ้นต้นด้วย https://script.google.com/" value="${esc((S.cloud && S.cloud.url) || '')}">
      <div class="gap"></div>`}

    <button class="btn pri block" data-act="cloudSaveSet">บันทึกการตั้งค่า</button>
    <div class="gap"></div>

    <div class="list">
      <div class="item"><div class="ic">☁️</div>
        <div class="grow"><b>ส่งขึ้นคลาวด์</b><div class="sub">ครั้งล่าสุด ${fmt(S.cloud.lastUp)}</div></div>
        <button class="btn sm ${cloudReady()?'pri':''}" data-act="cloudUp" ${cloudReady()?'':'disabled'}>ส่ง</button></div>
      <div class="item"><div class="ic">📥</div>
        <div class="grow"><b>ดึงจากคลาวด์</b><div class="sub">ครั้งล่าสุด ${fmt(S.cloud.lastDown)}</div></div>
        <button class="btn sm ${cloudReady()?'gold':''}" data-act="cloudDown" ${cloudReady()?'':'disabled'}>ดึง</button></div>
      <div class="item"><div class="ic">🔁</div>
        <div class="grow"><b>ส่งอัตโนมัติ</b><div class="sub">ส่งขึ้นคลาวด์ให้เองทุกครั้งที่จบรอบตอบคำถามหรือจบการดวล</div></div>
        <button class="btn sm ${S.cloud.auto?'on':''}" data-act="cloudAuto">${S.cloud.auto?'เปิด':'ปิด'}</button></div>
    </div>
    <div class="gap"></div>
    <div class="tiny">การดึงจากคลาวด์จะเขียนทับข้อมูลในเครื่องนี้ทั้งหมด ระบบจะเทียบเวลาให้ก่อนและถามยืนยันหากข้อมูลในเครื่องใหม่กว่า</div>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

function cloudSaveSettings(){
  const sidEl = document.getElementById('cloudSid');
  const urlEl = document.getElementById('cloudUrl');
  const sid = normStudentId(sidEl ? sidEl.value : '');
  S.cloud = S.cloud || {url:'', sid:'', auto:false, lastUp:0, lastDown:0};

  if (sid && !validStudentId(sid))
    return toast('รหัสนักเรียนใช้ได้เฉพาะตัวอักษร ตัวเลข ขีด ยาว 3-20 ตัว', 'bad');
  if (urlEl){
    const u = String(urlEl.value || '').trim();
    if (u && !/^https:\/\/script\.google\.com\//.test(u))
      return toast('ที่อยู่เซิร์ฟเวอร์ต้องขึ้นต้นด้วย https://script.google.com/', 'bad');
    S.cloud.url = u;
  }
  S.cloud.sid = sid;
  save();
  toast('บันทึกการตั้งค่าแล้ว');
  cloudSheet();
}

async function cloudDownloadFlow(){
  const r = await loadGameFromCloud();
  if (r.err) return toast(r.err, 'bad');
  const inc = r.incoming;
  const mine = S.savedAt || 0, theirs = inc.savedAt || 0;
  const sp = inc.pet ? `${inc.pet.name} Lv.${inc.pet.lv}` : 'ยังไม่ฟักไข่';
  const warn = mine > theirs + 60000;

  sheet(`<div class="eyebrow">พบข้อมูลบนคลาวด์</div>
    <h2>${esc(sp)}</h2>
    <div class="sub">รหัส ${esc(S.cloud.sid)} · ตอบไปแล้ว ${(inc.stats && inc.stats.answered) || 0} ข้อ · เหรียญ ${Math.floor(inc.coins || 0).toLocaleString('th-TH')}</div>
    <div class="gap"></div>
    <div class="list">
      <div class="item"><div class="ic">📥</div><div class="grow"><b>ข้อมูลบนคลาวด์</b>
        <div class="sub">บันทึกเมื่อ ${theirs ? fmtDate(theirs) : 'ไม่ทราบเวลา'}</div></div></div>
      <div class="item"><div class="ic">📱</div><div class="grow"><b>ข้อมูลในเครื่องนี้</b>
        <div class="sub">${S.pet ? esc(S.pet.name) + ' Lv.' + S.pet.lv : 'ยังไม่ฟักไข่'} · บันทึกเมื่อ ${mine ? fmtDate(mine) : 'ไม่ทราบเวลา'}</div></div></div>
    </div>
    ${warn ? `<div class="gap"></div><div class="expl" style="border-left-color:var(--bad)">
      <b style="color:var(--bad)">ข้อมูลในเครื่องนี้ใหม่กว่าบนคลาวด์</b>
      <div class="tiny" style="margin-top:4px">ถ้ากดดึง ความคืบหน้าที่เล่นไว้ล่าสุดในเครื่องนี้จะหายไป หากไม่แน่ใจให้กดส่งขึ้นคลาวด์แทน</div></div>` : ''}
    <div class="gap"></div>
    <button class="btn ${warn?'danger':'pri'} block" data-act="cloudApply">ดึงมาใช้และเขียนทับเครื่องนี้</button>
    <div class="gap"></div>
    <button class="btn block" data-act="cloud">ยกเลิก</button>`);
  CLOUD_PENDING = inc;
}
let CLOUD_PENDING = null;


/* ===========================================================
   นับจำนวนครั้งที่เปิดเว็บ
   ส่งแค่สัญญาณเปล่า ไม่มีข้อมูลของเด็กติดไปเลย
   =========================================================== */
let VISIT_TOTAL = 0;

function pingVisit(){
  const url = cloudUrl();
  if (!url) return;
  try {
    fetch(url + '?hit=1', { keepalive: true })
      .then(r => r.json())
      .then(out => {
        if (out && out.status === 'success' && out.total > 0){
          VISIT_TOTAL = out.total;
          paintVisit();
        }
      })
      .catch(() => {});
  } catch (e){}
}

/* แสดงตัวเลขท้ายหน้า ถ้าดึงไม่ได้ก็ไม่แสดงอะไรเลย */
function paintVisit(){
  const el = document.getElementById('visit');
  if (!el || !VISIT_TOTAL) return;
  el.innerHTML = `<span class="vnum">${VISIT_TOTAL.toLocaleString('th-TH')}</span> ครั้งที่เปิดเกมนี้`;
  el.classList.add('on');
}
