/* ===========================================================
   ระบบเสียง — สังเคราะห์ด้วยโค้ดทั้งหมด ไม่มีไฟล์เสียง
   ปิดเป็นค่าเริ่มต้น เพราะเด็กหลายคนเล่นพร้อมกันในห้องเรียน
   เริ่มทำงานได้เมื่อผู้ใช้แตะจอครั้งแรกเท่านั้น ตามกฎของเบราว์เซอร์
   =========================================================== */

let AC = null;              // AudioContext ใช้ร่วมกันทั้งเกม
let AUDIO_READY = false;

function soundOn(){ return !!(S && S.settings && S.settings.sound); }

/* เตรียมระบบเสียง เรียกตอนผู้ใช้แตะจอครั้งแรก */
function initAudio(){
  if (AUDIO_READY) return;
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    AC = new Ctx();
    AUDIO_READY = true;
  } catch (e){ AUDIO_READY = false; }
}

/* ปลุก AudioContext ที่ถูกเบราว์เซอร์พักไว้ */
function wakeAudio(){
  if (AC && AC.state === 'suspended') AC.resume().catch(() => {});
}

/* ---------- ตัวสร้างเสียงพื้นฐาน ----------
   freq  ความถี่ (เฮิรตซ์)
   dur   ความยาว (วินาที)
   type  รูปคลื่น sine นุ่มสุด · triangle ใสขึ้น
   vol   ความดัง 0-1
   delay หน่วงก่อนเล่น (วินาที)
   glide ความถี่ปลายทาง ถ้าใส่จะไล่เสียงจากต้นไปปลาย            */
function tone(freq, dur, opt){
  if (!soundOn() || !AUDIO_READY || !AC) return;
  const o = opt || {};
  const t0 = AC.currentTime + (o.delay || 0);
  const vol = (o.vol == null ? .18 : o.vol);

  const osc = AC.createOscillator();
  const gain = AC.createGain();

  osc.type = o.type || 'sine';
  osc.frequency.setValueAtTime(freq, t0);
  if (o.glide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, o.glide), t0 + dur);

  /* ซองเสียงแบบระนาด ขึ้นเร็วแล้วค่อยๆ จาง ไม่มีเสียงคลิกตอนตัด */
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

  osc.connect(gain); gain.connect(AC.destination);
  osc.start(t0); osc.stop(t0 + dur + 0.02);
}

/* เล่นหลายโน้ตต่อกันเป็นทำนองสั้นๆ */
function melody(notes, opt){
  const o = opt || {};
  let t = 0;
  notes.forEach(n => {
    tone(n.f, n.d, Object.assign({}, o, { delay: t, vol: n.v == null ? o.vol : n.v }));
    t += n.gap == null ? n.d * 0.72 : n.gap;
  });
}

/* บันไดเสียงเพนทาโทนิก ให้ความรู้สึกไทยและไม่มีโน้ตที่ฟังแล้วขัดหู */
const PENTA = [523.25, 587.33, 659.25, 783.99, 880.00,
               1046.50, 1174.66, 1318.51, 1567.98, 1760.00];

/* ---------- เสียงประจำเหตุการณ์ ---------- */
const SFX = {
  /* ตอบถูก ไล่สูงขึ้นตามจำนวนที่ถูกติดกัน สูงสุด 10 ขั้น */
  correct(streak){
    const i = Math.min(Math.max(streak - 1, 0), PENTA.length - 1);
    tone(PENTA[i], 0.26, { type:'triangle', vol:.16 });
    tone(PENTA[i] * 2, 0.16, { type:'sine', vol:.05, delay:.02 });
  },

  /* ตอบผิด ทุ้มนุ่ม ไม่ดุ ไม่ทำให้เด็กรู้สึกถูกดุ */
  wrong(){
    tone(196.00, 0.30, { type:'sine', vol:.13, glide:164.81 });
  },

  /* จบรอบ คอร์ดสั้น */
  round(){
    melody([{f:523.25,d:.22},{f:659.25,d:.22},{f:783.99,d:.34}],
           { type:'triangle', vol:.14 });
  },

  /* เลื่อนเลเวล */
  levelUp(){
    melody([{f:659.25,d:.16},{f:783.99,d:.16},{f:1046.50,d:.30}],
           { type:'triangle', vol:.15 });
  },

  /* ฟักไข่ ช่วงพีคของเกม กระดิ่งไล่ระดับ */
  hatch(){
    melody([{f:523.25,d:.24},{f:659.25,d:.24},{f:783.99,d:.24},
            {f:1046.50,d:.30},{f:1318.51,d:.55}],
           { type:'triangle', vol:.17 });
    tone(2093.00, 0.7, { type:'sine', vol:.05, delay:.55 });
  },

  /* วิวัฒนาการ */
  evolve(){
    melody([{f:392.00,d:.20},{f:523.25,d:.20},{f:659.25,d:.20},
            {f:783.99,d:.24},{f:1046.50,d:.60}],
           { type:'triangle', vol:.17 });
  },

  /* ร่ายคาถา กังวานยาว */
  spell(){
    tone(880.00, 0.55, { type:'triangle', vol:.16, glide:1760.00 });
    tone(587.33, 0.65, { type:'sine', vol:.09, delay:.05 });
  },

  /* โจมตีเข้าเต็มแรง */
  crit(){
    tone(1174.66, 0.18, { type:'triangle', vol:.15, glide:1567.98 });
  },

  /* ชนะการดวล */
  win(){
    melody([{f:783.99,d:.18},{f:1046.50,d:.18},{f:1318.51,d:.42}],
           { type:'triangle', vol:.17 });
  },

  /* แพ้การดวล */
  lose(){
    melody([{f:523.25,d:.22},{f:440.00,d:.22},{f:349.23,d:.42}],
           { type:'sine', vol:.13 });
  },

  /* ได้ของหายาก */
  loot(){
    tone(1318.51, 0.14, { type:'triangle', vol:.13 });
    tone(1760.00, 0.20, { type:'sine', vol:.09, delay:.09 });
  },

  /* จับคู่ถูก */
  match(){
    tone(880.00, 0.14, { type:'triangle', vol:.13 });
  },

  /* ภารกิจสำเร็จ */
  mission(){
    melody([{f:659.25,d:.18},{f:880.00,d:.18},{f:1174.66,d:.38}],
           { type:'triangle', vol:.16 });
  },

  /* วิญญาณตื่นจากหลับ */
  wake(){
    melody([{f:392.00,d:.26},{f:523.25,d:.26},{f:659.25,d:.44}],
           { type:'sine', vol:.15 });
  },
};

/* เรียกใช้แบบปลอดภัย ถ้าระบบเสียงมีปัญหาก็เงียบไป ไม่ทำให้เกมพัง */
function sfx(name, arg){
  try {
    if (!soundOn()) return;
    wakeAudio();
    if (SFX[name]) SFX[name](arg);
  } catch (e){}
}
