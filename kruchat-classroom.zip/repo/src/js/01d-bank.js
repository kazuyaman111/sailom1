/* ===========================================================
   ประกอบคลังคำถามทั้งหมด
   เพิ่มชุดใหม่: ประกาศตัวแปร Q_XXX_YY แล้วมาลงทะเบียนใน BANK_SETS
   =========================================================== */
const BANK_SETS = [
  { subj:'hist', grade:'p5', rows: Q_HIST_P5 },
  { subj:'hist', grade:'p6', rows: Q_HIST_P6 },
  { subj:'hist', grade:'m1', rows: Q_HIST_M1 },
  { subj:'hist', grade:'m2', rows: Q_HIST_M2 },
];

const QBANK_BUILTIN = [];
for (const set of BANK_SETS){
  set.rows.forEach((row, i) => {
    const [unit, diff, q, ch, ans, exp] = row;
    QBANK_BUILTIN.push({
      id: `${set.subj}_${set.grade}_${i}`,
      subj: set.subj, grade: set.grade, unit,
      diff, q, ch: ch.slice(), ans, exp: exp || '', built: true
    });
  });
}

/* จำนวนข้อที่มีอยู่จริง แยกตามวิชาและระดับชั้น */
function bankCount(subj, grade){
  return QBANK_BUILTIN.filter(q => q.subj === subj && q.grade === grade).length;
}
