/* ===================== แคนวาส: กระถาง + รอยราน + วิญญาณ ===================== */
const CW = 420, CH = 340;
let canvas, ctx, rafId = null, t0 = performance.now();
let crackle = null, crackleSeed = 0;

function initCanvas(el){
  canvas = el; ctx = el.getContext && el.getContext('2d');
  if (!ctx) return;
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = CW * dpr; canvas.height = CH * dpr;
  canvas.style.aspectRatio = `${CW}/${CH}`;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  if (!crackle) buildCrackle(hashStr(S.uid || 'pot'));
  if (rafId) cancelAnimationFrame(rafId);
  loop();
}

/* ---- สร้างเส้นรอยรานแบบสุ่มคงที่ ---- */
function buildCrackle(seed){
  crackleSeed = seed;
  const r = rngFrom(seed || 12345);
  const lines = [];
  for (let i=0;i<26;i++){
    const x = 90 + r()*240, y = 200 + r()*100;
    const pts = [[x,y]];
    let ang = r()*Math.PI*2;
    const n = 3 + Math.floor(r()*4);
    for (let j=0;j<n;j++){
      ang += (r()-.5)*1.5;
      const len = 8 + r()*22;
      const p = pts[pts.length-1];
      pts.push([p[0] + Math.cos(ang)*len, p[1] + Math.sin(ang)*len*.6]);
    }
    lines.push(pts);
  }
  crackle = lines;
}

/* ---- สถานะที่ใช้วาด ---- */
const View = { progress:0, focusing:false, drift:false, mood:70, bounce:0, duel:null };

function loop(){
  const t = (performance.now() - t0) / 1000;
  draw(t);
  rafId = requestAnimationFrame(loop);
}

function draw(t){
  if (!ctx || !S) return;
  if (!S.pet && !S.egg) return;
  ctx.clearRect(0,0,CW,CH);
  const p = S.pet, sp = p ? SPECIES[p.sp] : null;
  const night = isNight();
  const lit = roomBonus().light > 0;

  /* พื้นหลังวงกลมนุ่ม */
  const g = ctx.createRadialGradient(CW/2, 150, 20, CW/2, 160, 200);
  const warm = (!night || lit);
  g.addColorStop(0, warm ? 'rgba(124,174,155,.20)' : 'rgba(90,130,170,.16)');
  g.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = g; ctx.fillRect(0,0,CW,CH);

  /* วงแหวนโฟกัส */
  drawRing(t);

  /* วิญญาณ หรือไข่ */
  if (View.duel && p){
    drawSpirit(t, p, sp, {cx: CW*0.28, scale: 0.82});
    drawSpirit(t, View.duel.foe, View.duel.foeSp, {cx: CW*0.72, scale: 0.82, flip: true});
  } else {
    if (p) drawSpirit(t, p, sp);
    if (S.egg) drawEgg(t, !p);
  }

  /* กระถาง */
  drawPot(t);
}

/* ---- วงแหวนรอบกระถาง แสดงความคืบหน้าโฟกัส ---- */
function drawRing(t){
  const cx = CW/2, cy = 172, R = 128;
  ctx.save();
  ctx.lineWidth = 2;
  ctx.strokeStyle = 'rgba(190,222,210,.10)';
  ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI*2); ctx.stroke();
  if (View.focusing || View.progress > 0){
    ctx.lineWidth = 3.5;
    ctx.lineCap = 'round';
    ctx.strokeStyle = View.drift ? '#d8b04a' : '#a8d3c2';
    ctx.shadowColor = View.drift ? 'rgba(216,176,74,.6)' : 'rgba(168,211,194,.55)';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(cx, cy, R, -Math.PI/2, -Math.PI/2 + Math.PI*2*clamp(View.progress,0,1));
    ctx.stroke();
    ctx.shadowBlur = 0;
    // จุดหัวเส้น
    const a = -Math.PI/2 + Math.PI*2*clamp(View.progress,0,1);
    ctx.fillStyle = View.drift ? '#e8cf8a' : '#dff0e7';
    ctx.beginPath(); ctx.arc(cx + Math.cos(a)*R, cy + Math.sin(a)*R, 4.5, 0, Math.PI*2); ctx.fill();
  }
  ctx.restore();
}

/* ---- กระถางสังคโลก ---- */
function drawPot(t){
  const cx = CW/2;
  const topY = 214, botY = 316, topR = 84, botR = 58;

  ctx.save();
  // เงา
  ctx.fillStyle = 'rgba(0,0,0,.28)';
  ctx.beginPath(); ctx.ellipse(cx, botY+6, botR+14, 10, 0, 0, Math.PI*2); ctx.fill();

  // ตัวกระถาง
  const body = new Path2D();
  body.moveTo(cx-topR, topY);
  body.bezierCurveTo(cx-topR-6, topY+42, cx-botR-8, botY-34, cx-botR, botY);
  body.lineTo(cx+botR, botY);
  body.bezierCurveTo(cx+botR+8, botY-34, cx+topR+6, topY+42, cx+topR, topY);
  body.closePath();

  const pg = ctx.createLinearGradient(cx-topR, topY, cx+topR, botY);
  pg.addColorStop(0, '#8fbba9');
  pg.addColorStop(.45, '#6d9d8b');
  pg.addColorStop(1, '#3f6455');
  ctx.fillStyle = pg; ctx.fill(body);

  // เคลือบสะท้อนแสง
  ctx.save(); ctx.clip(body);
  const sh = ctx.createLinearGradient(cx-70, topY, cx-10, botY);
  sh.addColorStop(0, 'rgba(255,255,255,.22)');
  sh.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = sh; ctx.fillRect(cx-topR, topY, topR, botY-topY);

  // รอยรานตามความคืบหน้า
  const prog = clamp(View.progress, 0, 1);
  const show = Math.floor(crackle.length * prog);
  ctx.lineWidth = 1;
  for (let i=0;i<crackle.length;i++){
    const full = i < show;
    const partial = (i === show) ? (crackle.length*prog - show) : 0;
    if (!full && partial <= 0) continue;
    const pts = crackle[i];
    const lim = full ? pts.length : Math.max(2, Math.ceil(pts.length * partial));
    ctx.strokeStyle = View.drift ? 'rgba(216,176,74,.5)' : 'rgba(233,247,240,.42)';
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let j=1;j<lim;j++) ctx.lineTo(pts[j][0], pts[j][1]);
    ctx.stroke();
  }
  ctx.restore();

  // ขอบปากกระถาง
  ctx.strokeStyle = 'rgba(220,240,232,.35)'; ctx.lineWidth = 1.5; ctx.stroke(body);
  ctx.fillStyle = '#a9cfbe';
  ctx.beginPath(); ctx.ellipse(cx, topY, topR, 15, 0, 0, Math.PI*2); ctx.fill();
  ctx.fillStyle = '#2c4a3f';
  ctx.beginPath(); ctx.ellipse(cx, topY+3, topR-9, 11, 0, 0, Math.PI*2); ctx.fill();
  // ดิน
  ctx.fillStyle = '#3a3026';
  ctx.beginPath(); ctx.ellipse(cx, topY+4, topR-13, 9, 0, 0, Math.PI*2); ctx.fill();
  ctx.restore();
}

/* ---- ตัววิญญาณ ---- */
function bodyPath(shape, R){
  const P = new Path2D();
  if (shape === 'tall'){
    P.moveTo(0, -R*1.16);
    P.bezierCurveTo(R*0.80, -R*1.05, R*0.86, R*0.62, 0, R*0.98);
    P.bezierCurveTo(-R*0.86, R*0.62, -R*0.80, -R*1.05, 0, -R*1.16);
  } else if (shape === 'tear'){
    P.moveTo(0, -R*1.24);
    P.bezierCurveTo(R*0.62, -R*0.72, R*1.02, R*0.42, 0, R*0.96);
    P.bezierCurveTo(-R*1.02, R*0.42, -R*0.62, -R*0.72, 0, -R*1.24);
  } else if (shape === 'chunky'){
    P.moveTo(0, -R*0.88);
    P.bezierCurveTo(R*1.18, -R*0.86, R*1.24, R*0.58, 0, R*0.88);
    P.bezierCurveTo(-R*1.24, R*0.58, -R*1.18, -R*0.86, 0, -R*0.88);
  } else {
    P.moveTo(0, -R);
    P.bezierCurveTo(R*0.95, -R*0.95, R*1.05, R*0.6, 0, R*0.92);
    P.bezierCurveTo(-R*1.05, R*0.6, -R*0.95, -R*0.95, 0, -R);
  }
  P.closePath();
  return P;
}
const BODY_TOP = { round:1.0, tall:1.16, tear:1.24, chunky:0.88 };
const BODY_SIDE = { round:1.0, tall:0.84, tear:0.86, chunky:1.18 };

function drawTail(kind, R, sp, t){
  if (kind === 'none') return;
  ctx.save();
  ctx.strokeStyle = sp.a(.75); ctx.lineWidth = Math.max(2, R*0.10); ctx.lineCap = 'round';
  const sway = Math.sin(t*1.8)*R*0.16;
  if (kind === 'wisp'){
    ctx.beginPath();
    ctx.moveTo(R*0.5, R*0.5);
    ctx.quadraticCurveTo(R*1.3, R*0.7 + sway, R*1.5, R*0.05 + sway);
    ctx.stroke();
  } else if (kind === 'plume'){
    ctx.fillStyle = sp.a(.55);
    for (let i=0;i<3;i++){
      ctx.beginPath();
      ctx.moveTo(R*0.45, R*0.55);
      ctx.quadraticCurveTo(R*(1.1+i*0.12), R*(0.5-i*0.35) + sway, R*(1.35+i*0.1), R*(0.1-i*0.42) + sway);
      ctx.quadraticCurveTo(R*(0.95+i*0.1), R*(0.35-i*0.2) + sway, R*0.45, R*0.55);
      ctx.fill();
    }
  } else if (kind === 'curl'){
    ctx.beginPath();
    ctx.moveTo(R*0.5, R*0.45);
    ctx.bezierCurveTo(R*1.35, R*0.55 + sway, R*1.45, -R*0.35 + sway, R*0.85, -R*0.15 + sway);
    ctx.stroke();
  }
  ctx.restore();
}

function drawEars(kind, R, sp, t){
  if (kind === 'none') return;
  ctx.save();
  ctx.fillStyle = sp.c2;
  const wob = Math.sin(t*1.5)*0.08;
  for (const d of [-1, 1]){
    ctx.save(); ctx.translate(d*R*0.62, -R*0.62); ctx.rotate(d*(0.35 + wob));
    ctx.beginPath();
    if (kind === 'leaf'){
      ctx.moveTo(0,0); ctx.quadraticCurveTo(d*R*0.42, -R*0.30, d*R*0.12, -R*0.60);
      ctx.quadraticCurveTo(-d*R*0.06, -R*0.28, 0, 0);
    } else if (kind === 'long'){
      ctx.moveTo(0,0); ctx.quadraticCurveTo(d*R*0.24, -R*0.75, d*R*0.06, -R*1.05);
      ctx.quadraticCurveTo(-d*R*0.16, -R*0.62, 0, 0);
    } else { // fin
      ctx.moveTo(0,0); ctx.lineTo(d*R*0.52, -R*0.22); ctx.lineTo(d*R*0.30, -R*0.52);
      ctx.closePath();
    }
    ctx.fill(); ctx.restore();
  }
  ctx.restore();
}

function drawHorn(kind, R, sp, top){
  if (kind === 'none') return;
  ctx.save();
  ctx.fillStyle = sp.accent; ctx.strokeStyle = sp.accent;
  ctx.lineWidth = Math.max(2, R*0.09); ctx.lineCap = 'round';
  const y = -R*top;
  if (kind === 'single'){
    ctx.beginPath(); ctx.moveTo(-R*0.10, y+R*0.10); ctx.lineTo(0, y-R*0.45); ctx.lineTo(R*0.10, y+R*0.10); ctx.fill();
  } else if (kind === 'pair'){
    for (const d of [-1,1]){
      ctx.beginPath();
      ctx.moveTo(d*R*0.24, y+R*0.16); ctx.lineTo(d*R*0.36, y-R*0.34); ctx.lineTo(d*R*0.44, y+R*0.10);
      ctx.fill();
    }
  } else if (kind === 'curved'){
    for (const d of [-1,1]){
      ctx.beginPath();
      ctx.moveTo(d*R*0.28, y+R*0.16);
      ctx.quadraticCurveTo(d*R*0.72, y-R*0.30, d*R*0.34, y-R*0.52);
      ctx.stroke();
    }
  } else if (kind === 'antler'){
    for (const d of [-1,1]){
      ctx.beginPath();
      ctx.moveTo(d*R*0.22, y+R*0.14); ctx.lineTo(d*R*0.40, y-R*0.48);
      ctx.moveTo(d*R*0.32, y-R*0.18); ctx.lineTo(d*R*0.62, y-R*0.30);
      ctx.moveTo(d*R*0.37, y-R*0.34); ctx.lineTo(d*R*0.20, y-R*0.62);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawMarks(kind, R, sp, seed){
  if (kind === 'none') return;
  const r = rngFrom(seed);
  ctx.save();
  if (kind === 'spots'){
    ctx.fillStyle = sp.a(.42);
    for (let i=0;i<6;i++){
      const a = r()*Math.PI*2, d = r()*R*0.8;
      ctx.beginPath(); ctx.arc(Math.cos(a)*d, Math.sin(a)*d*0.9, R*(0.07+r()*0.07), 0, Math.PI*2); ctx.fill();
    }
  } else if (kind === 'stripes'){
    ctx.strokeStyle = sp.a(.38); ctx.lineWidth = R*0.11; ctx.lineCap='round';
    for (let i=0;i<3;i++){
      const y = -R*0.35 + i*R*0.42;
      ctx.beginPath(); ctx.moveTo(-R*1.1, y); ctx.quadraticCurveTo(0, y+R*0.16, R*1.1, y); ctx.stroke();
    }
  } else if (kind === 'veins'){
    ctx.strokeStyle = sp.a(.5); ctx.lineWidth = R*0.05; ctx.lineCap='round';
    for (let i=0;i<5;i++){
      const a = -Math.PI/2 + (i-2)*0.42;
      ctx.beginPath(); ctx.moveTo(0, R*0.55);
      ctx.quadraticCurveTo(Math.cos(a)*R*0.4, R*0.05, Math.cos(a)*R*0.92, Math.sin(a)*R*0.9);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawSpirit(t, p, sp, opt){
  const T = sp.traits;
  const cx = (opt && opt.cx) || CW/2;
  const scale = [0.55, 0.68, 0.82, 1.0, 1.16, 1.3][p.stage] * ((opt && opt.scale) || 1);
  const breathe = Math.sin(t*1.6) * 3;
  const happy = p.mood > 60 && p.hp > 40;
  const hop = happy ? Math.abs(Math.sin(t*2.2)) * 5 : 0;
  const cy = 168 - hop + breathe*0.4 + View.bounce;
  const R = 42 * scale;

  ctx.save();
  ctx.translate(cx, cy);
  if (opt && opt.flip) ctx.scale(-1, 1);

  // แสงเรืองตามความหายาก
  if (sp.rarity >= 3){ ctx.shadowColor = sp.a(.85); ctx.shadowBlur = sp.rarity === 4 ? 26 : 15; }

  // ออร่าร่างโบราณ / วงในตำนาน
  if (p.stage === 5 || T.halo){
    const n = p.stage === 5 ? 7 : 5;
    for (let i=0;i<n;i++){
      const a = t*0.6 + i*Math.PI*2/n;
      const rr = R*1.7 + Math.sin(t*2+i)*6;
      ctx.fillStyle = sp.a(.7);
      ctx.beginPath(); ctx.arc(Math.cos(a)*rr, Math.sin(a)*rr*.5, 3, 0, Math.PI*2); ctx.fill();
    }
  }

  if (p.stage === 0){ drawSeed(R, sp, t); ctx.restore(); return; }

  const top = BODY_TOP[T.body] || 1, side = BODY_SIDE[T.body] || 1;

  // หาง หู เขา อยู่หลังตัว
  drawTail(T.tail, R, sp, t);
  drawEars(T.ear, R, sp, t);
  drawHorn(T.horn, R, sp, top);

  // ปีก / ริ้ว สายระบำ
  if (p.stage >= 3 && p.branch === 'play'){
    ctx.save();
    ctx.strokeStyle = sp.a(.7); ctx.lineWidth = 3; ctx.lineCap = 'round';
    for (const dir of [-1, 1]){
      ctx.beginPath();
      ctx.moveTo(dir*R*0.7, 4);
      ctx.quadraticCurveTo(dir*R*1.8, -14 + Math.sin(t*3)*8, dir*R*2.1, 18 + Math.cos(t*2.4)*8);
      ctx.stroke();
    }
    ctx.restore();
  }
  // เกราะเปลือก สายกายา
  if (p.stage >= 3 && p.branch === 'body'){
    ctx.fillStyle = sp.c2;
    ctx.beginPath(); ctx.ellipse(0, R*0.15, R*side*1.05, R*0.85, 0, Math.PI*0.05, Math.PI*0.95); ctx.fill();
  }
  // วงแหวนฌาน
  if (p.stage >= 3 && p.branch === 'mind'){
    ctx.save();
    ctx.strokeStyle = sp.a(.85); ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.ellipse(0, -R*(top+0.18), R*0.72, R*0.20 + Math.sin(t*1.5)*2, 0, 0, Math.PI*2); ctx.stroke();
    ctx.restore();
  }

  // ตัว
  const P = bodyPath(T.body, R);
  const bg = ctx.createRadialGradient(-R*.3, -R*.35, R*.2, 0, 0, R*1.15);
  bg.addColorStop(0, sp.accent);
  bg.addColorStop(.55, sp.c1);
  bg.addColorStop(1, sp.c2);
  ctx.fillStyle = bg;
  ctx.fill(P);
  ctx.shadowBlur = 0;

  // ลายบนตัว
  ctx.save(); ctx.clip(P);
  drawMarks(T.mark, R, sp, hashStr('mk:' + sp.id));
  ctx.restore();

  // ใบบนหัวสำหรับสายไม้
  if (sp.elk === 'wood'){
    ctx.fillStyle = sp.c2;
    ctx.save(); ctx.translate(0, -R*(top-0.02)); ctx.rotate(Math.sin(t*1.2)*0.12);
    ctx.beginPath();
    ctx.moveTo(0,0);
    ctx.quadraticCurveTo(R*0.42, -R*0.32, R*0.10, -R*0.72);
    ctx.quadraticCurveTo(-R*0.06, -R*0.36, 0, 0);
    ctx.fill();
    ctx.restore();
  }

  // แก้ม
  if (happy){
    ctx.fillStyle = 'rgba(220,120,120,.28)';
    ctx.beginPath(); ctx.ellipse(-R*side*0.48, R*0.16, R*0.15, R*0.10, 0, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.ellipse( R*side*0.48, R*0.16, R*0.15, R*0.10, 0, 0, Math.PI*2); ctx.fill();
  }

  // ตา
  const blink = (Math.sin(t*0.9) > 0.985) ? 0.12 : 1;
  const sleepy = p.hp < 35 || p.mood < 20;
  ctx.fillStyle = '#15242c';
  for (const dx of [-R*0.27*side, R*0.27*side]){
    if (sleepy || View.focusing){
      ctx.strokeStyle = '#15242c'; ctx.lineWidth = 2.6; ctx.lineCap='round';
      ctx.beginPath(); ctx.moveTo(dx - R*0.11, -R*0.06); ctx.quadraticCurveTo(dx, R*0.04, dx + R*0.11, -R*0.06); ctx.stroke();
    } else {
      ctx.beginPath(); ctx.ellipse(dx, -R*0.06, R*0.085, R*0.115*blink, 0, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.85)';
      ctx.beginPath(); ctx.arc(dx + R*0.03, -R*0.11, R*0.03, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#15242c';
    }
  }

  // ปาก
  ctx.strokeStyle = '#15242c'; ctx.lineWidth = 2; ctx.lineCap = 'round';
  ctx.beginPath();
  if (p.mood > 55){ ctx.moveTo(-R*0.12, R*0.24); ctx.quadraticCurveTo(0, R*0.38, R*0.12, R*0.24); }
  else if (p.mood > 25){ ctx.moveTo(-R*0.10, R*0.28); ctx.lineTo(R*0.10, R*0.28); }
  else { ctx.moveTo(-R*0.12, R*0.32); ctx.quadraticCurveTo(0, R*0.18, R*0.12, R*0.32); }
  ctx.stroke();

  if (p.sick){
    ctx.font = '18px serif'; ctx.textAlign='center';
    ctx.fillText('\u{1FA79}', R*0.75, -R*0.75);
  }
  ctx.restore();
}

function drawSeed(R, sp, t){
  ctx.fillStyle = '#6b5540';
  ctx.beginPath(); ctx.ellipse(0, R*0.2, R*0.62, R*0.78, 0, 0, Math.PI*2); ctx.fill();
  ctx.strokeStyle = '#48382a'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(-R*0.2, -R*0.3); ctx.quadraticCurveTo(0, R*0.2, -R*0.1, R*0.7); ctx.stroke();
  ctx.fillStyle = sp.c1;
  ctx.save(); ctx.translate(0, -R*0.5); ctx.rotate(Math.sin(t*1.4)*0.15);
  ctx.beginPath();
  ctx.moveTo(0,0); ctx.quadraticCurveTo(R*0.5, -R*0.25, R*0.14, -R*0.62);
  ctx.quadraticCurveTo(0, -R*0.3, 0, 0); ctx.fill();
  ctx.restore();
}

/* ---- ไข่ ---- */
function eggTint(){
  const odds = hatchOddsByEl();
  let best = null, bv = -1;
  for (const k in odds) if (odds[k] > bv){ bv = odds[k]; best = k; }
  const E = ELEMENTS[best] || ELEMENTS.wood;
  // ยิ่งธาตุนำมาก สียิ่งชัด
  const lean = clamp((bv - 0.125) / 0.5, 0, 1);
  return { h: E.h, s: 10 + 42 * lean, l: 62 - 6 * lean, lean, el: best };
}

function drawEgg(t, big){
  const e = S.egg; if (!e) return;
  const prog = clamp(e.pts / e.need, 0, 1);
  const tint = eggTint();
  const R = big ? 52 : 22;
  const cx = big ? CW/2 : CW/2 + 96;
  const cy = big ? (168 + Math.sin(t*1.4)*3) : 214;

  ctx.save();
  ctx.translate(cx, cy);

  // ตัวไข่
  const g = ctx.createRadialGradient(-R*0.3, -R*0.45, R*0.2, 0, 0, R*1.3);
  g.addColorStop(0, _hsl(tint.h, tint.s, tint.l + 18));
  g.addColorStop(.6, _hsl(tint.h, tint.s, tint.l));
  g.addColorStop(1, _hsl(tint.h + 6, tint.s + 8, tint.l - 20));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(0, -R*1.26);
  ctx.bezierCurveTo(R*0.86, -R*0.92, R*0.98, R*0.55, 0, R*1.02);
  ctx.bezierCurveTo(-R*0.98, R*0.55, -R*0.86, -R*0.92, 0, -R*1.26);
  ctx.closePath();
  ctx.fill();

  // ลายจุดตามธาตุ
  const rr = rngFrom(hashStr('egg' + tint.el));
  ctx.fillStyle = _hsla(tint.h, tint.s + 14, tint.l - 26, .45);
  for (let i=0;i<7;i++){
    const a = rr()*Math.PI*2, d = rr()*R*0.72;
    ctx.beginPath(); ctx.arc(Math.cos(a)*d, Math.sin(a)*d*1.05, R*(0.06+rr()*0.06), 0, Math.PI*2); ctx.fill();
  }

  // รอยร้าวตามความคืบหน้าการฟัก
  if (prog > 0.05){
    const n = Math.floor(prog * 7);
    ctx.strokeStyle = 'rgba(20,32,40,.55)'; ctx.lineWidth = Math.max(1, R*0.045);
    const cr = rngFrom(hashStr('crack' + e.tier));
    for (let i=0;i<n;i++){
      let x = (cr()-.5)*R*1.2, y = (cr()-.5)*R*1.6;
      ctx.beginPath(); ctx.moveTo(x, y);
      for (let j=0;j<3;j++){
        x += (cr()-.5)*R*0.5; y += (cr()-.5)*R*0.5;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }
  // แสงตอนใกล้ฟัก
  if (prog > 0.85){
    ctx.shadowColor = _hsla(tint.h, 70, 70, .9);
    ctx.shadowBlur = 18 + Math.sin(t*4)*8;
    ctx.strokeStyle = _hsla(tint.h, 60, 78, .5); ctx.lineWidth = 2;
    ctx.beginPath(); ctx.ellipse(0, -R*0.1, R*0.9, R*1.12, 0, 0, Math.PI*2); ctx.stroke();
    ctx.shadowBlur = 0;
  }
  ctx.restore();
}

/* ---- ตราสัญลักษณ์การ์ด (พิกเซล 7x7) ---- */
function sigilSVG(seedStr, color, size=44){
  const r = rngFrom(hashStr(seedStr));
  const n = 7, cell = size/n;
  let rects = '';
  for (let y=0;y<n;y++){
    for (let x=0;x<Math.ceil(n/2);x++){
      if (r() > .48){
        const o = 0.5 + r()*0.5;
        rects += `<rect x="${x*cell}" y="${y*cell}" width="${cell}" height="${cell}" fill="${color}" opacity="${o.toFixed(2)}"/>`;
        const mx = n-1-x;
        if (mx !== x) rects += `<rect x="${mx*cell}" y="${y*cell}" width="${cell}" height="${cell}" fill="${color}" opacity="${o.toFixed(2)}"/>`;
      }
    }
  }
  return `<svg class="sigil" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">${rects}</svg>`;
}
