/* ===========================================================
   สอนเล่น — พาเด็กใหม่เข้าประตูทีละขั้น
   ซ่อนแท็บที่ยังไม่ถึงเวลา แล้วเปิดทีละอย่างเมื่อทำขั้นก่อนหน้าสำเร็จ
   ครูปิดระบบนี้ได้จากหน้าตั้งค่า สำหรับเด็กที่เคยเล่นแล้ว
   =========================================================== */

const TUTOR_STEPS = [
  { id:'quiz',  g:'❓', n:'ตอบคำถามรอบแรก',
    d:'กดแท็บตอบคำถาม เลือกวิชาที่ครูสอน แล้วตอบให้ครบหนึ่งรอบ',
    hint:'ตอบผิดไม่เป็นไร ข้อที่ผิดจะวนกลับมาให้ทำใหม่จนกว่าจะเข้าใจ',
    tabs:['pot','quiz'] },

  { id:'hatch', g:'🥚', n:'ฟักไข่ให้เป็นวิญญาณ',
    d:'ตอบคำถามสะสมคะแนนจนไข่พร้อม แล้วกลับมาที่กระถางเพื่อฟัก',
    hint:'หน่วยการเรียนรู้ที่ตอบจะกำหนดธาตุของวิญญาณที่จะได้',
    tabs:['pot','quiz'] },

  { id:'name',  g:'✏️', n:'ตั้งชื่อให้วิญญาณ',
    d:'ตั้งชื่อที่เราชอบ จะเปลี่ยนภายหลังก็ได้',
    hint:'ชื่อนี้เพื่อนจะเห็นตอนดวลกัน อย่าใช้ชื่อจริงของเรานะ',
    tabs:['pot','quiz'] },

  { id:'feed',  g:'🍚', n:'ให้อาหารวิญญาณ',
    d:'เปิดกระเป๋า เลือกอาหาร แล้วกดใช้ วิญญาณที่อิ่มและอารมณ์ดีจะโตเร็วกว่า',
    hint:'ซื้ออาหารด้วยเหรียญที่ได้จากการตอบคำถาม',
    tabs:['pot','quiz','bag'] },

  { id:'duel',  g:'⚔️', n:'ลองดวลกับเพื่อน',
    d:'สร้างรหัสท้าดวลส่งให้เพื่อน หรือขอรหัสเพื่อนมาวางเพื่อดวล',
    hint:'ในการดวลต้องตอบถูกเท่านั้นวิญญาณถึงจะโจมตีได้',
    tabs:['pot','quiz','bag','explore','home','book','sum'] },
];

function tutorOn(){
  return !!(S.tutor && !S.tutor.off && S.tutor.step < TUTOR_STEPS.length);
}
function tutorStep(){
  if (!tutorOn()) return null;
  return TUTOR_STEPS[S.tutor.step] || null;
}
/* แท็บที่เปิดให้ใช้ในขั้นนี้ */
function tutorTabs(){
  const st = tutorStep();
  return st ? st.tabs : null;
}
/* ทำขั้นนี้สำเร็จ */
function tutorDone(id, quiet){
  if (!tutorOn()) return false;
  const st = tutorStep();
  if (!st || st.id !== id) return false;
  S.tutor.step++;
  S.tutor.at = Date.now();
  save();
  const next = tutorStep();
  applyTabLock();
  sfx(next ? 'round' : 'win');
  if (quiet){ render(); return true; }
  sheet(`<div class="eyebrow" style="color:var(--gold)">ทำได้แล้ว</div>
    <h2>${st.g} ${esc(st.n)}</h2>
    <div class="sub">${esc(st.hint)}</div>
    <div class="gap"></div>
    ${next ? `<div class="list"><div class="item">
        <div class="ic">${next.g}</div>
        <div class="grow"><b>ขั้นต่อไป — ${esc(next.n)}</b>
          <div class="sub">${esc(next.d)}</div></div>
      </div></div>
      <div class="gap"></div>
      <div class="tiny">ทำครบ ${TUTOR_STEPS.length} ขั้นแล้วจะเปิดทุกอย่างในเกมให้</div>`
    : `<div class="list"><div class="item"><div class="ic">🎉</div>
        <div class="grow"><b>เปิดครบทุกอย่างแล้ว</b>
          <div class="sub">สำรวจ บ้าน สมุดสะสม และสรุปผล ใช้ได้หมดแล้ว ลองกดดูได้เลย</div></div>
      </div></div>`}
    <div class="gap"></div>
    <button class="btn pri block" data-act="closeSheet">เข้าใจแล้ว</button>`);
  render();
  return true;
}

/* ซ่อนแท็บที่ยังไม่ถึงเวลา */
function applyTabLock(){
  const allow = tutorTabs();
  document.querySelectorAll('#tabs button').forEach(b => {
    const ok = !allow || allow.includes(b.dataset.tab);
    b.classList.toggle('locked', !ok);
    b.disabled = !ok;
  });
}

/* การ์ดบอกขั้นตอนปัจจุบัน แสดงบนสุดของทุกหน้า */
function tutorCard(){
  const st = tutorStep();
  if (!st) return '';
  const n = S.tutor.step + 1;
  const dots = TUTOR_STEPS.map((x, i) =>
    `<span class="tdot ${i < S.tutor.step ? 'done' : (i === S.tutor.step ? 'now' : '')}"></span>`).join('');
  return `<div class="card tutor">
    <div class="row spread">
      <div class="eyebrow" style="color:var(--gold)">สอนเล่น ขั้นที่ ${n} จาก ${TUTOR_STEPS.length}</div>
      <button class="btn sm" data-act="tutorSkip">ข้าม</button>
    </div>
    <div class="row" style="gap:11px;align-items:flex-start;margin-top:2px">
      <div class="ic" style="flex:none">${st.g}</div>
      <div class="grow">
        <b style="font-size:calc(15px * var(--fs))">${esc(st.n)}</b>
        <div class="sub">${esc(st.d)}</div>
      </div>
    </div>
    <div class="tdots">${dots}</div>
  </div>`;
}

/* หน้าต้อนรับครั้งแรกสุด ให้เลือกว่าจะให้สอนหรือไม่ */
function welcomeSheet(){
  sheet(`<div class="eyebrow">ยินดีต้อนรับ</div>
    <h2>ห้องเรียนไร้ขีดจำกัด</h2>
    <div class="sub">ตอบคำถามในวิชาที่เรียน แล้วเอาคะแนนมาฟักไข่ เลี้ยงวิญญาณ และดวลกับเพื่อน</div>
    <div class="gap"></div>

    <div class="eyebrow">เคยเล่นเกมนี้มาก่อนไหม</div>
    <div class="list">
      <div class="item" style="border:1px solid var(--glaze);border-radius:12px;padding:12px;margin-bottom:9px;background:rgba(124,174,155,.08)">
        <div class="ic">🌱</div>
        <div class="grow">
          <b>ยังไม่เคยเล่น พาไปทีละขั้น</b>
          <div class="sub">จะเปิดให้ทีละอย่าง ${TUTOR_STEPS.length} ขั้น ไม่ต้องจำทั้งหมดตอนนี้</div>
          <div class="tiny">${TUTOR_STEPS.map(x => x.g).join('  ')}</div>
        </div>
        <button class="btn pri" data-act="tutorBegin">เลือก</button>
      </div>
      <div class="item" style="border:1px solid var(--line);border-radius:12px;padding:12px;background:rgba(255,255,255,.03)">
        <div class="ic">⚡</div>
        <div class="grow">
          <b>เคยเล่นแล้ว เปิดทุกอย่างเลย</b>
          <div class="sub">ใช้ได้ทั้ง 7 แท็บทันที ไม่ต้องมีคำแนะนำ</div>
        </div>
        <button class="btn" data-act="tutorSkipYes">เลือก</button>
      </div>
    </div>
    <div class="gap"></div>
    <div class="tiny">เปลี่ยนใจภายหลังได้ที่ ตั้งค่าและเซฟ ${'\u2192'} สอนเล่น</div>`);
}

/* หน้ายืนยันตอนกดข้าม */
function tutorSkipSheet(){
  sheet(`<h2>ข้ามการสอนเล่น</h2>
    <div class="sub">ทุกแท็บจะเปิดให้ใช้ทันที เหมาะกับเด็กที่เคยเล่นมาแล้ว</div>
    <div class="gap"></div>
    <button class="btn block" data-act="tutorSkipYes">ข้ามและเปิดทุกอย่าง</button>
    <div class="gap"></div>
    <button class="btn pri block" data-act="closeSheet">เรียนต่อทีละขั้น</button>`);
}
