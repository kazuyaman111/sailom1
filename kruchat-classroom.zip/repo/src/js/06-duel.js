/* ===========================================================
   ดวลปริศนา — ระบบท้าดวลด้วยรหัส (ไม่ต้องใช้เซิร์ฟเวอร์)
   ผู้เล่นสร้างรหัสจากวิญญาณของตน ส่งให้เพื่อน เพื่อนวางรหัสแล้วดวลกับ "เงา" ของตัวนั้น
   ตอบถูกเท่านั้นจึงจะโจมตีได้ ความแรงมาจากค่าสถานะและความเร็วในการตอบ
   =========================================================== */

const DUEL_VER = 1;
const DUEL_ROUNDS = 12;          // จำนวนข้อสูงสุดต่อการดวลหนึ่งครั้ง
const DUEL_WIN_CAP = 5;          // จำนวนครั้งต่อวันที่ยังได้รางวัลเต็ม
const DIFF_POWER = [0, 1.0, 1.25, 1.6, 2.1];   // ตัวคูณความแรงตามความยากของข้อ

/* ---------- เข้ารหัส / ถอดรหัส ---------- */
function b64e(str){
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function b64d(s){
  s = s.replace(/-/g,'+').replace(/_/g,'/');
  while (s.length % 4) s += '=';
  const bin = atob(s);
  const arr = new Uint8Array(bin.length);
  for (let i=0;i<bin.length;i++) arr[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(arr);
}
function shortSum(str){
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let h = hashStr(str), out = '';
  for (let i=0;i<4;i++){ out += c[h % c.length]; h = Math.floor(h / c.length) + 7919; }
  return out;
}

/* สร้างรหัสท้าดวลจากวิญญาณที่กำลังเลี้ยงอยู่ */
function makeDuelCode(){
  const p = S.pet;
  if (!p) return null;
  const acc = S.stats.answered ? Math.round(S.stats.correct / S.stats.answered * 100) : 60;
  const payload = JSON.stringify([
    DUEL_VER, p.sp, p.stage, p.branch || '', p.lv,
    p.stats.STR, p.stats.VIT, p.stats.AGI, p.stats.INT, p.stats.LUK,   // รหัสส่งค่าเต็มเสมอ ไม่ส่งค่าตอนหลับ
    clamp(acc, 30, 98), String(p.name).slice(0, 12), S.uid
  ]);
  const body = b64e(payload);
  return 'KJ' + DUEL_VER + '-' + body + '-' + shortSum(body);
}

/* ถอดรหัสท้าดวล คืนค่า {ok, foe} หรือ {ok:false, err} */
function readDuelCode(raw){
  const code = String(raw || '').trim().replace(/\s+/g, '');
  const m = code.match(/^KJ(\d+)-([A-Za-z0-9\-_]+)-([A-Z2-9]{4})$/);
  if (!m) return {ok:false, err:'รูปแบบรหัสไม่ถูกต้อง ลองคัดลอกใหม่ทั้งบรรทัด'};
  if (+m[1] !== DUEL_VER) return {ok:false, err:'รหัสนี้มาจากเกมคนละรุ่น ให้เพื่อนอัปเดตเกมก่อน'};
  if (shortSum(m[2]) !== m[3]) return {ok:false, err:'รหัสไม่สมบูรณ์หรือถูกแก้ไข ลองขอรหัสใหม่'};
  let a;
  try { a = JSON.parse(b64d(m[2])); } catch(e){ return {ok:false, err:'อ่านรหัสไม่ได้'}; }
  if (!Array.isArray(a) || a.length < 13) return {ok:false, err:'ข้อมูลในรหัสไม่ครบ'};
  const sp = a[1];
  if (!SPECIES[sp]) return {ok:false, err:'ไม่รู้จักสายพันธุ์ในรหัสนี้'};
  const stage = clamp(+a[2] || 0, 0, 5);
  const foe = {
    sp, stage,
    branch: a[3] || null,
    lv: clamp(+a[4] || 1, 1, 99),
    stats: {
      STR: clamp(+a[5]||5, 1, 999), VIT: clamp(+a[6]||5, 1, 999),
      AGI: clamp(+a[7]||5, 1, 999), INT: clamp(+a[8]||5, 1, 999),
      LUK: clamp(+a[9]||5, 1, 999)
    },
    acc: clamp(+a[10] || 60, 30, 98),
    name: String(a[11] || 'คู่ต่อสู้').slice(0, 12),
    uid: String(a[12] || '????'),
    mood: 80, hp: 100, sick: false, care:{body:0,mind:0,play:0}
  };
  if (foe.uid === S.uid) return {ok:false, err:'นี่คือรหัสของตัวเอง ต้องใช้รหัสของเพื่อน'};
  return {ok:true, foe};
}

/* ---------- สูตรการต่อสู้ ---------- */
/* ค่าสถานะที่ใช้จริงในการดวล รวมโบนัสจากอาวุธของฝ่ายเรา */
function dStat(p, key, mine){ return liveStat(p, key) + (mine ? gearStatBonus(key) : 0); }

/* ธาตุของวิญญาณ */
function petEl(p){ const sp = SPECIES[p.sp]; return sp ? sp.elk : null; }

/* ---------- เลือด ---------- */
function duelMaxHp(p, mine){
  const base = 130 + dStat(p,'VIT',mine) * 2.0 + p.lv * 2.6;
  return Math.round(base + (mine ? gearHpBonus() : 0));
}

/* ---------- โจมตีปกติ: STR เป็นหลัก ---------- */
function duelAtk(p, mine){
  /* ทุกค่าสถานะมีส่วนในการโจมตีปกติ เพื่อไม่ให้สายโชคกับสายไวไร้ฐานพลัง */
  const base = 6 + dStat(p,'STR',mine) * 0.55
                 + dStat(p,'AGI',mine) * 0.22
                 + dStat(p,'LUK',mine) * 0.18
                 + dStat(p,'INT',mine) * 0.10;
  return mine ? base * (1 + roomBonus().duelAtk + gearAtkBonus()) : base;
}

/* ---------- คาถา: INT เป็นหลัก ---------- */
function duelMagic(p, mine){
  return 24 + dStat(p,'INT',mine) * 2.2 + dStat(p,'LUK',mine) * 0.4;
}

/* ---------- เกราะ: ลดเป็นเปอร์เซ็นต์ ไม่ลบตรงๆ ----------
   ไม่ผูกกับ VIT เพราะ VIT ให้เลือดอยู่แล้ว ถ้าให้ทั้งสองอย่างสายถังจะแข็งเกินไป */
function duelDefRaw(p, mine){
  const v = p.lv * 1.0 + 10;
  return mine ? v * (1 + roomBonus().duelDef + gearDefBonus()) : v;
}
function defCut(defRaw, pierce){
  const eff = defRaw * (1 - (pierce || 0));
  return 100 / (100 + eff);          // 0-1 ยิ่งน้อยยิ่งลดความเสียหายได้มาก
}

/* ---------- AGI: โอกาสตีซ้ำ (แทนการหลบ) ---------- */
function duelExtra(p, mine){ 
  return clamp(dStat(p,'AGI',mine) / 130 + (mine ? gearExtraBonus() : 0), 0, 0.40);
}
/* ---------- LUK: โอกาสเข้าเต็มแรง ---------- */
function duelCrit(p, mine){
  return clamp(dStat(p,'LUK',mine) / 150 + (mine ? gearCritBonus() : 0), 0, 0.45);
}
/* ---------- AGI ทำให้เกจคาถาเต็มเร็วขึ้น ---------- */
function gaugeRate(p, mine){ return 1 + clamp(dStat(p,'AGI',mine) / 260, 0, 0.45); }

/* ---------- คำนวณความเสียหาย ---------- */
function duelDamage(o){
  const { atk, def, mineAtk, diff, speed, spell, shield } = o;
  const aEl = petEl(atk), dEl = petEl(def);
  const em = elMul(aEl, dEl);

  let base, kind;
  if (spell){
    base = duelMagic(atk, mineAtk) * spell.pw;
    kind = 'spell';
  } else {
    base = duelAtk(atk, mineAtk) * DIFF_POWER[diff] * (1 + 0.5 * clamp(speed, 0, 1));
    kind = 'hit';
  }

  const pierce = (spell && spell.eff === 'pierce') ? spell.v : 0;
  base *= defCut(duelDefRaw(def, !mineAtk), pierce);
  base *= em;

  /* VIT ช่วยลดความเสียหายจากคาถาโดยเฉพาะ */
  if (spell) base *= 1 - clamp(dStat(def,'VIT',!mineAtk) / 900, 0, 0.22);

  /* ยกที่ 6 เป็นต้นไป ความเสียหายทวีขึ้นเรื่อยๆ เพื่อให้การดวลจบในสนามเสมอ */
  if (DUEL.round >= 7) base *= 1 + 0.18 * (DUEL.round - 6);

  const crit = !spell && Math.random() < duelCrit(atk, mineAtk);
  if (crit) base *= 1.8;
  if (shield) base *= 1 - shield;

  return {
    dmg: Math.max(1, Math.round(base)),
    crit, kind, em,
    spell: spell || null,
    shielded: !!shield
  };
}

/* เงาของคู่ต่อสู้ตอบถูกหรือไม่ อิงจากความแม่นยำจริงของเจ้าของรหัส */
function foeAnswers(foe, diff){
  const mod = [0, 1.06, 1.0, 0.88, 0.76][diff];
  return Math.random() < clamp(foe.acc / 100 * mod, 0.1, 0.97);
}
function foeSpeed(foe){
  return clamp(foe.stats.AGI / (foe.stats.AGI + 45), 0, 1) * (0.6 + Math.random() * 0.4);
}

/* ---------- สถานะการดวล ---------- */
const DUEL = {
  running:false, foe:null, subj:'mix', grade:null,
  hp:0, foeHp:0, maxHp:0, foeMax:0,
  gauge:0, foeGauge:0,          // เกจคาถา 0-100
  burn:null, foeBurn:null,      // {dmg, left}
  shield:0, foeShield:0,        // ลดความเสียหายในยกถัดไป
  spellCast:null,               // คาถาที่เพิ่งร่ายในยกนี้ (ไว้แสดงผล)
  round:0, used:[], cur:null, locked:false, chosen:-1, units:{}, eggPts:0,
  limitMs:0, startAt:0, tickId:null, log:[], result:null
};

function duelStart(foe, subj, grade){
  const p = S.pet;
  DUEL.running = true; DUEL.foe = foe;
  DUEL.subj = subj; DUEL.grade = grade;
  DUEL.maxHp = duelMaxHp(p, true);
  /* เจ้าของรหัสเลือกวิญญาณไม่ได้ จึงได้เลือดชดเชย 8% ชดเชยการที่อีกฝ่ายได้ตีก่อน */
  DUEL.foeMax = Math.round(duelMaxHp(foe, false) * 1.08);
  DUEL.hp = DUEL.maxHp; DUEL.foeHp = DUEL.foeMax;
  DUEL.round = 0; DUEL.used = []; DUEL.log = []; DUEL.result = null;
  DUEL.units = {}; DUEL.eggPts = 0;
  /* รางวัลจากภารกิจ เริ่มดวลด้วยเกจเต็ม ใช้ได้ครั้งเดียว */
  DUEL.gauge = S.mqGauge ? GAUGE_MAX : 0;
  if (S.mqGauge){ S.mqGauge = false; save(); }
  DUEL.foeGauge = 0;
  DUEL.burn = null; DUEL.foeBurn = null;
  DUEL.shield = 0; DUEL.foeShield = 0;
  View.duel = { foe, foeSp: SPECIES[foe.sp] };
  duelNext();
}

function duelNext(){
  const q = pickQuestion(DUEL.subj, DUEL.grade, DUEL.used);
  if (!q || DUEL.round >= DUEL_ROUNDS) return duelFinish();
  DUEL.used.push(q.id);
  let cur = q;
  if (S.settings.shuffle){
    const order = q.ch.map((c,i)=>i).sort(() => Math.random() - .5);
    cur = Object.assign({}, q, { ch: order.map(i => q.ch[i]), ans: order.indexOf(q.ans) });
  }
  DUEL.cur = cur;
  DUEL.locked = false; DUEL.chosen = -1;
  DUEL.limitMs = S.settings.timed ? DIFF[cur.diff].sec * 1000 : 0;
  DUEL.startAt = Date.now();
  View.focusing = true; View.progress = 0; View.drift = false;
  clearInterval(DUEL.tickId);
  if (DUEL.limitMs) DUEL.tickId = setInterval(duelTick, 120);
  render();
}

function duelTick(){
  if (!DUEL.running || DUEL.locked || !DUEL.limitMs) return;
  const left = DUEL.limitMs - (Date.now() - DUEL.startAt);
  View.progress = clamp(1 - left / DUEL.limitMs, 0, 1);
  View.drift = left < DUEL.limitMs * 0.25;
  const c = document.getElementById('qclock');
  if (c){
    c.textContent = Math.max(0, Math.ceil(left/1000)) + ' วิ';
    c.classList.toggle('low', left < DUEL.limitMs * 0.25);
  }
  if (left <= 0) duelAnswer(-1);
}

/* สุ่มคาถาของธาตุนั้น โชคสูงมีโอกาสได้บทที่แรงกว่า */
function pickSpell(p, mine){
  const el = petEl(p);
  const list = SPELLS[el] || SPELLS.wood;
  const luck = clamp(dStat(p, 'LUK', mine) / 220, 0, 0.45);
  const w = list.map(sp => Math.pow(sp.pw, 1 + luck * 4));
  const tot = w.reduce((a, b) => a + b, 0);
  let r = Math.random() * tot;
  for (let i = 0; i < list.length; i++){ r -= w[i]; if (r <= 0) return list[i]; }
  return list[0];
}

/* ใส่ผลข้างเคียงของคาถา คืนข้อความสรุป */
function applySpellEffect(sp, dmg, mine){
  const out = [];
  if (!sp || !sp.eff) return out;
  if (sp.eff === 'heal'){
    const h = Math.max(1, Math.round(dmg * sp.v));
    if (mine){ DUEL.hp = Math.min(DUEL.maxHp, DUEL.hp + h); }
    else { DUEL.foeHp = Math.min(DUEL.foeMax, DUEL.foeHp + h); }
    out.push(`ดูดพลังคืน ${h}`);
  } else if (sp.eff === 'burn'){
    const b = { dmg: Math.max(1, Math.round(dmg * sp.v)), left: 3 };
    if (mine) DUEL.foeBurn = b; else DUEL.burn = b;
    out.push(`ติดไฟไหม้ ${b.dmg} ต่อยก อีก 3 ยก`);
  } else if (sp.eff === 'shield'){
    if (mine) DUEL.shield = sp.v; else DUEL.foeShield = sp.v;
    out.push(`ตั้งเกราะกัน ${Math.round(sp.v * 100)}% ในยกถัดไป`);
  } else if (sp.eff === 'drain'){
    if (mine) DUEL.foeGauge = Math.max(0, DUEL.foeGauge - sp.v);
    else DUEL.gauge = Math.max(0, DUEL.gauge - sp.v);
    out.push(`ลดเกจคาถาอีกฝ่าย ${sp.v}`);
  } else if (sp.eff === 'pierce'){
    out.push(`เจาะเกราะ ${Math.round(sp.v * 100)}%`);
  }
  return out;
}

/* ความเสียหายจากไฟไหม้ตอนต้นยก */
function tickBurn(){
  const msg = [];
  if (DUEL.foeBurn){
    DUEL.foeHp = Math.max(0, DUEL.foeHp - DUEL.foeBurn.dmg);
    msg.push({ side:'foe', dmg: DUEL.foeBurn.dmg });
    if (--DUEL.foeBurn.left <= 0) DUEL.foeBurn = null;
  }
  if (DUEL.burn){
    DUEL.hp = Math.max(0, DUEL.hp - DUEL.burn.dmg);
    msg.push({ side:'me', dmg: DUEL.burn.dmg });
    if (--DUEL.burn.left <= 0) DUEL.burn = null;
  }
  return msg;
}

function duelAnswer(i){
  if (DUEL.locked) return;
  clearInterval(DUEL.tickId);
  const q = DUEL.cur, p = S.pet, foe = DUEL.foe;
  const correct = i === q.ans;
  const left = DUEL.limitMs ? Math.max(0, DUEL.limitMs - (Date.now() - DUEL.startAt)) : 0;
  const speed = DUEL.limitMs ? left / DUEL.limitMs : 0.5;

  DUEL.chosen = i; DUEL.locked = true; DUEL.round++;
  const turn = { correct, my:[], foe:[], burn:[], note:[] };

  /* เกราะที่ตั้งไว้ยกก่อนใช้ได้ในยกนี้ แล้วสลาย */
  const myShield = DUEL.shield, foeShield = DUEL.foeShield;
  DUEL.shield = 0; DUEL.foeShield = 0;

  if (correct){
    /* เติมเกจตามความยากและ AGI */
    DUEL.gauge = Math.min(GAUGE_MAX, DUEL.gauge + GAUGE_BY_DIFF[q.diff] * gaugeRate(p, true));

    if (DUEL.gauge >= GAUGE_MAX){
      /* ร่ายคาถา */
      const sp = pickSpell(p, true);
      DUEL.gauge = 0;
      const r = duelDamage({ atk:p, def:foe, mineAtk:true, spell:sp, shield:foeShield });
      DUEL.foeHp = Math.max(0, DUEL.foeHp - r.dmg);
      r.effects = applySpellEffect(sp, r.dmg, true);
      turn.my.push(r);
    } else {
      const r = duelDamage({ atk:p, def:foe, mineAtk:true, diff:q.diff, speed, shield:foeShield });
      DUEL.foeHp = Math.max(0, DUEL.foeHp - r.dmg);
      turn.my.push(r);
      /* AGI: โอกาสฟันซ้ำ */
      if (DUEL.foeHp > 0 && Math.random() < duelExtra(p, true)){
        const r2 = duelDamage({ atk:p, def:foe, mineAtk:true, diff:q.diff, speed:speed*0.6, shield:0 });
        r2.repeat = true;
        DUEL.foeHp = Math.max(0, DUEL.foeHp - r2.dmg);
        turn.my.push(r2);
      }
    }
    recordAnswer(q, true);
    S.stats.answered++; S.stats.correct++;
    wakeProgress(1);
    DUEL.eggPts += DIFF[q.diff].pt;
    DUEL.units[q.unit] = (DUEL.units[q.unit] || 0) + DIFF[q.diff].pt;
  } else {
    recordAnswer(q, false);
    S.stats.answered++;
  }

  /* ตาของเงาคู่ต่อสู้ */
  if (DUEL.foeHp > 0){
    if (foeAnswers(foe, q.diff)){
      DUEL.foeGauge = Math.min(GAUGE_MAX, DUEL.foeGauge + GAUGE_BY_DIFF[q.diff] * gaugeRate(foe, false));
      if (DUEL.foeGauge >= GAUGE_MAX){
        const sp = pickSpell(foe, false);
        DUEL.foeGauge = 0;
        const r = duelDamage({ atk:foe, def:p, mineAtk:false, spell:sp, shield:myShield });
        DUEL.hp = Math.max(0, DUEL.hp - r.dmg);
        r.effects = applySpellEffect(sp, r.dmg, false);
        turn.foe.push(r);
      } else {
        const r = duelDamage({ atk:foe, def:p, mineAtk:false, diff:q.diff, speed:foeSpeed(foe), shield:myShield });
        DUEL.hp = Math.max(0, DUEL.hp - r.dmg);
        turn.foe.push(r);
        if (DUEL.hp > 0 && Math.random() < duelExtra(foe, false)){
          const r2 = duelDamage({ atk:foe, def:p, mineAtk:false, diff:q.diff, speed:foeSpeed(foe)*0.6, shield:0 });
          r2.repeat = true;
          DUEL.hp = Math.max(0, DUEL.hp - r2.dmg);
          turn.foe.push(r2);
        }
      }
    }
  }

  /* ไฟไหม้ทำงานท้ายยก */
  if (DUEL.hp > 0 && DUEL.foeHp > 0) turn.burn = tickBurn();

  DUEL.log.push(turn);
  View.drift = false;
  save(); render();
  if (DUEL.foeHp <= 0 || DUEL.hp <= 0) setTimeout(duelFinish, 500);
}

function duelAdvance(){
  if (!DUEL.locked) return;
  if (DUEL.foeHp <= 0 || DUEL.hp <= 0 || DUEL.round >= DUEL_ROUNDS) return duelFinish();
  duelNext();
}

function duelFinish(){
  clearInterval(DUEL.tickId);
  if (!DUEL.running) return;
  DUEL.running = false;
  View.focusing = false; View.drift = false; View.progress = 0; View.duel = null;

  const myPct = DUEL.hp / DUEL.maxHp, foePct = DUEL.foeHp / DUEL.foeMax;
  const win = DUEL.foeHp <= 0 ? true : (DUEL.hp <= 0 ? false : myPct > foePct);
  const draw = DUEL.hp > 0 && DUEL.foeHp > 0 && Math.abs(myPct - foePct) < 0.02;

  S.duel = S.duel || { win:0, lose:0, draw:0, day:'', today:0 };
  const t = todayKey();
  if (S.duel.day !== t){ S.duel.day = t; S.duel.today = 0; }
  const full = S.duel.today < DUEL_WIN_CAP;
  S.duel.today++;

  const hit = DUEL.log.filter(x => x.correct).length;
  let coin = 0, crys = 0, xp = 0;
  if (draw){ S.duel.draw++; coin = 40; }
  else if (win){ S.duel.win++; coin = 80 + S.pet.lv * 3; crys = full ? 2 : 0; }
  else { S.duel.lose++; coin = 25; }
  if (!full) coin = Math.round(coin * 0.3);
  xp = Math.round(hit * 12 * (win ? 1.3 : 1));

  S.coins += coin; S.crystals += crys;
  const lv = gainXp(xp).levels;
  S.pet.mood = clamp(S.pet.mood + (win ? 8 : 3), 0, 100);
  if (S.egg && DUEL.eggPts > 0) eggAddPoints(DUEL.eggPts, DUEL.units);
  DUEL.result = { win, draw, coin, crys, xp, lv, hit, full };
  save();
  if (typeof tutorDone === 'function' && tutorStep() && tutorStep().id === 'duel'){
    S.tutor.step++; S.tutor.at = Date.now(); save(); applyTabLock();
  }
  render();
  sheet(duelResultSheet());
  cloudAutoSync();
}

/* ===================== หน้าจอดวล ===================== */
function duelSheet(){
  if (!S.pet) return toast('ต้องมีวิญญาณก่อนจึงจะดวลได้', 'bad');
  const d = S.duel || {win:0, lose:0, draw:0};
  sheet(`<div class="eyebrow">ดวลปริศนา</div>
    <h2>ท้าดวลกับเพื่อน</h2>
    <div class="sub">ตอบถูกเท่านั้นวิญญาณจึงจะโจมตีได้ ตอบเร็วยิ่งแรง ค่าสถานะเป็นตัวกำหนดพลังพื้นฐาน</div>
    <div class="gap"></div>
    <div class="bigstat">
      <div><b style="color:var(--ok)">${d.win||0}</b><span>ชนะ</span></div>
      <div><b>${d.draw||0}</b><span>เสมอ</span></div>
      <div><b style="color:var(--bad)">${d.lose||0}</b><span>แพ้</span></div>
    </div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="duelMine">สร้างรหัสของฉันให้เพื่อน</button>
    <div class="gap"></div>
    <button class="btn gold block" data-act="duelPaste">วางรหัสเพื่อนเพื่อเริ่มดวล</button>
    <div class="gap"></div>
    <div class="tiny">รหัสเป็นภาพนิ่งของวิญญาณ ณ ตอนที่สร้าง ถ้าเลี้ยงจนแข็งแรงขึ้นให้สร้างรหัสใหม่ส่งให้เพื่อนอีกครั้ง</div>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

function duelMineSheet(){
  const code = makeDuelCode();
  if (!code) return toast('ยังไม่มีวิญญาณ', 'bad');
  const p = S.pet, sp = SPECIES[p.sp];
  sheet(`<div class="eyebrow">รหัสท้าดวลของฉัน</div>
    <h2>${esc(p.name)}</h2>
    <div class="sub">${formName(p.sp,p.stage,p.branch)} · Lv.${p.lv} · พลังรวม ${petPower(p)}</div>
    <div class="gap"></div>
    <div class="list">
      <div class="item"><div class="ic" style="background:${sp.dim};border-color:${sp.a(.4)}">${sp.g}</div>
        <div class="grow"><b>เลือดสูงสุด ${duelMaxHp(p, true)}</b>
          <div class="tiny">โจมตี ${Math.round(duelAtk(p,true))} · คาถา ${Math.round(duelMagic(p,true))} · เกราะ ${Math.round(duelDefRaw(p,true))} · ตีซ้ำ ${Math.round(duelExtra(p,true)*100)}% · เต็มแรง ${Math.round(duelCrit(p,true)*100)}%</div>
          <div class="tiny">ธาตุ${ELEMENTS[petEl(p)].n} ${ELEMENTS[petEl(p)].g} · ข่ม${ELEMENTS[EL_BEATS[petEl(p)][0]].n} · แพ้ทาง${ELEMENTS[Object.keys(EL_BEATS).find(k=>EL_BEATS[k].includes(petEl(p)))].n}</div></div></div>
    </div>
    <div class="gap"></div>
    <textarea id="duelOut" class="fld" readonly style="min-height:96px;font-family:'IBM Plex Mono',monospace;font-size:calc(12px * var(--fs));word-break:break-all">${code}</textarea>
    <button class="btn pri block" data-act="duelCopy">คัดลอกรหัส</button>
    <div class="gap"></div>
    <div class="tiny">ส่งรหัสนี้ให้เพื่อนทางไลน์หรือเขียนใส่กระดาษก็ได้ เพื่อนจะได้ดวลกับเงาของวิญญาณตัวนี้</div>
    <div class="gap"></div>
    <button class="btn block" data-act="duel">ย้อนกลับ</button>`);
}

function duelPasteSheet(){
  const grade = QUIZ.grade || S.grade;
  const total = questionsBy('mix', grade).length;
  sheet(`<div class="eyebrow">รับคำท้า</div><h2>วางรหัสของเพื่อน</h2>
    <div class="sub">คำถามที่ใช้ดวลจะมาจากระดับชั้นและวิชาที่เลือกด้านล่าง</div>
    <div class="gap"></div>
    <textarea id="duelIn" class="fld" style="min-height:88px;font-size:calc(13px * var(--fs))" placeholder="วางรหัสที่ขึ้นต้นด้วย KJ1- ตรงนี้"></textarea>
    <div class="eyebrow">ระดับชั้น</div>
    <div class="chips">${GRADE_KEYS.map(g => {
      const n = questionsBy('mix', g).length;
      return `<button class="chip ${g===grade?'on':''}" data-dgrade="${g}" ${n?'':'disabled'}>${GRADES[g].n}</button>`;
    }).join('')}</div>
    <div class="gap"></div>
    <div class="eyebrow">วิชา</div>
    <div class="chips">
      <button class="chip ${DUEL.subj==='mix'?'on':''}" data-dsubj="mix">🎲 ผสม <span class="mono" style="font-size:11px;opacity:.7">${total}</span></button>
      ${SUBJ_KEYS.map(k => {
        const n = questionsBy(k, grade).length;
        return `<button class="chip ${DUEL.subj===k?'on':''}" data-dsubj="${k}" ${n?'':'disabled'}>${SUBJECTS[k].g} ${SUBJECTS[k].short} <span class="mono" style="font-size:11px;opacity:.7">${n}</span></button>`;
      }).join('')}
    </div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="duelGo">ตรวจรหัสและเลือกวิญญาณ</button>
    <div class="gap"></div>
    <button class="btn block" data-act="duel">ย้อนกลับ</button>`);
}

function hpBar(cur, max, cls){
  const pct = clamp(cur / max * 100, 0, 100);
  const col = pct > 50 ? '#7cae9b' : (pct > 20 ? '#d8b04a' : '#c26a6a');
  return `<div class="bar" style="height:9px"><i style="width:${pct}%;background:${col}"></i></div>`;
}

function gaugeBar(cur, max){
  const pct = clamp(cur / max * 100, 0, 100);
  const full = pct >= 100;
  return `<div class="bar gauge ${full?'full':''}" style="height:6px;margin-top:3px">
    <i style="width:${pct}%;background:${full?'var(--gold)':'#7fa8c9'}"></i></div>`;
}

function elBadge(a, b){
  const l = elLabel(a, b);
  if (!l) return '';
  return `<span class="pill" style="color:${l.c};border-color:${l.c}55">${l.t}</span>`;
}

function viewDuel(){
  if (!DUEL.running) return viewPot();
  const p = S.pet, foe = DUEL.foe;
  const fsp = SPECIES[foe.sp], msp = SPECIES[p.sp];
  const myEl = petEl(p), foeEl = petEl(foe);
  const q = DUEL.cur, d = DIFF[q.diff];
  const ready = DUEL.gauge >= GAUGE_MAX;

  const choices = q.ch.map((c, i) => {
    let cls = '';
    if (DUEL.locked){
      if (i === q.ans) cls = 'right';
      else if (i === DUEL.chosen) cls = 'wrong';
    }
    return `<button class="ch ${cls}" data-dans="${i}" ${DUEL.locked?'disabled':''}>
      <span class="k">${'กขคง'[i]}</span><span>${esc(c)}</span></button>`;
  }).join('');

  const hitLine = (r, who) => {
    if (r.spell){
      return `<div><b style="color:var(--gold)">${r.spell.g} ${esc(r.spell.n)}</b>
        <span class="mono"> ${r.dmg}</span>
        ${r.em>1?'<span class="tiny" style="color:var(--ok)"> ธาตุข่ม</span>':(r.em<1?'<span class="tiny" style="color:var(--bad)"> ถูกข่ม</span>':'')}
        ${r.shielded?'<span class="tiny"> ถูกเกราะกันไว้</span>':''}
        ${(r.effects&&r.effects.length)?`<div class="tiny">${r.effects.join(' · ')}</div>`:''}</div>`;
    }
    return `<div>${r.repeat?'<span class="tiny">ฟันซ้ำ </span>':''}${who} <span class="mono">${r.dmg}</span>
      ${r.crit?'<span class="tiny" style="color:var(--gold)"> เข้าเต็มแรง</span>':''}
      ${r.em>1?'<span class="tiny" style="color:var(--ok)"> ธาตุข่ม</span>':(r.em<1?'<span class="tiny" style="color:var(--bad)"> ถูกข่ม</span>':'')}
      ${r.shielded?'<span class="tiny"> ถูกเกราะกันไว้</span>':''}</div>`;
  };

  let after = '';
  if (DUEL.locked){
    const t = DUEL.log[DUEL.log.length - 1] || {};
    const lines = [];
    if (t.correct && t.my && t.my.length)
      t.my.forEach(r => lines.push(`<span style="color:var(--ok)">${hitLine(r, esc(p.name) + ' โจมตี')}</span>`));
    else lines.push(`<b style="color:var(--warn)">ตอบผิด ${esc(p.name)} โจมตีไม่เข้า</b>`);

    if (t.foe && t.foe.length)
      t.foe.forEach(r => lines.push(`<span style="color:var(--bad)">${hitLine(r, esc(foe.name) + ' สวนกลับ')}</span>`));
    else lines.push(`<span class="tiny">${esc(foe.name)} ตอบข้อนี้ไม่ได้ จึงโจมตีไม่เข้า</span>`);

    (t.burn || []).forEach(b => lines.push(
      `<span class="tiny" style="color:#d88a4a">🔥 ไฟไหม้ทำความเสียหาย ${b.dmg} กับ${b.side==='foe'?esc(foe.name):esc(p.name)}</span>`));

    after = `<div class="expl" style="border-left-color:${t.correct?'var(--glaze)':'var(--bad)'}">
      ${lines.join('')}
      ${q.exp ? `<div class="tiny" style="margin-top:6px;padding-top:6px;border-top:1px solid var(--line)">${esc(q.exp)}</div>` : ''}
    </div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="duelNext">${(DUEL.hp<=0||DUEL.foeHp<=0||DUEL.round>=DUEL_ROUNDS)?'ดูผลการดวล':'ข้อถัดไป'}</button>`;
  }

  const side = (name, hp, max, gauge, el, otherEl, burn, shield, lv) => `
    <div class="grow">
      <div class="row spread"><b style="font-size:calc(14px * var(--fs))">${esc(name)}</b>
        <span class="mono tiny">${hp}/${max}</span></div>
      ${hpBar(hp, max)}
      ${gaugeBar(gauge, GAUGE_MAX)}
      <div class="tiny">Lv.${lv} · ${ELEMENTS[el].g}${ELEMENTS[el].n} ${elBadge(el, otherEl)}
        ${burn?'<span class="tiny" style="color:#d88a4a">🔥'+burn.left+'</span>':''}
        ${shield?'<span class="tiny" style="color:var(--glaze-lt)">🛡️</span>':''}</div>
    </div>`;

  return `
  <div class="card">
    <div class="stage"><canvas id="pot" width="420" height="340" aria-label="สนามดวล"></canvas></div>
    <div class="row" style="gap:12px;margin-top:4px;align-items:flex-start">
      ${side(p.name, DUEL.hp, DUEL.maxHp, DUEL.gauge, myEl, foeEl, DUEL.burn, DUEL.shield, p.lv)}
      ${side(foe.name, DUEL.foeHp, DUEL.foeMax, DUEL.foeGauge, foeEl, myEl, DUEL.foeBurn, DUEL.foeShield, foe.lv)}
    </div>
    ${ready ? `<div class="tiny" style="margin-top:6px;color:var(--gold);text-align:center">
      เกจคาถาเต็มแล้ว ตอบข้อถัดไปถูกจะร่ายคาถาทันที</div>` : ''}
  </div>
  <div class="card">
    <div class="qmeta">
      <span>ยกที่ ${DUEL.round + (DUEL.locked?0:1)}/${DUEL_ROUNDS} · ${UNITS[q.unit].n} · <span style="color:${d.c}">${d.n}</span></span>
      <span>${S.settings.timed && !DUEL.locked ? `<span id="qclock">${Math.ceil(Math.max(0,DUEL.limitMs-(Date.now()-DUEL.startAt))/1000)} วิ</span>` : ''}</span>
    </div>
    <div class="qtext">${esc(q.q)}</div>
    <div class="choices">${choices}</div>
    ${after}
  </div>
  ${DUEL.locked ? '' : '<div class="card"><button class="btn sm danger block" data-act="duelQuit">ยอมแพ้</button></div>'}`;
}

function duelResultSheet(){
  const r = DUEL.result, foe = DUEL.foe;
  const title = r.draw ? 'เสมอกัน' : (r.win ? 'ชนะการดวล' : 'แพ้การดวล');
  const line = (g, t, s2) => `<div class="item"><div class="ic">${g}</div><div class="grow"><b>${t}</b>${s2?`<div class="sub">${s2}</div>`:''}</div></div>`;
  return `<div class="eyebrow">ผลการดวล</div>
    <h2 style="color:${r.draw?'var(--gold)':(r.win?'var(--ok)':'var(--bad)')}">${title}</h2>
    <div class="sub">${esc(S.pet.name)} ${DUEL.hp}/${DUEL.maxHp} · ${esc(foe.name)} ${DUEL.foeHp}/${DUEL.foeMax} · ตอบถูก ${r.hit} ข้อ</div>
    <div class="gap"></div>
    <div class="list">
      ${line('🪙', `เหรียญ +${r.coin}`, r.full ? '' : 'เกินโควตารางวัลของวันนี้แล้ว ได้ 30%')}
      ${r.crys ? line('💠', `ผลึกสมาธิ +${r.crys}`) : ''}
      ${line('⭐', `ประสบการณ์ +${r.xp}`, r.lv ? `เลื่อนขึ้น ${r.lv} เลเวล` : '')}
      ${S.egg ? line('🥚', `ไข่ได้รับ +${DUEL.eggPts} คะแนนฐาน`) : ''}
    </div>
    <div class="gap"></div>
    <div class="tiny">${r.win ? 'ยิ่งตอบเร็วและตอบข้อยากได้ ยิ่งโจมตีแรง' : 'ลองตอบข้อที่ยากขึ้นและตอบให้เร็วขึ้น จะโจมตีได้แรงกว่านี้'}</div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="closeSheet">ปิด</button>`;
}


/* ===================== เลือกวิญญาณก่อนดวล (ทาง ค) ===================== */
let DUEL_FOE = null;

function duelPickSheet(foe){
  DUEL_FOE = foe;
  const foeEl = petEl(foe), fsp = SPECIES[foe.sp];
  const all = [S.pet].concat(S.garden || []).filter(Boolean);

  const row = (pet, idx) => {
    const sp = SPECIES[pet.sp], el = petEl(pet);
    const l = elLabel(el, foeEl);
    const hint = l ? `<span class="pill" style="color:${l.c};border-color:${l.c}55">${l.t}</span>` : '<span class="pill">เสมอ</span>';
    return `<div class="item">
      <div class="ic" style="background:${sp.dim};border-color:${sp.a(.4)}">${sp.g}</div>
      <div class="grow">
        <b>${esc(pet.name)}</b> ${hint}
        <div class="sub">${formName(pet.sp, pet.stage, pet.branch)} · Lv.${pet.lv} · ${ELEMENTS[el].g}${ELEMENTS[el].n}</div>
        <div class="tiny">โจมตี ${Math.round(duelAtk(pet, idx===0))} · คาถา ${Math.round(duelMagic(pet, idx===0))} · เลือด ${duelMaxHp(pet, idx===0)}</div>
        ${l && l.why ? `<div class="tiny" style="color:${l.c}">${l.why}</div>` : ''}
      </div>
      <button class="btn sm ${l && l.t==='ข่มได้' ? 'pri' : ''}" data-dpick="${idx}">เลือก</button>
    </div>`;
  };

  sheet(`<div class="eyebrow">รับคำท้าจาก ${esc(foe.name)}</div>
    <h2>เลือกวิญญาณลงสนาม</h2>
    <div class="sub">คู่ต่อสู้เป็นธาตุ${ELEMENTS[foeEl].n} ${ELEMENTS[foeEl].g} · Lv.${foe.lv} · เลือกตัวที่ข่มธาตุนี้ได้จะเสียเปรียบน้อยลง</div>
    <div class="gap"></div>
    <div class="list">${all.map((x,i) => row(x,i)).join('')}</div>
    <div class="gap"></div>
    <div class="tiny">เจ้าของรหัสเลือกวิญญาณไม่ได้ ระบบจึงเพิ่มเลือดให้ฝ่ายนั้น 8% เพื่อชดเชยที่เราได้ตีก่อน</div>
    <div class="gap"></div>
    <button class="btn block" data-act="duel">ยกเลิก</button>`);
}

/* สลับวิญญาณที่เลือกมาเป็นตัวหลักชั่วคราวแล้วเริ่มดวล */
function duelStartWith(idx){
  if (!DUEL_FOE) return toast('ไม่พบคู่ต่อสู้', 'bad');
  if (idx > 0){
    const g = S.garden || [];
    const pick = g[idx - 1];
    if (!pick) return toast('ไม่พบวิญญาณตัวนี้', 'bad');
    g[idx - 1] = S.pet;
    S.pet = pick;
    S.garden = g;
    save();
  }
  const foe = DUEL_FOE; DUEL_FOE = null;
  closeSheet();
  TAB = 'duel';
  document.querySelectorAll('#tabs button').forEach(x => x.classList.remove('on'));
  duelStart(foe, DUEL.subj, QUIZ.grade || S.grade);
  toast(`${S.pet.name} ลงสนามสู้กับ ${foe.name}`, 'gold');
}

/* ===================== ตารางธาตุ ===================== */
function elChartSheet(){
  const cx = 130, cy = 118, R = 82;
  const pos = EL_ORDER.map((e, i) => {
    const a = -Math.PI/2 + i * Math.PI/3;
    return { e, x: cx + Math.cos(a)*R, y: cy + Math.sin(a)*R };
  });
  const arrows = pos.map((p1, i) => {
    const p2 = pos[(i+1) % 6];
    const dx = p2.x-p1.x, dy = p2.y-p1.y, L = Math.hypot(dx,dy);
    const ux = dx/L, uy = dy/L, pad = 20;
    const x1 = p1.x+ux*pad, y1 = p1.y+uy*pad, x2 = p2.x-ux*pad, y2 = p2.y-uy*pad;
    return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#7cae9b" stroke-width="1.6" marker-end="url(#ah)" opacity=".75"/>`;
  }).join('');
  const nodes = pos.map(p => `
    <circle cx="${p.x}" cy="${p.y}" r="17" fill="hsla(${ELEMENTS[p.e].h},40%,45%,.30)" stroke="hsl(${ELEMENTS[p.e].h},40%,60%)" stroke-width="1.2"/>
    <text x="${p.x}" y="${p.y+5}" text-anchor="middle" font-size="15">${ELEMENTS[p.e].g}</text>
    <text x="${p.x}" y="${p.y+31}" text-anchor="middle" font-size="10" fill="#8ba69c">${ELEMENTS[p.e].n}</text>`).join('');

  const pairRows = Object.keys(EL_WHY).map(k => {
    const [a, b] = k.split('>');
    return `<div class="item">
      <div class="ic" style="background:hsla(${ELEMENTS[a].h},40%,45%,.22)">${ELEMENTS[a].g}</div>
      <div class="grow"><b>${ELEMENTS[a].n} ข่ม ${ELEMENTS[b].n}</b>
        <div class="tiny">${EL_WHY[k]}</div></div>
      <span class="pill" style="color:var(--ok);border-color:var(--ok)55">×${ADV_UP}</span>
    </div>`;
  }).join('');

  sheet(`<div class="eyebrow">ตารางธาตุ</div>
    <h2>ธาตุไหนข่มธาตุไหน</h2>
    <div class="sub">ธาตุที่ข่มได้จะโจมตีแรงขึ้น ${Math.round((ADV_UP-1)*100)}% ส่วนธาตุที่ถูกข่มจะโจมตีลดลง ${Math.round((1-ADV_DOWN)*100)}%</div>
    <div class="gap"></div>
    <div style="text-align:center;background:rgba(255,255,255,.03);border:1px solid var(--line);border-radius:12px;padding:6px">
      <svg viewBox="0 0 260 250" style="width:100%;max-width:280px">
        <defs><marker id="ah" markerWidth="7" markerHeight="7" refX="6" refY="3" orient="auto">
          <path d="M0,0 L7,3 L0,6 Z" fill="#7cae9b"/></marker></defs>
        ${arrows}${nodes}
        <text x="130" y="228" text-anchor="middle" font-size="11" fill="#8ba69c">${ELEMENTS.light.g} แสง ↔ เงา ${ELEMENTS.shade.g} ข่มกันทั้งสองทาง</text>
      </svg>
    </div>
    <div class="gap"></div>
    <div class="list">${pairRows}</div>
    <div class="gap"></div>
    <div class="tiny">ธาตุของวิญญาณมาจากหน่วยการเรียนรู้ที่ตอบระหว่างฟักไข่ อยากได้ธาตุไหนให้ดูผังธาตุประจำไข่ในหน้ากระถาง</div>
    <div class="gap"></div>
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}
