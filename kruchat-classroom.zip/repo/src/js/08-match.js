/* ===========================================================
   โหมดจับคู่ — อุ่นเครื่องก่อนสอบ
   แบบที่ 1 โจทย์ ↔ เฉลย  สร้างจากคลังคำถามที่มีอยู่
   แบบที่ 2 ศักราช ↔ ปี   สร้างด้วยสูตรเทียบศักราช
   ตอบผิดไม่หักคะแนน คู่จะเด้งกลับให้ลองใหม่ แต่จับเวลาไว้
   =========================================================== */

const MATCH_PAIRS = 5;          // จำนวนคู่ต่อหนึ่งชุด
const MATCH_SETS  = 3;          // จำนวนชุดต่อหนึ่งรอบ

/* เกณฑ์เวลาเพื่อให้รางวัล (วินาทีต่อชุด) */
const MATCH_TIME = { gold:35, silver:55 };

/* ---------- สร้างชุดจับคู่ ---------- */

/* แบบที่ 1 โจทย์กับเฉลย ตัวลวงคือเฉลยของข้ออื่นในหน่วยเดียวกัน */
function buildMatchQA(subj, grade){
  const pool = questionsBy(subj, grade);
  if (pool.length < MATCH_PAIRS) return null;

  /* จัดกลุ่มตามหน่วย แล้วเลือกหน่วยที่มีข้อพอ */
  const byUnit = {};
  pool.forEach(q => (byUnit[q.unit] = byUnit[q.unit] || []).push(q));
  const units = Object.keys(byUnit).filter(u => byUnit[u].length >= MATCH_PAIRS);
  const list = units.length
    ? byUnit[units[Math.floor(Math.random() * units.length)]]
    : pool;

  const pick = list.slice().sort(() => Math.random() - .5).slice(0, MATCH_PAIRS);
  return {
    kind: 'qa',
    title: units.length ? UNITS[pick[0].unit].n : 'ผสมทุกหน่วย',
    left:  pick.map((q, i) => ({ id:i, t: q.q })),
    right: pick.map((q, i) => ({ id:i, t: q.ch[q.ans] })),
    ids:   pick.map(q => q.id),
    units: pick.map(q => q.unit),
    diffs: pick.map(q => q.diff),
  };
}

/* แบบที่ 2 เทียบศักราช */
const ERA_DEFS = [
  {k:'ms', n:'ม.ศ.', full:'มหาศักราช',      add:621},
  {k:'js', n:'จ.ศ.', full:'จุลศักราช',      add:1181},
  {k:'rs', n:'ร.ศ.', full:'รัตนโกสินทร์ศก', add:2324},
  {k:'cs', n:'ค.ศ.', full:'คริสต์ศักราช',   add:543},
  {k:'hs', n:'ฮ.ศ.', full:'ฮิจเราะห์ศักราช', add:1122},
];
function buildMatchEra(){
  /* สุ่มศักราชมา 5 คู่ ให้ต่างชนิดกันมากที่สุด */
  const defs = ERA_DEFS.slice().sort(() => Math.random() - .5);
  const rows = [];
  for (let i = 0; i < MATCH_PAIRS; i++){
    const e = defs[i % defs.length];
    /* เลือกปีที่แปลงแล้วอยู่ในช่วง พ.ศ. 1800-2600 เพื่อให้เป็นตัวเลขที่เด็กคุ้น */
    const be = 1800 + Math.floor(Math.random() * 800);
    const raw = be - e.add;
    if (raw <= 0){ i--; continue; }
    rows.push({ era:e, raw, be });
  }
  return {
    kind: 'era',
    title: 'เทียบศักราชเป็นพุทธศักราช',
    left:  rows.map((r, i) => ({ id:i, t: `${r.era.n} ${r.raw}` })),
    right: rows.map((r, i) => ({ id:i, t: `พ.ศ. ${r.be}` })),
    why:   rows.map(r => `${r.era.full} บวก ${r.era.add}`),
    diffs: rows.map(() => 2),
    units: rows.map(() => null),
  };
}

/* ---------- สถานะโหมดจับคู่ ---------- */
const MATCH = {
  running:false, kind:'qa', subj:'mix', grade:null,
  set:0, sets:[], cur:null,
  leftOrder:[], rightOrder:[], sel:null, done:[], wrong:0,
  startAt:0, times:[], tickId:null, result:null,
};

function matchStart(kind, subj, grade){
  MATCH.kind = kind; MATCH.subj = subj; MATCH.grade = grade;
  MATCH.sets = [];
  for (let i = 0; i < MATCH_SETS; i++){
    const s = kind === 'era' ? buildMatchEra() : buildMatchQA(subj, grade);
    if (!s) break;
    MATCH.sets.push(s);
  }
  if (!MATCH.sets.length) return toast('คำถามในชุดนี้ยังไม่พอสำหรับโหมดจับคู่', 'bad');
  MATCH.running = true; MATCH.set = 0; MATCH.times = []; MATCH.result = null; MATCH.mqDone = null;
  matchLoadSet();
}

function matchLoadSet(){
  const s = MATCH.sets[MATCH.set];
  MATCH.cur = s;
  MATCH.leftOrder  = s.left.map(x => x.id).sort(() => Math.random() - .5);
  MATCH.rightOrder = s.right.map(x => x.id).sort(() => Math.random() - .5);
  MATCH.sel = null; MATCH.done = []; MATCH.wrong = 0;
  MATCH.startAt = Date.now();
  clearInterval(MATCH.tickId);
  MATCH.tickId = setInterval(() => {
    const el = document.getElementById('mclock');
    if (el) el.textContent = ((Date.now() - MATCH.startAt) / 1000).toFixed(1) + ' วิ';
  }, 100);
  render();
}

/* แตะฝั่งซ้ายหรือขวา */
function matchTap(side, id){
  if (!MATCH.running || MATCH.done.includes(id) && side === 'L') return;
  if (MATCH.done.includes(id)) return;

  if (!MATCH.sel){ MATCH.sel = { side, id }; return render(); }
  if (MATCH.sel.side === side){ MATCH.sel = { side, id }; return render(); }

  const a = MATCH.sel.id, b = id;
  MATCH.sel = null;
  if (a === b){
    MATCH.done.push(a);
    sfx('match');
    const s = MATCH.cur;
    /* บันทึกผลรายหน่วยเหมือนการตอบคำถามปกติ */
    if (s.units && s.units[a] && s.ids && s.ids[a]){
      const q = allQuestions().find(x => x.id === s.ids[a]);
      if (q){ recordAnswer(q, true); recordProgress(q, true);
        const md = mqRecord(q, true);
        if (md) MATCH.mqDone = { m: md, rw: mqReward(md) }; }
    }
    S.stats.answered++; S.stats.correct++;
    wakeProgress(1);
    if (MATCH.done.length >= MATCH.cur.left.length) return matchFinishSet();
  } else {
    MATCH.wrong++;
    sfx('wrong');
    View.bounce = 1;
  }
  save(); render();
}

function matchFinishSet(){
  clearInterval(MATCH.tickId);
  const sec = (Date.now() - MATCH.startAt) / 1000;
  MATCH.times.push({ sec, wrong: MATCH.wrong });
  MATCH.set++;
  if (MATCH.set >= MATCH.sets.length) return matchFinish();
  render();
  sheet(`<div class="eyebrow">ชุดที่ ${MATCH.set} เสร็จแล้ว</div>
    <h2>${sec.toFixed(1)} วินาที</h2>
    <div class="sub">จับผิดไป ${MATCH.wrong} ครั้ง · เหลืออีก ${MATCH.sets.length - MATCH.set} ชุด</div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="matchNext">ชุดถัดไป</button>`);
}

function matchFinish(){
  clearInterval(MATCH.tickId);
  MATCH.running = false;
  const totSec = MATCH.times.reduce((a, x) => a + x.sec, 0);
  const totWrong = MATCH.times.reduce((a, x) => a + x.wrong, 0);
  const avg = totSec / Math.max(1, MATCH.times.length);
  const rank = avg <= MATCH_TIME.gold ? 'gold' : (avg <= MATCH_TIME.silver ? 'silver' : 'ok');

  const pairs = MATCH.times.length * MATCH_PAIRS;
  let coin = Math.round(pairs * 6 + (rank === 'gold' ? 60 : rank === 'silver' ? 30 : 0));
  let crys = rank === 'gold' ? 3 : (rank === 'silver' ? 1 : 0);
  let xp = Math.round(pairs * 7 * (rank === 'gold' ? 1.3 : 1));
  if (totWrong === 0){ coin += 40; crys += 1; }

  S.coins += coin; S.crystals += crys;
  if (S.pet) S.pet.care.play += CARE.match;
  const lv = S.pet ? gainXp(xp).levels : 0;
  S.match = S.match || { plays:0, best:0 };
  S.match.plays++;
  if (!S.match.best || avg < S.match.best) S.match.best = avg;

  MATCH.result = { totSec, totWrong, avg, rank, coin, crys, xp, lv, pairs };
  sfx(MATCH.mqDone ? 'mission' : (rank === 'gold' ? 'win' : 'round'));
  save(); render();
  sheet(matchResultSheet());
}

function matchResultSheet(){
  const r = MATCH.result;
  const title = r.rank === 'gold' ? 'เร็วมาก' : (r.rank === 'silver' ? 'ทำได้ดี' : 'ผ่านแล้ว');
  const col = r.rank === 'gold' ? 'var(--gold)' : (r.rank === 'silver' ? 'var(--glaze-lt)' : 'var(--mist)');
  const line = (g, t, s2) => `<div class="item"><div class="ic">${g}</div>
    <div class="grow"><b>${t}</b>${s2 ? `<div class="sub">${s2}</div>` : ''}</div></div>`;
  return `<div class="eyebrow">จับคู่เสร็จแล้ว</div>
    <h2 style="color:${col}">${title}</h2>
    <div class="sub">จับคู่ได้ ${r.pairs} คู่ · รวม ${r.totSec.toFixed(1)} วินาที · เฉลี่ยชุดละ ${r.avg.toFixed(1)} วินาที · จับผิด ${r.totWrong} ครั้ง</div>
    <div class="gap"></div>
    <div class="list">
      ${line('🪙', `เหรียญ +${r.coin}`, r.rank === 'gold' ? 'โบนัสความเร็ว' : '')}
      ${r.crys ? line('💠', `ผลึกสมาธิ +${r.crys}`, r.totWrong === 0 ? 'ไม่พลาดเลยสักครั้ง' : '') : ''}
      ${S.pet ? line('⭐', `ประสบการณ์ +${r.xp}`, r.lv ? `เลื่อนขึ้น ${r.lv} เลเวล` : '') : ''}
      ${MATCH.mqDone ? line('🎯', `ภารกิจ${esc(UNITS[MATCH.mqDone.m.unit].n)}สำเร็จ`, `ผลึก +${MATCH.mqDone.rw.crys} · เหรียญ +${MATCH.mqDone.rw.coin}`) : ''}
      ${S.match && S.match.best ? line('⏱️', `สถิติดีที่สุด ${S.match.best.toFixed(1)} วินาทีต่อชุด`) : ''}
    </div>
    <div class="gap"></div>
    <div class="tiny">โหมดนี้ไม่ให้คะแนนไข่ แต่นับเข้าผลสัมฤทธิ์รายหน่วยและช่วยปลุกวิญญาณที่หลับอยู่</div>
    <div class="gap"></div>
    <button class="btn pri block" data-act="closeSheet">เรียบร้อย</button>`;
}

/* ===================== หน้าจอจับคู่ ===================== */
function matchIntroSheet(){
  const grade = QUIZ.grade || S.grade;
  const n = questionsBy(MATCH.subj, grade).length;
  sheet(`<div class="eyebrow">โหมดจับคู่</div>
    <h2>อุ่นเครื่องก่อนสอบ</h2>
    <div class="sub">ลากสายตาจับคู่ให้ครบ ${MATCH_PAIRS} คู่ต่อชุด รวม ${MATCH_SETS} ชุด ตอบผิดไม่หักคะแนน แต่จับเวลาไว้</div>
    <div class="gap"></div>

    <div class="eyebrow">ระดับชั้น</div>
    <div class="chips">${GRADE_KEYS.map(g => {
      const c = questionsBy('mix', g).length;
      return `<button class="chip ${g===grade?'on':''}" data-mgrade="${g}" ${c?'':'disabled'}>${GRADES[g].n}</button>`;
    }).join('')}</div>
    <div class="gap" style="height:8px"></div>
    <div class="eyebrow">วิชา</div>
    <div class="chips">
      <button class="chip ${MATCH.subj==='mix'?'on':''}" data-msubj="mix">🎲 ผสม</button>
      ${SUBJ_KEYS.map(k => {
        const c = questionsBy(k, grade).length;
        return `<button class="chip ${MATCH.subj===k?'on':''}" data-msubj="${k}" ${c?'':'disabled'}>${SUBJECTS[k].g} ${SUBJECTS[k].short}</button>`;
      }).join('')}
    </div>
    <div class="gap"></div>

    <div class="list">
      <div class="item"><div class="ic">🔗</div>
        <div class="grow"><b>โจทย์ จับคู่กับ เฉลย</b>
          <div class="sub">ยกโจทย์จากหน่วยเดียวกันมา 5 ข้อ ตัวลวงคือเฉลยของข้ออื่นในหน่วยนั้น</div>
          <div class="tiny">คลังชุดนี้มี ${n} ข้อ</div></div>
        <button class="btn sm pri" data-mgo="qa" ${n >= MATCH_PAIRS ? '' : 'disabled'}>เริ่ม</button></div>
      <div class="item"><div class="ic">📅</div>
        <div class="grow"><b>ศักราช จับคู่กับ พุทธศักราช</b>
          <div class="sub">ม.ศ. จ.ศ. ร.ศ. ค.ศ. ฮ.ศ. แปลงเป็น พ.ศ. ให้ถูกคู่</div>
          <div class="tiny">สร้างโจทย์ใหม่ทุกครั้ง ไม่มีวันซ้ำ</div></div>
        <button class="btn sm gold" data-mgo="era">เริ่ม</button></div>
    </div>
    <div class="gap"></div>
    ${S.match && S.match.best ? `<div class="tiny">สถิติดีที่สุดของเรา ${S.match.best.toFixed(1)} วินาทีต่อชุด · เล่นไปแล้ว ${S.match.plays} รอบ</div><div class="gap"></div>` : ''}
    <button class="btn block" data-act="closeSheet">ปิด</button>`);
}

function viewMatch(){
  if (!MATCH.running) return viewQuiz();
  const s = MATCH.cur;
  const left = MATCH.leftOrder.map(id => {
    const done = MATCH.done.includes(id);
    const sel = MATCH.sel && MATCH.sel.side === 'L' && MATCH.sel.id === id;
    return `<button class="mcell ${done?'done':''} ${sel?'sel':''}" data-mtap="L:${id}" ${done?'disabled':''}>
      ${esc(s.left.find(x => x.id === id).t)}</button>`;
  }).join('');
  const right = MATCH.rightOrder.map(id => {
    const done = MATCH.done.includes(id);
    const sel = MATCH.sel && MATCH.sel.side === 'R' && MATCH.sel.id === id;
    return `<button class="mcell ${done?'done':''} ${sel?'sel':''}" data-mtap="R:${id}" ${done?'disabled':''}>
      ${esc(s.right.find(x => x.id === id).t)}</button>`;
  }).join('');

  return `<div class="card">
    <div class="qmeta">
      <span>ชุดที่ ${MATCH.set + 1}/${MATCH.sets.length} · ${esc(s.title)}</span>
      <span id="mclock" class="mono">0.0 วิ</span>
    </div>
    <div class="row spread" style="margin-top:4px">
      <span class="tiny">จับคู่แล้ว ${MATCH.done.length}/${s.left.length}</span>
      <span class="tiny">${MATCH.wrong ? 'จับผิด ' + MATCH.wrong + ' ครั้ง' : 'ยังไม่พลาดเลย'}</span>
    </div>
    <div class="bar" style="margin-top:6px"><i style="width:${MATCH.done.length/s.left.length*100}%;background:var(--glaze)"></i></div>
    <div class="gap" style="height:10px"></div>
    <div class="mgrid">
      <div class="mcol">${left}</div>
      <div class="mcol">${right}</div>
    </div>
    ${s.kind === 'era' ? `<div class="gap" style="height:8px"></div>
      <div class="tiny">ม.ศ.+621 · จ.ศ.+1181 · ร.ศ.+2324 · ค.ศ.+543 · ฮ.ศ.+1122</div>` : ''}
  </div>
  <div class="card"><button class="btn sm danger block" data-act="matchQuit">ออกจากโหมดจับคู่</button></div>`;
}
